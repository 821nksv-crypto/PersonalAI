# MVP 0.4 — Real local inference

This version uses the current ExecuTorch Android 1.5 LLM API.

- Dependency: `org.pytorch:executorch-android:1.5.0`
- Model: user-imported `.pte`
- Tokenizer: user-imported tokenizer file
- Inference: on-device, no cloud API
- Generation: background coroutine; ExecuTorch token callback
- Context: reset before each request in this MVP

ExecuTorch's Android LLM API documents `LlmModule`, `LlmGenerationConfig`, streaming `LlmCallback`, and loading from model/tokenizer paths. XNNPACK is the general CPU backend; hardware-specific backends can be added later.

**Important:** A `.pte` file must be exported for an ExecuTorch-supported LLM architecture. A random PyTorch/Hugging Face checkpoint will not work merely by renaming it to `.pte`.

The app intentionally does not auto-download a model. This prevents an unexpected large download and keeps model licensing explicit.
