# Personal AI MVP 1.8

## Signed model manifests
Added Ed25519 detached-signature verification over a canonical model manifest. The verifier expects a public key pinned by the application, not supplied by the downloaded package.

## Atomic model installation
Models are copied to a `.part` file, flushed, then committed atomically. An existing model is retained temporarily as a rollback backup. A partially copied model is never treated as active.

## Indexing UI control layer
`IndexingController` exposes WorkManager state and cancellation for document-specific indexing jobs.

## Local memory compaction
Added a deterministic bounded `MemoryCompactor`. It keeps a bounded local transcript without sending data to a remote service.

## Security notes
- SHA-256 verifies file integrity against the manifest.
- Ed25519 verifies manifest authenticity when a pinned public key is configured.
- The current source does not ship a real production signing key; release builds must inject the project's actual public key.
- Signature verification must be required, rather than optional, for a production model marketplace/download path.

## Next: MVP 1.9
- Wire model installer and signed manifests into the visible Model Manager UI.
- Add real document indexing progress/cancel/retry UI.
- Add encrypted local memory store with user-controlled enable/disable/clear.
- Add voice I/O as a separate permission-gated module.
- Add automated local integration tests.
