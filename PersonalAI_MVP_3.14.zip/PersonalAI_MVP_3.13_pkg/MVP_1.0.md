# Personal AI MVP 1.0

This milestone turns the previous runtime + RAG pieces into a single local conversational layer.

## What is implemented

- Local conversational chat through `LocalModelEngine`.
- Local conversation persistence in app-private storage.
- Simple router:
  - `GENERAL_CHAT` -> local LLM.
  - `DOCUMENT_QA` -> local retrieval + local LLM.
- User-selected PDF ingestion with page-aware chunks.
- Local vector retrieval.
- Source metadata shown separately from model output.
- Explicit local-data status in the UI.
- No automatic access to contacts, SMS, WhatsApp, email, gallery, microphone, camera, GPS, or other personal data.
- No cloud LLM API is used by this milestone.

## Important limitation

The project still requires a compatible ExecuTorch `.pte` model and tokenizer to be imported by the user. The app does not bundle a large model.

The included `ExecuTorchLocalEngine` is the Android runtime adapter. A real response is only possible after a compatible model pack has been installed successfully.

## Routing behavior

The router is intentionally conservative and local. It does not send prompts to a server to classify them.

If a local document is indexed and the prompt contains document-oriented cues, it routes to RAG. Otherwise it routes to ordinary local conversation.

## Next milestone: 1.1

- Explicit Internet toggle and a search provider adapter.
- Better intent routing using local heuristics/model classification.
- Streaming UI from `LlmCallback`.
- Persistent document index rebuild instead of re-embedding only during the current process.
- Full tokenizer assets and verified model-pack installer.
- Optional voice input/output.
