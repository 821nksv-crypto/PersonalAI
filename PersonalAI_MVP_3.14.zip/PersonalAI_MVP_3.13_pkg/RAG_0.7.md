# MVP 0.7 — Page-aware local PDF RAG

## Implemented

- PDF text extraction using PdfBox-Android 2.0.27.0.
- Per-page extraction.
- Page-aware chunking.
- Local deterministic vectorization.
- Cosine-similarity retrieval.
- Source metadata: document name + page number.
- Context builder ready to feed retrieved passages into the local LLM.

The PdfBox-Android project documents Android support and `PDFTextStripper`; its latest listed release is 2.0.27.0. The upstream Apache PDFBox project also documents page-by-page text extraction.

## Important distinction

The vectorizer in this MVP is a deterministic hashing vectorizer. It is deliberately NOT presented as a neural embedding model.

Next upgrade:
1. Add a small on-device sentence embedding model.
2. Persist vectors instead of keeping them only in memory.
3. Add OCR fallback for scanned PDFs.
4. Connect `RagContextBuilder` directly to the local LLM prompt.
5. Display citations in the chat UI.

## Privacy boundary

PDF content remains local. The RAG pipeline has no network API and does not expose document chunks to distributed workers.
