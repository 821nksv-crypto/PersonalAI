# Personal AI MVP 2.6

## Explicit Android file access

This milestone adds Android Storage Access Framework (SAF) integration points.

### Added
- `ContentImport`
- `SelectedPdfImporter`
- `SelectedModelImporter`
- `DocumentProgressBridge`
- SAF-based PDF/model/manifest Activity Result contracts
- Explicit copy into app-private `filesDir`
- SHA-256 helper for imported content

### Privacy boundary

The application does not enumerate the gallery, Downloads folder, contacts, SMS, WhatsApp, email, browser history, microphone, camera, or GPS.

A file reaches the application only after the user selects it through the Android picker.

The selected bytes are copied into app-private storage.

### Verification boundary

Model import is still:

User selects `.pte`
→ user selects manifest
→ manifest parsing
→ SHA-256 verification
→ Ed25519 signature verification
→ atomic install

No automatic model download is introduced.

### Current limitation

The host Activity demonstrates the SAF boundary and private-copy step. The final wiring into the existing `DocumentImportCoordinator` and `VerifiedModelImportController` should be completed after their exact constructor/controller APIs are reconciled. This avoids pretending that a callback is a complete production pipeline.

### Next: MVP 2.7

- Complete coordinator calls after API reconciliation.
- Connect imported PDF records to catalog + WorkManager.
- Connect model pair to `VerifiedModelImportController`.
- Surface WorkManager progress in Document Library.
- Connect encrypted memory clear/toggle.
- Replace `ChatHostScreen` with actual streaming Chat UI.
- Add integration tests for selected-file → private-storage → catalog lifecycle.
