# Personal AI MVP 3.6

## Runtime milestone

MVP 3.6 makes installed-model selection deterministic and validation-gated before inference.

### Runtime path

`InstalledModelPackageStore -> ModelRuntimeResolver -> ExecuTorchLocalEngine -> ChatViewModel -> ChatService`

### Validation gates

- runtime must be `executorch`
- device ABI must match the manifest
- `.pte` file must exist and match size/SHA-256
- tokenizer must exist
- tokenizer SHA-256 must match the manifest
- only a validated package can create `ExecuTorchLocalEngine`
- if no package passes validation, the UI exposes an unavailable state and does not enable chat input

### Selection

When multiple validated packages exist, the resolver selects deterministically by manifest version and then model ID. Production releases should replace lexical version ordering with semantic-version comparison if semantic versions are required.

### Verification limitation

This milestone is source-level verified. A full Android APK build is not claimed because the execution environment does not have the required Gradle/dependency artifacts available offline.
