# PersonalAI MVP 3.13 — Build Readiness

Version: 3.13.0  
Version code: 38

## Purpose
3.13 is a build-readiness milestone. No new personal-data access or automatic data collection is introduced.

## Current Android build contract
- compileSdk: 35
- targetSdk: 35
- minSdk: 26
- Java/Kotlin JVM target: 17
- Android Gradle Plugin: 8.7.3
- Gradle distribution: 8.11.1
- Kotlin: 2.0.21

## Verification
Run from the project root:

```bash
./tools/verify_build_environment.sh
./gradlew testDebugUnitTest --stacktrace
./gradlew assembleDebug --stacktrace
```

Expected debug artifact:

`app/build/outputs/apk/debug/app-debug.apk`

## Important status
The source archive currently contains `gradle-wrapper.properties`, but the Gradle wrapper executable/JAR is not bundled because no usable wrapper JAR was available in the build environment used to prepare this checkpoint. Therefore APK compilation is **not claimed as verified** for this archive.

The included GitHub Actions workflow provisions JDK 17 and Android SDK 35 and runs unit tests plus `assembleDebug` once a complete Gradle wrapper is committed.
