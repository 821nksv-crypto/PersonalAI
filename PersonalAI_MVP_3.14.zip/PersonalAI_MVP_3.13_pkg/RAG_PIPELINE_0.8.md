# RAG pipeline 0.8

PDF
  -> page-aware chunks
  -> local MiniLM ONNX embedding
  -> local cosine retrieval
  -> top-k source passages
  -> local LLM prompt
  -> answer with document/page citations

The embedding model never receives data over the network from this pipeline.

The current vector index remains in memory. Persistence, incremental indexing and OCR are separate follow-up tasks.
