package com.personalai.mvp.integration

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ImportEventStore(context: Context) {
    private val file = File(context.filesDir, "import_events.json")

    @Synchronized
    fun append(event: ImportEvent) {
        val arr = if (file.exists()) JSONArray(file.readText()) else JSONArray()
        arr.put(JSONObject().apply {
            put("artifactId", event.artifactId)
            put("name", event.name)
            put("lifecycle", event.lifecycle.name)
            event.detail?.let { put("detail", it) }
            put("timestamp", System.currentTimeMillis())
        })
        file.writeText(arr.toString())
    }

    fun latest(artifactId: String): ImportEvent? {
        if (!file.exists()) return null
        val arr = JSONArray(file.readText())
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(i)
            if (o.optString("artifactId") == artifactId) {
                return ImportEvent(
                    artifactId,
                    o.optString("name"),
                    ImportLifecycle.valueOf(o.optString("lifecycle")),
                    o.optString("detail").takeIf { it.isNotEmpty() }
                )
            }
        }
        return null
    }
}
