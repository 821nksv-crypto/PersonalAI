package com.personalai.mvp.model

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Installs a verified local model atomically. If a tokenizer is declared in the
 * manifest, it is verified and committed together with the model.
 */
class AtomicModelInstaller(private val modelsDir: File, private val packageStore: InstalledModelPackageStore? = null) {
    fun install(
        source: File,
        manifest: ModelManifest,
        signatureBase64: String? = null,
        pinnedPublicKeyBase64: String? = null,
        tokenizerSource: File? = null
    ): InstallationResult {
        val compatibility = ModelCompatibility.check(manifest)
        if (!compatibility.compatible) return InstallationResult(false, compatibility.message)

        if (signatureBase64 != null && pinnedPublicKeyBase64 != null) {
            if (!SignedManifestVerifier.verify(canonicalManifest(manifest), signatureBase64, pinnedPublicKeyBase64)) {
                return InstallationResult(false, "Signed manifest verification failed")
            }
        }

        val verification = ModelVerifier.verify(source, manifest)
        if (!verification.verified) return InstallationResult(false, verification.message)

        val tokenizerName = manifest.tokenizerFileName
        if (tokenizerName != null) {
            val tokenizer = tokenizerSource ?: return InstallationResult(false, "Manifest requires tokenizer: $tokenizerName")
            if (tokenizerName != tokenizer.name) return InstallationResult(false, "Tokenizer filename mismatch")
            val expectedHash = manifest.tokenizerSha256
            if (expectedHash.isNullOrBlank()) return InstallationResult(false, "Tokenizer SHA-256 is required")
            val actualHash = ModelVerifier.sha256(tokenizer)
            if (!actualHash.equals(expectedHash, ignoreCase = true)) {
                return InstallationResult(false, "Tokenizer SHA-256 mismatch")
            }
        }

        modelsDir.mkdirs()
        val target = File(modelsDir, manifest.fileName)
        val temp = File(modelsDir, "${manifest.fileName}.part")
        val backup = File(modelsDir, "${manifest.fileName}.backup")
        val tokenizerTarget = tokenizerName?.let { File(modelsDir, it) }
        val tokenizerTemp = tokenizerName?.let { File(modelsDir, "$it.part") }
        val tokenizerBackup = tokenizerName?.let { File(modelsDir, "$it.backup") }

        return try {
            copyAndSync(source, temp)
            if (tokenizerName != null) copyAndSync(requireNotNull(tokenizerSource), requireNotNull(tokenizerTemp))

            backupExisting(target, backup)
            if (tokenizerTarget != null) backupExisting(tokenizerTarget, requireNotNull(tokenizerBackup))

            if (!temp.renameTo(target)) throw IllegalStateException("Could not commit model")
            if (tokenizerTemp != null && tokenizerTarget != null && !tokenizerTemp.renameTo(tokenizerTarget)) {
                throw IllegalStateException("Could not commit tokenizer")
            }

            backup.delete()
            tokenizerBackup?.delete()
            packageStore?.upsert(manifest)
            InstallationResult(true, "Model installed: ${target.name}")
        } catch (t: Throwable) {
            temp.delete()
            tokenizerTemp?.delete()
            if (backup.exists() && !target.exists()) backup.renameTo(target)
            if (tokenizerBackup?.exists() == true && tokenizerTarget?.exists() != true) {
                tokenizerBackup.renameTo(tokenizerTarget)
            }
            InstallationResult(false, "Install failed: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    private fun copyAndSync(source: File, target: File) {
        FileInputStream(source).use { input ->
            FileOutputStream(target).use { output ->
                input.copyTo(output, 1024 * 1024)
                output.fd.sync()
            }
        }
    }

    private fun backupExisting(target: File, backup: File) {
        if (!target.exists()) return
        backup.delete()
        if (!target.renameTo(backup)) throw IllegalStateException("Could not create rollback backup for ${target.name}")
    }

    private fun canonicalManifest(m: ModelManifest): String = listOf(
        m.id, m.displayName, m.version, m.runtime, m.architecture,
        m.fileName, m.sizeBytes.toString(), m.sha256,
        m.tokenizerFileName ?: "", m.tokenizerSha256 ?: ""
    ).joinToString("\n")
}

data class InstallationResult(val installed: Boolean, val message: String)
