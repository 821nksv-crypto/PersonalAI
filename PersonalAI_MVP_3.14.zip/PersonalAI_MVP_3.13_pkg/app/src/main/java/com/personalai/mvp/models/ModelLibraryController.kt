package com.personalai.mvp.models

import android.content.Context
import com.personalai.mvp.catalog.ModelCatalogStore
import com.personalai.mvp.model.InstalledModelPackageStore

class ModelLibraryController(context: Context) {
    private val catalog = ModelCatalogStore(context)
    private val packages = InstalledModelPackageStore(context)

    fun installed(): List<String> = catalog.list()

    fun registerInstalled(name: String) = catalog.add(name)

    fun remove(name: String) {
        catalog.remove(name)
        packages.list().firstOrNull { it.manifest.displayName == name }?.let { packages.remove(it.manifest.id) }
    }
}
