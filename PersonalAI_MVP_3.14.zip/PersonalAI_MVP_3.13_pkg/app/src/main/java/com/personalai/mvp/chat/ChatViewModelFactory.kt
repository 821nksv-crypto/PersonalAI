package com.personalai.mvp.chat

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.personalai.mvp.ai.LocalModelEngine
import com.personalai.mvp.internet.BraveSearchClient
import com.personalai.mvp.rag.PersistentVectorIndex
import com.personalai.mvp.security.SecureSettingsStore

class ChatViewModelFactory(
    private val context: Context,
    private val engine: LocalModelEngine,
    private val index: PersistentVectorIndex
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val secure = SecureSettingsStore(context.applicationContext)
        val client = secure.braveApiKey.takeIf { it.isNotBlank() }?.let { BraveSearchClient(it) }
        return ChatViewModel(
            engine = engine,
            serviceFactory = { policy -> ChatService(engine, index, policy, client) },
            store = ConversationStore(context.applicationContext)
        ) as T
    }
}
