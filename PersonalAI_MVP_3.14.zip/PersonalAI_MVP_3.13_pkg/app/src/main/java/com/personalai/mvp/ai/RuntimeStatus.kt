package com.personalai.mvp.ai

data class RuntimeStatus(
    val runtime: String,
    val ready: Boolean,
    val model: String,
    val note: String
)
