package com.personalai.mvp.rag

class LocalRetriever(private val store: LocalDocumentStore) {
    fun search(query: String, limit: Int = 4): List<DocumentChunk> {
        val terms = query.lowercase()
            .split(Regex("\\W+"))
            .filter { it.length >= 3 }
            .toSet()

        return store.loadAll()
            .map { chunk ->
                val words = chunk.text.lowercase()
                val score = terms.count { words.contains(it) }
                chunk to score
            }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first }
    }
}
