package com.personalai.mvp.models

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ModelVerificationScreen(
    session: ModelImportSession,
    onSelectModel: () -> Unit,
    onSelectManifest: () -> Unit,
    onInstall: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Verify Local Model", style = MaterialTheme.typography.headlineSmall)
        Text("Model: ${session.fileName.ifBlank { "Not selected" }}")
        Text("Manifest: ${session.manifestName.ifBlank { "Not selected" }}")
        Text("Status: ${session.state}")
        if (session.message.isNotBlank()) Text(session.message)

        OutlinedButton(onClick = onSelectModel, Modifier.fillMaxWidth()) {
            Text("Select .pte Model")
        }
        OutlinedButton(onClick = onSelectManifest, Modifier.fillMaxWidth()) {
            Text("Select Manifest JSON")
        }
        Button(
            onClick = onInstall,
            enabled = session.fileName.isNotBlank() && session.manifestName.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Verify & Install")
        }
    }
}
