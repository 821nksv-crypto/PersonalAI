package com.personalai.mvp.rag

data class DocumentChunk(
    val documentName: String,
    val chunkIndex: Int,
    val text: String
)
