package com.personalai.mvp.rag

import android.content.Context
import java.io.File
import java.security.MessageDigest

class LocalDocumentStore(private val context: Context) {
    private val dir = File(context.filesDir, "documents").apply { mkdirs() }

    fun saveText(documentName: String, text: String): List<DocumentChunk> {
        val safe = documentName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        File(dir, "$safe.txt").writeText(text, Charsets.UTF_8)
        return chunk(text, documentName)
    }

    fun loadAll(): List<DocumentChunk> =
        dir.listFiles()?.filter { it.isFile && it.extension == "txt" }?.flatMap {
            chunk(it.readText(Charsets.UTF_8), it.name.removeSuffix(".txt"))
        } ?: emptyList()

    private fun chunk(text: String, name: String, size: Int = 1200): List<DocumentChunk> {
        val clean = text.replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty()) return emptyList()
        return clean.chunked(size).mapIndexed { i, part -> DocumentChunk(name, i, part) }
    }

    fun sha256(text: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
}
