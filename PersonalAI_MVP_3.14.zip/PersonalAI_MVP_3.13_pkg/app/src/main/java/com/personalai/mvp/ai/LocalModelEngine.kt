package com.personalai.mvp.ai

/**
 * Boundary for the on-device LLM runtime.
 *
 * A native runtime (for example llama.cpp/ExecuTorch, depending on the
 * chosen model) should implement this interface. The UI never talks
 * directly to native inference code.
 */
interface LocalModelEngine {
    suspend fun generate(prompt: String): String
    fun isReady(): Boolean
    fun modelName(): String
}
