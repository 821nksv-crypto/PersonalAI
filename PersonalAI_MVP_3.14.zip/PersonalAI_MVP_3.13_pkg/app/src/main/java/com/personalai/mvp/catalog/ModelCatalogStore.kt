package com.personalai.mvp.catalog

import android.content.Context
import org.json.JSONArray
import java.io.File

class ModelCatalogStore(private val context: Context) {
    private val file = File(context.filesDir, "model_catalog.json")

    @Synchronized
    fun list(): List<String> {
        if (!file.exists()) return emptyList()
        val array = JSONArray(file.readText())
        return buildList {
            for (i in 0 until array.length()) add(array.getString(i))
        }
    }

    @Synchronized
    fun add(name: String) {
        val values = list().toMutableSet()
        values.add(name)
        persist(values.toList())
    }

    @Synchronized
    fun remove(name: String) {
        persist(list().filterNot { it == name })
    }

    private fun persist(values: List<String>) {
        val array = JSONArray()
        values.forEach(array::put)
        val tmp = File(file.parentFile, "${file.name}.part")
        tmp.writeText(array.toString())
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }
}
