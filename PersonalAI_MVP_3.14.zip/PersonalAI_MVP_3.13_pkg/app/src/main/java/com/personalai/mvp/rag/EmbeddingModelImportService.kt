package com.personalai.mvp.rag

import android.content.Context
import android.net.Uri
import com.personalai.mvp.model.ModelVerifier
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Imports an ONNX embedding package through Android's user-selected document UIs. */
class EmbeddingModelImportService(private val context: Context) {
    fun importSelectedPackage(modelUri: Uri, vocabUri: Uri, manifestUri: Uri): Result {
        val staging = File(context.cacheDir, "embedding-import-${UUID.randomUUID()}").apply { mkdirs() }
        return try {
            val manifest = context.contentResolver.openInputStream(manifestUri)?.bufferedReader()?.use { JSONObject(it.readText()) }
                ?: error("Could not read embedding manifest")
            val model = File(staging, "model.onnx")
            val vocab = File(staging, "vocab.txt")
            context.contentResolver.openInputStream(modelUri)?.use { input -> model.outputStream().use(input::copyTo) }
                ?: error("Could not read ONNX model")
            context.contentResolver.openInputStream(vocabUri)?.use { input -> vocab.outputStream().use(input::copyTo) }
                ?: error("Could not read vocabulary")

            val expectedModelHash = manifest.getString("modelSha256")
            val expectedVocabHash = manifest.getString("vocabSha256")
            require(ModelVerifier.sha256(model).equals(expectedModelHash, ignoreCase = true)) {
                "ONNX model SHA-256 does not match manifest"
            }
            require(ModelVerifier.sha256(vocab).equals(expectedVocabHash, ignoreCase = true)) {
                "Vocabulary SHA-256 does not match manifest"
            }
            require(manifest.optString("format", "onnx").equals("onnx", ignoreCase = true)) {
                "Embedding format must be ONNX"
            }
            require(manifest.optString("name").isNotBlank()) { "Embedding name is missing" }
            require(manifest.optString("version").isNotBlank()) { "Embedding version is missing" }
            require(manifest.optInt("dimension", 0) > 0) { "Embedding dimension is invalid" }
            require(manifest.optInt("maxLength", 128) >= 2) { "Embedding maxLength is invalid" }

            EmbeddingModelInstaller(context).installValidated(
                modelSource = model,
                vocabSource = vocab,
                name = manifest.getString("name"),
                version = manifest.getString("version"),
                dimension = manifest.getInt("dimension"),
                maxLength = manifest.optInt("maxLength", 128),
                expectedModelSha256 = expectedModelHash,
                expectedVocabSha256 = expectedVocabHash
            )
            Result.Success("Embedding model installed and verified: ${manifest.getString("name")} ${manifest.getString("version")}")
        } catch (t: Throwable) {
            Result.Failure(t.message ?: t.javaClass.simpleName)
        } finally {
            staging.deleteRecursively()
        }
    }

    fun status(): EmbeddingStatus {
        val root = File(context.filesDir, "embedding")
        val manifestFile = File(root, "embedding_manifest.json")
        if (!manifestFile.isFile) return EmbeddingStatus("Hashing baseline", "No neural embedding installed", false, null)
        return runCatching {
            val o = JSONObject(manifestFile.readText())
            EmbeddingStatus(
                o.optString("name", "Unknown"),
                "Version ${o.optString("version", "unknown")}, ${o.optInt("dimension", 0)} dimensions",
                true,
                o.optString("version", null)
            )
        }.getOrElse { EmbeddingStatus("Invalid embedding package", it.message ?: "Verification failed", false, null) }
    }

    sealed interface Result {
        data class Success(val message: String) : Result
        data class Failure(val message: String) : Result
    }
}

data class EmbeddingStatus(
    val name: String,
    val detail: String,
    val neural: Boolean,
    val version: String?
)
