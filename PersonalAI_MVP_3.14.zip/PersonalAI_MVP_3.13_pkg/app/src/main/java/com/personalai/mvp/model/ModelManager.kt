package com.personalai.mvp.model

import java.io.File

class ModelManager(private val modelsDir: File) {
    fun installedModels(): List<File> =
        modelsDir.listFiles { file -> file.isFile && !file.name.endsWith(".part") && !file.name.endsWith(".backup") }
            ?.sortedBy { it.name }
            ?: emptyList()

    fun remove(model: File): Boolean = !model.exists() || model.delete()

    fun verify(model: File, manifest: ModelManifest): VerificationResult =
        ModelVerifier.verify(model, manifest)
}
