package com.personalai.mvp.rag

import android.content.Context
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject

class DocumentStore(context: Context) {
    private val file = java.io.File(context.filesDir, "documents.json")
    private val index = PersistentVectorIndex(context)

    fun list(): List<DocumentRecord> {
        if (!file.exists()) return emptyList()
        return runCatching {
            val a = JSONArray(file.readText())
            buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    add(DocumentRecord(
                        o.getString("documentId"),
                        o.getString("documentName"),
                        o.getString("sha256"),
                        o.getInt("chunkCount"),
                        o.getLong("addedAt")
                    ))
                }
            }
        }.getOrDefault(emptyList())
    }

    fun containsHash(hash: String): Boolean = list().any { it.sha256 == hash }

    fun add(record: DocumentRecord) {
        val all = list().filterNot { it.documentId == record.documentId } + record
        save(all)
    }

    fun remove(documentId: String) {
        index.removeDocument(documentId)
        save(list().filterNot { it.documentId == documentId })
    }

    private fun save(records: List<DocumentRecord>) {
        val a = JSONArray()
        records.forEach {
            a.put(JSONObject().apply {
                put("documentId", it.documentId)
                put("documentName", it.documentName)
                put("sha256", it.sha256)
                put("chunkCount", it.chunkCount)
                put("addedAt", it.addedAt)
            })
        }
        file.writeText(a.toString())
    }

    companion object {
        fun sha256(bytes: ByteArray): String =
            MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    }
}
