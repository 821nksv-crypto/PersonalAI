package com.personalai.mvp.models

data class ModelImportSession(
    val fileName: String = "",
    val manifestName: String = "",
    val state: ModelInstallState.Status = ModelInstallState.Status.IDLE,
    val message: String = ""
)
