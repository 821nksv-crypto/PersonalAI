package com.personalai.mvp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun LocalMemoryControls(
    enabled: Boolean,
    onEnabledChange: (Boolean) -> Unit,
    onClear: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Local Memory", style = MaterialTheme.typography.titleMedium)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(if (enabled) "Memory is enabled" else "Memory is disabled")
            Switch(checked = enabled, onCheckedChange = onEnabledChange)
        }
        OutlinedButton(onClick = onClear) {
            Text("Clear Local Memory")
        }
    }
}

@Composable
fun IndexingProgress(
    running: Boolean,
    progress: Int,
    status: String,
    error: String?,
    onCancel: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Document Indexing", style = MaterialTheme.typography.titleMedium)
        if (running) LinearProgressIndicator(progress = { progress / 100f })
        Text("$status${error?.let { ": $it" } ?: ""}")
        if (running) OutlinedButton(onClick = onCancel) { Text("Cancel") }
    }
}
