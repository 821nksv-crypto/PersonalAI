package com.personalai.mvp.models

import java.io.File
import com.personalai.mvp.importer.ImportResult
import com.personalai.mvp.importer.ModelImportPipeline

class VerifiedModelImportController(
    private val pipeline: ModelImportPipeline,
    private val library: ModelLibraryController
) {
    fun importFromManifest(
        modelFile: File,
        manifestJson: String,
        signatureBase64: String?,
        pinnedPublicKeyBase64: String?,
        tokenizerFile: File? = null
    ): ImportResult {
        return try {
            val manifest = ModelManifestJson.parse(manifestJson)
            val installation = pipeline.import(
                modelFile,
                manifest,
                signatureBase64,
                pinnedPublicKeyBase64,
                tokenizerSource = tokenizerFile
            )
            if (!installation.installed) return ImportResult.Failure(installation.message)
            library.registerInstalled(manifest.displayName)
            ImportResult.Success("Installed ${manifest.displayName} ${manifest.version}")
        } catch (t: Throwable) {
            ImportResult.Failure(t.message ?: "Model verification/installation failed")
        }
    }
}
