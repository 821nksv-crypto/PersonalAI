package com.personalai.mvp.rag

/** Common contract for every local embedding implementation used by RAG. */
interface EmbeddingRuntime : AutoCloseable {
    val manifest: EmbeddingModelManifest
    fun embed(text: String): FloatArray

    override fun close() = Unit
}

class HashingEmbeddingRuntime(
    override val manifest: EmbeddingModelManifest = EmbeddingModelManifest.HASHING_384_V1
) : EmbeddingRuntime {
    private val vectorizer = LocalVectorizer(manifest.dimension)

    override fun embed(text: String): FloatArray = vectorizer.embed(text)
}

class OnnxEmbeddingRuntime(
    private val delegate: OnnxMiniLmEmbedder,
    override val manifest: EmbeddingModelManifest
) : EmbeddingRuntime {
    override fun embed(text: String): FloatArray = delegate.embed(text)
    override fun close() = delegate.close()
}
