package com.personalai.mvp.integration

enum class ImportLifecycle {
    SELECTED, COPIED_PRIVATE, REGISTERED, QUEUED, VERIFYING, INSTALLED, INDEXING, COMPLETED, FAILED
}

data class ImportEvent(
    val artifactId: String,
    val name: String,
    val lifecycle: ImportLifecycle,
    val detail: String? = null
)
