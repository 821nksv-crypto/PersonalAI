package com.personalai.mvp.ai

/** Explicit non-model state. Never fabricates an assistant response. */
class UnavailableLocalEngine(private val reason: String) : LocalModelEngine {
    override suspend fun generate(prompt: String): String =
        "Local model unavailable: $reason"

    override fun isReady(): Boolean = false
    override fun modelName(): String = "No local model"
}
