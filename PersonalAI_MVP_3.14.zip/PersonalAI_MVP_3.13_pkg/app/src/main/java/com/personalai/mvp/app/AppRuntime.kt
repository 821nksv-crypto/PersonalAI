package com.personalai.mvp.app

import android.content.Context
import com.personalai.mvp.appstate.AppCoordinator

class AppRuntime(context: Context) {
    val coordinator = AppCoordinator(context.applicationContext)
}
