package com.personalai.mvp.memory

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

class EncryptedMemoryStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        "personal_ai_memory",
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        context,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun isEnabled(): Boolean = prefs.getBoolean(KEY_ENABLED, true)

    fun setEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun getSummary(): String = prefs.getString(KEY_SUMMARY, "") ?: ""

    fun saveSummary(summary: String) {
        if (isEnabled()) prefs.edit().putString(KEY_SUMMARY, summary).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY_SUMMARY).apply()
    }

    companion object {
        private const val KEY_ENABLED = "enabled"
        private const val KEY_SUMMARY = "summary"
    }
}
