package com.personalai.mvp.rag

import kotlin.math.sqrt

/**
 * Offline deterministic hashing vectorizer.
 * This is a vector-retrieval baseline, not a neural embedding model.
 * It allows the RAG pipeline to be exercised without sending text anywhere.
 */
class LocalVectorizer(private val dimensions: Int = 384) {
    fun embed(text: String): FloatArray {
        val v = FloatArray(dimensions)
        val tokens = text.lowercase().split(Regex("\\W+")).filter { it.length >= 2 }
        for (token in tokens) {
            val h = token.hashCode() and Int.MAX_VALUE
            v[h % dimensions] += 1f
        }
        val norm = sqrt(v.sumOf { (it * it).toDouble() }).toFloat()
        if (norm > 0f) for (i in v.indices) v[i] /= norm
        return v
    }

    fun cosine(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 0f
        var dot = 0f
        var aa = 0f
        var bb = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            aa += a[i] * a[i]
            bb += b[i] * b[i]
        }
        return if (aa == 0f || bb == 0f) 0f else
            dot / (sqrt(aa.toDouble()).toFloat() * sqrt(bb.toDouble()).toFloat())
    }
}
