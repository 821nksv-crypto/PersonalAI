package com.personalai.mvp.internet

object WebContextBuilder {
    fun build(response: WebSearchResponse): String {
        if (response.results.isEmpty()) return "No web results were found."
        return buildString {
            append("WEB SEARCH RESULTS FOR: ").append(response.query).append("\n\n")
            response.results.forEachIndexed { i, r ->
                append("[${i + 1}] ").append(r.title).append("\n")
                append("URL: ").append(r.url).append("\n")
                append("SOURCE: ").append(r.source).append("\n")
                append("SNIPPET: ").append(r.snippet).append("\n\n")
            }
            append("Use these results as external context. Do not invent details not supported by them.")
        }
    }
}
