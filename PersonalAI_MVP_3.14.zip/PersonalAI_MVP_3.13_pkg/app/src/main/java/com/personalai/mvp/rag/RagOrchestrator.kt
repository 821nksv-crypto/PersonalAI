package com.personalai.mvp.rag

class RagOrchestrator(
    private val index: LocalVectorIndex,
    private val promptBuilder: RagPromptBuilder,
    private val llm: LocalLlmEngine
) {
    suspend fun answer(question: String, topK: Int = 5): RagAnswer {
        val results = index.search(question, topK)
        val prompt = promptBuilder.build(question, results)
        val text = llm.generate(prompt)

        val sources = results.map {
            RagSource(
                it.chunk.documentName,
                it.chunk.pageNumber,
                it.chunk.chunkIndex,
                it.score
            )
        }

        return RagAnswer(text, sources)
    }
}

interface LocalLlmEngine {
    suspend fun generate(prompt: String): String
}
