package com.personalai.mvp.documents

import androidx.lifecycle.LifecycleOwner
import com.personalai.mvp.indexing.WorkManagerIndexingObserver

class DocumentProgressBridge(private val observer: WorkManagerIndexingObserver) {
    fun observe(
        owner: LifecycleOwner,
        documentId: String,
        onUpdate: (WorkManagerIndexingObserver.ObservedWorkState) -> Unit
    ) = observer.observe(owner, documentId, onUpdate)

    fun cancel(documentId: String) = observer.cancel(documentId)
}
