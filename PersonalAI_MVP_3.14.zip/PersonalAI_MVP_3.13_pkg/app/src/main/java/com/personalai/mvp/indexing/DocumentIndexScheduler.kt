package com.personalai.mvp.indexing

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

object DocumentIndexScheduler {
    fun enqueue(context: Context, documentId: String, documentName: String, path: String) {
        val input = Data.Builder()
            .putString(DocumentIndexWorker.KEY_DOCUMENT_ID, documentId)
            .putString(DocumentIndexWorker.KEY_DOCUMENT_NAME, documentName)
            .putString(DocumentIndexWorker.KEY_DOCUMENT_PATH, path)
            .build()

        val request = OneTimeWorkRequestBuilder<DocumentIndexWorker>()
            .setInputData(input)
            .setBackoffCriteria(
                BackoffPolicy.EXPONENTIAL,
                10,
                TimeUnit.SECONDS
            )
            .build()

        WorkManager.getInstance(context)
            .enqueueUniqueWork(
                DocumentIndexWorkIdentity.uniqueName(documentId),
                ExistingWorkPolicy.REPLACE,
                request
            )
    }

    fun cancel(context: Context, documentId: String) {
        WorkManager.getInstance(context).cancelUniqueWork(DocumentIndexWorkIdentity.uniqueName(documentId))
    }
}


object DocumentIndexWorkIdentity {
    fun uniqueName(documentId: String) = "document-index-$documentId"
}
