package com.personalai.mvp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File

@Composable
fun ModelManagerScreen(
    models: List<File>,
    onRemove: (File) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Model Manager", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        if (models.isEmpty()) {
            Text("No local models installed.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(models, key = { it.absolutePath }) { model ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(model.name)
                                Text("${model.length() / (1024 * 1024)} MB")
                            }
                            TextButton(onClick = { onRemove(model) }) {
                                Text("Remove")
                            }
                        }
                    }
                }
            }
        }
    }
}
