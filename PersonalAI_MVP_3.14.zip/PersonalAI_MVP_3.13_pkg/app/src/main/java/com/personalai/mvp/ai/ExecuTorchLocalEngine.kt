package com.personalai.mvp.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.pytorch.executorch.extension.llm.LlmCallback
import org.pytorch.executorch.extension.llm.LlmGenerationConfig
import org.pytorch.executorch.extension.llm.LlmModule
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/** Real on-device ExecuTorch LLM adapter. */
class ExecuTorchLocalEngine(
    private val modelFile: File,
    private val tokenizerFile: File
) : LocalModelEngine {

    private var module: LlmModule? = null
    private var loadError: String? = null
    private val generating = AtomicBoolean(false)

    init {
        try {
            val config = org.pytorch.executorch.extension.llm.LlmModuleConfig.create()
                .modulePath(modelFile.absolutePath)
                .tokenizerPath(tokenizerFile.absolutePath)
                .temperature(0.7f)
                .modelType(org.pytorch.executorch.extension.llm.LlmModuleConfig.MODEL_TYPE_TEXT)
                .loadMode(org.pytorch.executorch.extension.llm.LlmModuleConfig.LOAD_MODE_MMAP)
                .build()
            val m = LlmModule(config)
            val status = m.load()
            if (status == 0) module = m else loadError = "ExecuTorch load error: $status"
        } catch (t: Throwable) {
            loadError = t.message ?: t.javaClass.simpleName
        }
    }

    override suspend fun generate(prompt: String): String = withContext(Dispatchers.Default) {
        val m = module ?: return@withContext "Local model could not be loaded: ${loadError ?: "unknown error"}"
        val out = StringBuilder()
        val error = AtomicReference<String?>(null)
        val done = Object()
        var finished = false

        val callback = object : LlmCallback {
            override fun onResult(token: String) {
                synchronized(done) { out.append(token) }
            }
            override fun onStats(statsJson: String) {
                synchronized(done) { finished = true; done.notifyAll() }
            }
            override fun onError(errorCode: Int, message: String) {
                synchronized(done) {
                    error.set("Inference error $errorCode: $message")
                    finished = true
                    done.notifyAll()
                }
            }
        }

        try {
            generating.set(true)
            val config = LlmGenerationConfig.create()
                .seqLen(2048)
                .maxNewTokens(512)
                .temperature(0.7f)
                .echo(false)
                .build()
            m.generate(prompt, config, callback)
            synchronized(done) {
                while (!finished && error.get() == null) done.wait(50)
            }
            error.get()?.let { return@withContext it }
            out.toString().ifBlank { "(No output generated)" }
        } catch (t: Throwable) {
            "Local inference failed: ${t.message ?: t.javaClass.simpleName}"
        } finally {
            generating.set(false)
        }
    }

    fun startStreaming(
        prompt: String,
        onToken: (String) -> Unit,
        onComplete: (String) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        val m = module
        if (m == null) {
            onError(IllegalStateException(loadError ?: "Local model is not loaded."))
            return
        }
        if (!generating.compareAndSet(false, true)) {
            onError(IllegalStateException("A generation is already running."))
            return
        }

        Thread {
            val output = StringBuilder()
            try {
                val config = LlmGenerationConfig.create()
                    .seqLen(2048)
                    .maxNewTokens(512)
                    .temperature(0.7f)
                    .echo(false)
                    .build()

                val callback = object : LlmCallback {
                    override fun onResult(token: String) {
                        output.append(token)
                        onToken(token)
                    }
                    override fun onStats(statsJson: String) {
                        onComplete(output.toString())
                    }
                    override fun onError(errorCode: Int, message: String) {
                        onError(IllegalStateException("ExecuTorch error $errorCode: $message"))
                    }
                }
                m.generate(prompt, config, callback)
            } catch (t: Throwable) {
                onError(t)
            } finally {
                generating.set(false)
            }
        }.apply { name = "personal-ai-llm" }.start()
    }

    fun stopStreaming() {
        module?.stop()
    }

    override fun isReady(): Boolean = module != null
    override fun modelName(): String = modelFile.name
}
