package com.personalai.mvp.onboarding

import android.content.Context

class PrivacySetupStore(context: Context) {
    private val prefs = context.getSharedPreferences("privacy_setup", Context.MODE_PRIVATE)

    fun isComplete(): Boolean = prefs.getBoolean(KEY_COMPLETE, false)

    fun complete() {
        prefs.edit().putBoolean(KEY_COMPLETE, true).apply()
    }

    companion object {
        private const val KEY_COMPLETE = "complete"
    }
}
