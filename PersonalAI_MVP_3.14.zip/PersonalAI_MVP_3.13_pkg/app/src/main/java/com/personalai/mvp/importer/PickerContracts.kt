package com.personalai.mvp.importer

import android.content.Intent

object PickerContracts {
    const val MIME_PDF = "application/pdf"
    const val MIME_MODEL = "application/octet-stream"

    fun pdfIntent(): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = MIME_PDF
            addCategory(Intent.CATEGORY_OPENABLE)
        }

    fun modelIntent(): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = MIME_MODEL
            addCategory(Intent.CATEGORY_OPENABLE)
        }
}
