package com.personalai.mvp.app

import com.personalai.mvp.documents.DocumentUiItem

data class RuntimeSnapshot(
    val documents: List<DocumentUiItem>,
    val installedModels: List<String>,
    val modelReady: Boolean
)
