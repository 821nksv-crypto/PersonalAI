package com.personalai.mvp.model

import android.content.Context
import com.personalai.mvp.ai.ExecuTorchLocalEngine
import com.personalai.mvp.ai.LocalModelEngine
import com.personalai.mvp.ai.UnavailableLocalEngine

/** Resolves exactly one verified, device-compatible model package for inference. */
class ModelRuntimeResolver(context: Context) {
    private val store = InstalledModelPackageStore(context.applicationContext)

    fun resolve(): ResolvedModel {
        val packages = store.list()
        if (packages.isEmpty()) return ResolvedModel.Unavailable("No installed model package.")

        val candidates = packages.map { pkg ->
            val compatibility = ModelCompatibility.check(pkg.manifest)
            if (!compatibility.compatible) return@map Candidate.Invalid(pkg, compatibility.message)
            val modelCheck = ModelVerifier.verify(pkg.modelFile, pkg.manifest)
            if (!modelCheck.verified) return@map Candidate.Invalid(pkg, modelCheck.message)
            val tokenizer = pkg.tokenizerFile
                ?: return@map Candidate.Invalid(pkg, "Tokenizer file is required for ExecuTorch runtime.")
            val tokenizerHash = pkg.manifest.tokenizerSha256
                ?: return@map Candidate.Invalid(pkg, "Tokenizer SHA-256 is missing from the model manifest.")
            val actualTokenizer = ModelVerifier.sha256(tokenizer)
            if (!actualTokenizer.equals(tokenizerHash, ignoreCase = true)) {
                return@map Candidate.Invalid(pkg, "Tokenizer SHA-256 mismatch.")
            }
            Candidate.Valid(pkg)
        }

        val valid = candidates.filterIsInstance<Candidate.Valid>()
            .sortedWith(compareByDescending<Candidate.Valid> { it.packageInfo.manifest.version }
                .thenBy { it.packageInfo.manifest.id })
            .firstOrNull()

        return if (valid != null) {
            ResolvedModel.Ready(valid.packageInfo)
        } else {
            val reason = candidates.filterIsInstance<Candidate.Invalid>()
                .joinToString("; ") { "${it.packageInfo.manifest.displayName}: ${it.reason}" }
                .ifBlank { "No compatible model package." }
            ResolvedModel.Unavailable(reason)
        }
    }

    fun createEngine(): LocalModelEngine = when (val resolved = resolve()) {
        is ResolvedModel.Ready -> ExecuTorchLocalEngine(
            resolved.packageInfo.modelFile,
            resolved.packageInfo.tokenizerFile
                ?: error("Verified runtime package has no tokenizer")
        )
        is ResolvedModel.Unavailable -> UnavailableLocalEngine(resolved.reason)
    }

    private sealed interface Candidate {
        data class Valid(val packageInfo: InstalledModelPackage) : Candidate
        data class Invalid(val packageInfo: InstalledModelPackage, val reason: String) : Candidate
    }
}

sealed interface ResolvedModel {
    data class Ready(val packageInfo: InstalledModelPackage) : ResolvedModel
    data class Unavailable(val reason: String) : ResolvedModel
}
