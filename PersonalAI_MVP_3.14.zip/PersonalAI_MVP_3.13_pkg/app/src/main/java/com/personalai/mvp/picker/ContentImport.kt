package com.personalai.mvp.picker

import android.content.Context
import android.net.Uri
import java.io.File
import java.security.MessageDigest

object ContentImport {
    fun copyToPrivateStorage(context: Context, uri: Uri, subdir: String, displayName: String): File {
        val dir = File(context.filesDir, subdir).apply { mkdirs() }
        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val target = File(dir, safeName)
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Unable to open selected file" }
            target.outputStream().use { output -> input.copyTo(output) }
        }
        return target
    }

    fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                md.update(buffer, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
