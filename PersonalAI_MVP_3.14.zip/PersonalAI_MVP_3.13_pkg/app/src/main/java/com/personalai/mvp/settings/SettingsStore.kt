package com.personalai.mvp.settings

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("personal_ai_settings", Context.MODE_PRIVATE)

    fun internetEnabled(): Boolean = prefs.getBoolean("internet_enabled", false)
    fun setInternetEnabled(value: Boolean) =
        prefs.edit().putBoolean("internet_enabled", value).apply()
}
