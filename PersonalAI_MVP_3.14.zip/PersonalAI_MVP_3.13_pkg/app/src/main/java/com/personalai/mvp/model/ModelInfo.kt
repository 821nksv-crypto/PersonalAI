package com.personalai.mvp.model

data class ModelInfo(
    val id: String,
    val name: String,
    val path: String,
    val format: String,
    val sizeBytes: Long
)
