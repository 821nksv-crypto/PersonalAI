package com.personalai.mvp.model

data class ModelManifest(
    val id: String,
    val displayName: String,
    val version: String,
    val runtime: String,
    val architecture: String,
    val fileName: String,
    val sizeBytes: Long,
    val sha256: String,
    val tokenizerFileName: String? = null,
    val tokenizerSha256: String? = null
)
