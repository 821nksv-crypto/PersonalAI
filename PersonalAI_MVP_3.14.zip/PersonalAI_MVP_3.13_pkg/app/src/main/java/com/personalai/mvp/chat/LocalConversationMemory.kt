package com.personalai.mvp.chat

import com.personalai.mvp.model.ChatMessage

class LocalConversationMemory(
    private val maxTurns: Int = 8,
    private val maxCharacters: Int = 6000
) {
    fun buildContext(messages: List<ChatMessage>): String {
        val turns = messages.filter { it.role == "user" || it.role == "assistant" }.takeLast(maxTurns)
        if (turns.isEmpty()) return ""
        val raw = turns.joinToString("\n") { "${it.role.uppercase()}: ${it.text}" }
        return if (raw.length <= maxCharacters) raw else raw.takeLast(maxCharacters)
    }

    fun compact(messages: List<ChatMessage>): String = buildContext(messages)
}
