package com.personalai.mvp.model

import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.PublicKey
import java.security.Signature
import java.security.spec.X509EncodedKeySpec

/**
 * Verifies a detached Ed25519 signature over a canonical manifest payload.
 *
 * Production builds should pin the public key in app resources/build configuration
 * and never accept a key supplied by the downloaded package.
 */
object SignedManifestVerifier {
    fun verify(
        canonicalManifest: String,
        signatureBase64: String,
        pinnedPublicKeyBase64: String
    ): Boolean {
        return try {
            val keyBytes = Base64.decode(pinnedPublicKeyBase64, Base64.DEFAULT)
            val signatureBytes = Base64.decode(signatureBase64, Base64.DEFAULT)
            val keySpec = X509EncodedKeySpec(keyBytes)
            val publicKey: PublicKey =
                KeyFactory.getInstance("Ed25519").generatePublic(keySpec)

            Signature.getInstance("Ed25519").run {
                initVerify(publicKey)
                update(canonicalManifest.toByteArray(StandardCharsets.UTF_8))
                verify(signatureBytes)
            }
        } catch (_: Throwable) {
            false
        }
    }
}
