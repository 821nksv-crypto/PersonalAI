package com.personalai.mvp.importer

import java.io.File
import com.personalai.mvp.model.AtomicModelInstaller
import com.personalai.mvp.model.ModelManifest

class ModelImportController(
    private val pipeline: ModelImportPipeline
) {
    fun import(
        source: File,
        manifest: ModelManifest,
        signatureBase64: String?,
        pinnedPublicKeyBase64: String?
    ): ImportResult {
        return try {
            val result = pipeline.import(
                source, manifest, signatureBase64, pinnedPublicKeyBase64
            )
            ImportResult.Success(result.toString())
        } catch (t: Throwable) {
            ImportResult.Failure(t.message ?: "Model installation failed")
        }
    }
}
