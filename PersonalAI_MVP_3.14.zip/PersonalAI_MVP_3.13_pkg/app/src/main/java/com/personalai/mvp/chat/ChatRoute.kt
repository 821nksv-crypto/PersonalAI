package com.personalai.mvp.chat

enum class ChatRoute {
    GENERAL_CHAT,
    DOCUMENT_QA,
    INTERNET_SEARCH
}

data class RoutedPrompt(
    val route: ChatRoute,
    val reason: String
)

class ChatRouter {
    fun route(prompt: String, hasDocuments: Boolean, internetEnabled: Boolean): RoutedPrompt {
        val p = prompt.lowercase()

        val explicitWeb = listOf(
            "search the web", "search online", "look up", "latest", "today",
            "current", "news", "on internet", "google this",
            "इंटरनेट पर", "ऑनलाइन खोज", "आज का", "ताज़ा", "नवीनतम", "खोजो"
        ).any { p.contains(it) }

        if (internetEnabled && explicitWeb) {
            return RoutedPrompt(ChatRoute.INTERNET_SEARCH, "The prompt explicitly requests current/online information.")
        }

        if (hasDocuments) {
            val documentSignals = listOf(
                "according to", "document", "pdf", "file", "page", "chapter",
                "section", "this book", "this file",
                "दस्तावेज", "पीडीएफ", "फाइल", "पेज", "अध्याय", "इसमें", "किताब", "धारा"
            )
            if (documentSignals.any { p.contains(it) }) {
                return RoutedPrompt(ChatRoute.DOCUMENT_QA, "The prompt appears to reference indexed local documents.")
            }
        }

        return if (!internetEnabled && explicitWeb) {
            RoutedPrompt(ChatRoute.GENERAL_CHAT, "Internet is disabled; answering from local knowledge instead.")
        } else {
            RoutedPrompt(ChatRoute.GENERAL_CHAT, "General local conversation.")
        }
    }
}
