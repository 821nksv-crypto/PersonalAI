package com.personalai.mvp.model

import java.io.File
import java.security.MessageDigest

object ModelVerifier {
    fun verify(file: File, manifest: ModelManifest): VerificationResult {
        if (!file.exists()) return VerificationResult(false, "Model file not found")
        if (file.length() != manifest.sizeBytes) {
            return VerificationResult(false, "Size mismatch: expected ${manifest.sizeBytes}, got ${file.length()}")
        }
        val actual = sha256(file)
        return if (actual.equals(manifest.sha256, ignoreCase = true)) {
            VerificationResult(true, "SHA-256 verified")
        } else VerificationResult(false, "SHA-256 mismatch")
    }

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}

data class VerificationResult(val verified: Boolean, val message: String)
