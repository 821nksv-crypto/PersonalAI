package com.personalai.mvp.chat

data class StreamingChatState(
    val active: Boolean = false,
    val text: String = "",
    val error: String? = null
)
