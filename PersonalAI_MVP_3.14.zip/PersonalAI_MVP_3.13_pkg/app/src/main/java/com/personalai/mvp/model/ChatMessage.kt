package com.personalai.mvp.model
data class ChatMessage(val role: String, val text: String)
