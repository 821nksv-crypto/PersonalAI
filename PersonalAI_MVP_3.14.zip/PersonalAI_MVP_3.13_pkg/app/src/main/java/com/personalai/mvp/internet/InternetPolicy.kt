package com.personalai.mvp.internet

data class InternetPolicy(
    val enabledByUser: Boolean = false,
    val sendOnlyQuery: Boolean = true
) {
    fun canSearch(): Boolean = enabledByUser && sendOnlyQuery
}
