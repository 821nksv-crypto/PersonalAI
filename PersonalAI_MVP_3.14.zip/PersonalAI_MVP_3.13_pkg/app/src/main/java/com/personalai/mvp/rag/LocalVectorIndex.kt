package com.personalai.mvp.rag

/**
 * In-memory index retained for tests and dependency compatibility.
 * Production UI uses PersistentVectorIndex.
 */
class LocalVectorIndex(private val vectorizer: LocalVectorizer = LocalVectorizer()) {
    private val chunks = mutableListOf<PageChunk>()
    fun clear() = chunks.clear()
    fun size(): Int = chunks.size
    fun add(items: List<PageChunk>) { chunks += items.map { it.copy(vector = vectorizer.embed(it.text)) } }
    fun search(query: String, limit: Int = 5): List<ScoredChunk> {
        val q = vectorizer.embed(query)
        return chunks.map { ScoredChunk(it, vectorizer.cosine(q, it.vector)) }
            .sortedByDescending { it.score }.take(limit)
    }
}
data class ScoredChunk(val chunk: PageChunk, val score: Float)
