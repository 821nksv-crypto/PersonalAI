package com.personalai.mvp.rag

class RagPromptBuilder {
    fun build(question: String, results: List<ScoredChunk>): String {
        val context = results.mapIndexed { i, r ->
            "SOURCE_${i + 1}: ${r.chunk.documentName}, page ${r.chunk.pageNumber}\n${r.chunk.text}"
        }.joinToString("\n\n")

        return """
You are a local document question-answering assistant.

Answer the user's question using the supplied document excerpts.
Do not invent facts that are not supported by the excerpts.
If the excerpts do not contain enough information, say that the document context is insufficient.
Do not invent page numbers or source names.
Keep the answer concise and useful.

QUESTION:
$question

DOCUMENT EXCERPTS:
$context

ANSWER:
""".trimIndent()
    }
}
