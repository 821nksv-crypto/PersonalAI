package com.personalai.mvp.documents

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ImportedDocumentStore(context: Context) {
    private val file = File(context.filesDir, "imported_documents.json")

    @Synchronized
    fun upsert(doc: ImportedDocument) {
        val arr = if (file.exists()) JSONArray(file.readText()) else JSONArray()
        var replaced = false
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") == doc.id) {
                arr.put(i, encode(doc))
                replaced = true
                break
            }
        }
        if (!replaced) arr.put(encode(doc))
        file.writeText(arr.toString())
    }

    fun get(id: String): ImportedDocument? = all().firstOrNull { it.id == id }

    @Synchronized
    fun remove(id: String) {
        val filtered = all().filterNot { it.id == id }
        val arr = JSONArray()
        filtered.forEach { arr.put(encode(it)) }
        file.writeText(arr.toString())
    }

    fun all(): List<ImportedDocument> {
        if (!file.exists()) return emptyList()
        val arr = JSONArray(file.readText())
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    ImportedDocument(
                        o.getString("id"),
                        o.getString("name"),
                        o.getString("path"),
                        o.getLong("sizeBytes"),
                        o.getString("sha256")
                    )
                )
            }
        }
    }

    private fun encode(d: ImportedDocument) = JSONObject().apply {
        put("id", d.id)
        put("name", d.name)
        put("path", d.path)
        put("sizeBytes", d.sizeBytes)
        put("sha256", d.sha256)
    }
}
