package com.personalai.mvp.rag

import ai.onnxruntime.*
import java.io.File
import java.nio.LongBuffer

/** On-device ONNX adapter for sentence-transformers/all-MiniLM-L6-v2 style BERT graphs. */
class OnnxMiniLmEmbedder(
    private val modelFile: File,
    private val tokenizer: BertWordPieceTokenizer,
    private val maxLength: Int = 128
) : AutoCloseable {
    private val env = OrtEnvironment.getEnvironment()
    private val session: OrtSession = env.createSession(modelFile.absolutePath, OrtSession.SessionOptions())

    fun embed(text: String): FloatArray {
        val ids = tokenizer.encode(text, maxLength)
        val inputIds = LongArray(maxLength) { ids.inputIds[it].toLong() }
        val attention = LongArray(maxLength) { ids.attentionMask[it].toLong() }
        val tokenTypes = LongArray(maxLength)

        OnnxTensor.createTensor(env, LongBuffer.wrap(inputIds), longArrayOf(1, maxLength)).use { tIds ->
            OnnxTensor.createTensor(env, LongBuffer.wrap(attention), longArrayOf(1, maxLength)).use { tMask ->
                OnnxTensor.createTensor(env, LongBuffer.wrap(tokenTypes), longArrayOf(1, maxLength)).use { tTypes ->
                    val inputs = linkedMapOf<String, OnnxTensor>(
                        "input_ids" to tIds,
                        "attention_mask" to tMask,
                        "token_type_ids" to tTypes
                    )
                    session.run(inputs).use { result ->
                        val output = result[0].value
                        val sequence = when (output) {
                            is Array<*> -> output[0] as Array<*>
                            else -> error("Unsupported ONNX embedding output type: ${output::class.java.name}")
                        }
                        val first = sequence.firstOrNull() as? FloatArray
                            ?: error("Unsupported ONNX embedding output shape")
                        val pooled = FloatArray(first.size)
                        var count = 0f
                        for (i in sequence.indices) {
                            if (i >= attention.size || attention[i] == 0L) continue
                            val row = sequence[i] as? FloatArray ?: error("Unsupported ONNX token vector")
                            for (j in row.indices) pooled[j] += row[j]
                            count += 1f
                        }
                        if (count > 0f) for (j in pooled.indices) pooled[j] /= count
                        l2Normalize(pooled)
                    }
                }
            }
        }
    }

    private fun l2Normalize(v: FloatArray): FloatArray {
        var sum = 0.0
        for (x in v) sum += x.toDouble() * x.toDouble()
        val norm = kotlin.math.sqrt(sum).toFloat()
        if (norm > 0f) for (i in v.indices) v[i] /= norm
        return v
    }

    override fun close() = session.close()
}

data class TokenizedInput(val inputIds: IntArray, val attentionMask: IntArray)

class BertWordPieceTokenizer(private val vocab: Map<String, Int>) {
    fun encode(text: String, maxLength: Int): TokenizedInput {
        require(maxLength >= 2) { "maxLength must be at least 2" }
        val cls = vocab["[CLS]"] ?: 101
        val sep = vocab["[SEP]"] ?: 102
        val unk = vocab["[UNK]"] ?: 100
        val tokens = mutableListOf<Int>()
        tokens += cls

        for (word in text.lowercase()
            .replace(Regex("[^a-z0-9']"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }) {
            for (piece in wordPiece(word)) {
                if (tokens.size >= maxLength - 1) break
                tokens += vocab[piece] ?: unk
            }
            if (tokens.size >= maxLength - 1) break
        }
        tokens += sep

        val ids = IntArray(maxLength)
        val mask = IntArray(maxLength)
        tokens.take(maxLength).forEachIndexed { i, id -> ids[i] = id; mask[i] = 1 }
        return TokenizedInput(ids, mask)
    }

    private fun wordPiece(word: String): List<String> {
        if (vocab.containsKey(word)) return listOf(word)
        val pieces = mutableListOf<String>()
        var start = 0
        while (start < word.length) {
            var end = word.length
            var found: String? = null
            while (start < end) {
                val candidate = word.substring(start, end).let { if (start == 0) it else "##$it" }
                if (vocab.containsKey(candidate)) { found = candidate; break }
                end--
            }
            if (found == null) return listOf("[UNK]")
            pieces += found
            start = end
        }
        return pieces
    }

    companion object {
        fun fromVocabFile(file: File): BertWordPieceTokenizer {
            val vocab = linkedMapOf<String, Int>()
            file.forEachLine { line ->
                if (line.isNotEmpty() && !vocab.containsKey(line)) vocab[line] = vocab.size
            }
            require(vocab.containsKey("[UNK]") && vocab.containsKey("[CLS]") && vocab.containsKey("[SEP]")) {
                "Invalid BERT vocabulary: required special tokens are missing"
            }
            return BertWordPieceTokenizer(vocab)
        }
    }
}
