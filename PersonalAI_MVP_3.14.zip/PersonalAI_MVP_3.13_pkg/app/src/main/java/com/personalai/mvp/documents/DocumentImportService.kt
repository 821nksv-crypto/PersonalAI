package com.personalai.mvp.documents

import android.content.Context
import android.net.Uri
import com.personalai.mvp.integration.ImportEvent
import com.personalai.mvp.integration.ImportEventStore
import com.personalai.mvp.integration.ImportLifecycle
import com.personalai.mvp.picker.ContentImport
import java.util.UUID

class DocumentImportService(private val context: Context) {
    private val events = ImportEventStore(context)
    private val importedStore = ImportedDocumentStore(context)

    fun importSelectedPdf(uri: Uri, displayName: String): ImportedDocument {
        require(displayName.lowercase().endsWith(".pdf")) { "Selected file is not a PDF." }
        val id = UUID.randomUUID().toString()
        events.append(ImportEvent(id, displayName, ImportLifecycle.SELECTED))
        val file = ContentImport.copyToPrivateStorage(
            context, uri, "documents", "${id}_$displayName"
        )
        val sha = ContentImport.sha256(file)
        events.append(ImportEvent(id, displayName, ImportLifecycle.COPIED_PRIVATE, sha))
        val result = ImportedDocument(id, displayName, file.absolutePath, file.length(), sha)
        importedStore.upsert(result)
        return result
    }

    fun markRegistered(doc: ImportedDocument) =
        events.append(ImportEvent(doc.id, doc.name, ImportLifecycle.REGISTERED))

    fun markQueued(doc: ImportedDocument) =
        events.append(ImportEvent(doc.id, doc.name, ImportLifecycle.QUEUED))
}

data class ImportedDocument(
    val id: String,
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val sha256: String
)
