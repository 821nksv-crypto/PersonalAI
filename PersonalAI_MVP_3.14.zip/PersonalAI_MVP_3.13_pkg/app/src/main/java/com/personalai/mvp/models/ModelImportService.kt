package com.personalai.mvp.models

import android.content.Context
import android.net.Uri
import com.personalai.mvp.importer.ImportResult
import com.personalai.mvp.importer.ModelImportPipeline
import com.personalai.mvp.integration.ImportEvent
import com.personalai.mvp.integration.ImportEventStore
import com.personalai.mvp.integration.ImportLifecycle
import com.personalai.mvp.model.AtomicModelInstaller
import com.personalai.mvp.model.InstalledModelPackageStore
import java.io.File
import java.util.UUID

class ModelImportService(private val context: Context) {
    private val events = ImportEventStore(context)
    private val library = ModelLibraryController(context)
    private val pending = PendingModelPairStore(context)

    fun copySelectedPair(modelUri: Uri, modelName: String, manifestUri: Uri, manifestName: String, tokenizerUri: Uri? = null, tokenizerName: String? = null): SelectedModelPair {
        val id = UUID.randomUUID().toString()
        events.append(ImportEvent(id, modelName, ImportLifecycle.SELECTED))
        val model = com.personalai.mvp.picker.ContentImport.copyToPrivateStorage(context, modelUri, "models/incoming", modelName)
        val manifest = com.personalai.mvp.picker.ContentImport.copyToPrivateStorage(context, manifestUri, "models/incoming", manifestName)
        val tokenizer = if (tokenizerUri != null && tokenizerName != null) com.personalai.mvp.picker.ContentImport.copyToPrivateStorage(context, tokenizerUri, "models/incoming", tokenizerName) else null
        events.append(ImportEvent(id, modelName, ImportLifecycle.COPIED_PRIVATE))
        val pair = SelectedModelPair(id, model, manifest, tokenizer)
        pending.save(pair)
        return pair
    }

    fun markVerifying(pair: SelectedModelPair) = events.append(ImportEvent(pair.id, pair.model.name, ImportLifecycle.VERIFYING))
    fun markInstalled(pair: SelectedModelPair) = events.append(ImportEvent(pair.id, pair.model.name, ImportLifecycle.INSTALLED))

    fun verifyAndInstall(pair: SelectedModelPair): ImportResult {
        return try {
            markVerifying(pair)
            val manifestJson = pair.manifest.readText()
            val pipeline = ModelImportPipeline(AtomicModelInstaller(File(context.filesDir, "models"), InstalledModelPackageStore(context)))
            val result = VerifiedModelImportController(pipeline, library).importFromManifest(
                pair.model, manifestJson, null, null, pair.tokenizer
            )
            when (result) {
                is ImportResult.Success -> { markInstalled(pair); pending.clear(); result }
                else -> result
            }
        } catch (t: Throwable) {
            ImportResult.Failure(t.message ?: "Model verification/installation failed")
        }
    }
}

data class SelectedModelPair(val id: String, val model: File, val manifest: File, val tokenizer: File? = null)
