package com.personalai.mvp.appstate

import android.content.Context
import com.personalai.mvp.documents.DocumentLibraryController
import com.personalai.mvp.models.ModelLibraryController

class AppCoordinator(context: Context) {
    private val appContext = context.applicationContext

    val state = AppStateRepository(appContext)
    val documents = DocumentLibraryController(appContext)
    val models = ModelLibraryController(appContext)
}
