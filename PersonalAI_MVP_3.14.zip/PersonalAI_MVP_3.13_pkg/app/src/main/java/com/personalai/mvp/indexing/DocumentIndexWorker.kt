package com.personalai.mvp.indexing

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.Data
import com.personalai.mvp.rag.PdfTextExtractor
import com.personalai.mvp.rag.PersistentVectorIndex
import java.io.File

/**
 * Resumable background PDF indexing worker.
 *
 * The worker reports page-level progress and returns retry on transient I/O failures.
 * The document remains app-private throughout processing.
 */
private val INDEXING_STATUS_VERSION = 1

class DocumentIndexWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    private val progressReporter by lazy { IndexingProgressReporter(applicationContext) }


    override suspend fun doWork(): Result {
        val documentId = inputData.getString(KEY_DOCUMENT_ID) ?: return Result.failure()
        val documentName = inputData.getString(KEY_DOCUMENT_NAME) ?: documentId
        val path = inputData.getString(KEY_DOCUMENT_PATH) ?: return Result.failure()

        return try {
            progressReporter.queued(documentId)
            setProgress(Data.Builder()
                .putString(KEY_STATUS, "RUNNING")
                .putInt(KEY_PROGRESS, 0)
                .putString("documentId", documentId)
                .putString("documentName", documentName)
                .build())

            val file = File(path)
            if (!file.exists()) {
                progressReporter.failed(documentId, "Document file does not exist")
                return Result.failure(Data.Builder().putString("error", "Document file does not exist").build())
            }

            val extractor = PdfTextExtractor(applicationContext)
            val index = PersistentVectorIndex(applicationContext)
            val pages = extractor.extractPages(file)
            if (isStopped) {
                progressReporter.cancelled(documentId)
                return Result.failure(Data.Builder().putString("error", "Indexing cancelled").build())
            }

            // Build the replacement off-index. The old document remains available until commit.
            index.replaceDocumentFromPages(documentId, documentName, pages) { processed, total ->
                if (isStopped) throw IndexingCancelledException()
                progressReporter.running(documentId, processed, total)
                setProgress(Data.Builder()
                    .putString(KEY_STATUS, "RUNNING")
                    .putInt(KEY_PROGRESS, ((processed.toDouble() / total.coerceAtLeast(1) * 100.0)).toInt())
                    .putInt("processedPages", processed)
                    .putInt("totalPages", total)
                    .putString("documentId", documentId)
                    .build())
            }

            progressReporter.completed(documentId, pages.size)
            setProgress(Data.Builder()
                .putString(KEY_STATUS, "COMPLETED")
                .putInt(KEY_PROGRESS, 100)
                .putInt("processedPages", pages.size)
                .putInt("totalPages", pages.size)
                .putString("documentId", documentId)
                .build())

            Result.success()
        } catch (t: IndexingCancelledException) {
            progressReporter.cancelled(documentId)
            Result.failure(Data.Builder().putString("error", "Indexing cancelled").build())
        } catch (t: java.io.IOException) {
            progressReporter.failed(documentId, t.message ?: "I/O failure")
            Result.retry()
        } catch (t: Throwable) {
            progressReporter.failed(documentId, t.message ?: t.javaClass.simpleName)
            Result.failure(
                Data.Builder()
                    .putString("status", "FAILED")
                    .putString("error", t.message ?: t.javaClass.simpleName)
                    .build()
            )
        }
    }

    private class IndexingCancelledException : RuntimeException()

    companion object {
        const val KEY_DOCUMENT_ID = "documentId"
        const val KEY_DOCUMENT_NAME = "documentName"
        const val KEY_DOCUMENT_PATH = "documentPath"
        const val KEY_STATUS = "status"
        const val KEY_PROGRESS = "progress"
    }
}
