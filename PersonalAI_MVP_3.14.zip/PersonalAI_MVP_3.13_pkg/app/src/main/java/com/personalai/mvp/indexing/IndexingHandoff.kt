package com.personalai.mvp.indexing

data class IndexingHandoff(
    val documentId: String,
    val documentName: String,
    val documentPath: String
)
