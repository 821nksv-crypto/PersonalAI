package com.personalai.mvp.rag

import android.content.Context
import android.net.Uri
import java.io.File
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper

class PdfTextExtractor(private val context: Context) {
    init { PDFBoxResourceLoader.init(context.applicationContext) }

    fun extract(uri: Uri, displayName: String): List<DocumentChunk> {
        val input = context.contentResolver.openInputStream(uri)
            ?: error("Unable to open selected PDF")
        return input.use { stream ->
            PDDocument.load(stream).use { document ->
                extractDocument(document, displayName)
            }
        }
    }

    fun extractPages(file: File): List<String> {
        require(file.isFile) { "PDF file does not exist: ${file.absolutePath}" }
        return PDDocument.load(file).use { document ->
            val stripper = PDFTextStripper()
            buildList {
                for (page in 1..document.numberOfPages) {
                    stripper.startPage = page
                    stripper.endPage = page
                    add(stripper.getText(document).trim())
                }
            }
        }
    }

    private fun extractDocument(document: PDDocument, displayName: String): List<DocumentChunk> {
        val stripper = PDFTextStripper()
        val chunks = mutableListOf<DocumentChunk>()
        for (page in 1..document.numberOfPages) {
            stripper.startPage = page
            stripper.endPage = page
            val text = stripper.getText(document).trim()
            if (text.isBlank()) continue
            text.chunked(1200).forEachIndexed { idx, piece ->
                chunks += DocumentChunk(
                    documentName = displayName,
                    pageNumber = page,
                    chunkIndex = idx,
                    text = piece
                )
            }
        }
        if (chunks.isEmpty()) error("PDF contains no extractable text.")
        return chunks
    }
}
