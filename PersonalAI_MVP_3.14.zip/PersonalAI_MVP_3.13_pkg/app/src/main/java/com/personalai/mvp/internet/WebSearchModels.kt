package com.personalai.mvp.internet

data class WebSearchResult(
    val title: String,
    val url: String,
    val snippet: String,
    val source: String
)

data class WebSearchResponse(
    val query: String,
    val results: List<WebSearchResult>
)
