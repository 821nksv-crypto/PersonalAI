package com.personalai.mvp.app

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.MaterialTheme
import com.personalai.mvp.memory.EncryptedMemoryStore
import com.personalai.mvp.rag.EmbeddingModelImportService
import com.personalai.mvp.documents.DocumentImportService
import com.personalai.mvp.models.ModelImportService
import com.personalai.mvp.models.SelectedModelPair
import com.personalai.mvp.shell.PersonalAiAppShell
import kotlinx.coroutines.delay

class PersonalAiHostActivity : ComponentActivity() {
    private lateinit var runtime: AppRuntime

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        handleSelectedPdf(uri)
    }

    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        pendingModelUri = uri
        if (pendingManifestUri == null) manifestPicker.launch(arrayOf("application/json", "text/json", "*/*")) else maybeHandleModelPair()
    }

    private val manifestPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        pendingManifestUri = uri
        val requiresTokenizer = runCatching {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                org.json.JSONObject(reader.readText()).optString("tokenizerFileName").isNotBlank()
            } ?: false
        }.getOrDefault(false)
        if (requiresTokenizer) {
            tokenizerPicker.launch(arrayOf("application/octet-stream", "text/plain", "*/*"))
        } else {
            maybeHandleModelPair()
        }
    }

    private val tokenizerPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        pendingTokenizerUri = uri
        maybeHandleModelPair()
    }

    private val embeddingModelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        pendingEmbeddingModelUri = uri
        if (pendingEmbeddingManifestUri == null) embeddingManifestPicker.launch(arrayOf("application/json", "text/json", "*/*")) else maybeHandleEmbeddingPair()
    }

    private val embeddingManifestPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        pendingEmbeddingManifestUri = uri
        embeddingVocabPicker.launch(arrayOf("text/plain", "application/octet-stream", "*/*"))
    }

    private val embeddingVocabPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        pendingEmbeddingVocabUri = uri
        maybeHandleEmbeddingPair()
    }

    private var pendingModelUri: Uri? = null
    private var pendingManifestUri: Uri? = null
    private var pendingTokenizerUri: Uri? = null
    private var pendingEmbeddingModelUri: Uri? = null
    private var pendingEmbeddingManifestUri: Uri? = null
    private var pendingEmbeddingVocabUri: Uri? = null
    private val documentImportService by lazy { DocumentImportService(this) }
    private val modelImportService by lazy { ModelImportService(this) }
    private val embeddingImportService by lazy { EmbeddingModelImportService(this) }
    private val memoryStore by lazy { EncryptedMemoryStore(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runtime = AppRuntime(this)

        setContent {
            MaterialTheme {
                val coordinator = runtime.coordinator
                var documents by remember { mutableStateOf(coordinator.documents.items()) }
                var installedModels by remember { mutableStateOf(coordinator.models.installed()) }
                var embeddingStatus by remember { mutableStateOf(embeddingImportService.status()) }
                var requiresReindex by remember { mutableStateOf(coordinator.documents.requiresReindex()) }

                LaunchedEffect(Unit) {
                    while (true) {
                        coordinator.documents.refreshIndexingState()
                        documents = coordinator.documents.items()
                        installedModels = coordinator.models.installed()
                        embeddingStatus = embeddingImportService.status()
                        requiresReindex = coordinator.documents.requiresReindex()
                        delay(750)
                    }
                }

                PersonalAiAppShell(
                    appState = coordinator.state,
                    documents = documents,
                    installedModels = installedModels,
                    modelReady = installedModels.isNotEmpty(),
                    memoryEnabled = memoryStore.isEnabled(),
                    onImportPdf = { pdfPicker.launch(arrayOf("application/pdf")) },
                    onCancelIndexing = coordinator.documents::cancel,
                    onRetryIndexing = { coordinator.documents.retry(it, null) },
                    requiresReindex = requiresReindex,
                    onReindexAll = { coordinator.documents.reindexAll() },
                    onDeleteDocument = { coordinator.documents.delete(it, null) },
                    onImportModel = {
                        pendingModelUri = null
                        pendingManifestUri = null
                        pendingTokenizerUri = null
                        modelPicker.launch(arrayOf("application/octet-stream", "application/x-pte", "*/*"))
                    },
                    onRemoveModel = coordinator.models::remove,
                    onClearMemory = { memoryStore.clear() },
                    onMemoryChanged = { enabled ->
                        memoryStore.setEnabled(enabled)
                        coordinator.state.setMemoryEnabled(enabled)
                    },
                    embeddingStatus = embeddingStatus,
                    onImportEmbedding = {
                        pendingEmbeddingModelUri = null
                        pendingEmbeddingManifestUri = null
                        pendingEmbeddingVocabUri = null
                        embeddingModelPicker.launch(arrayOf("application/onnx", "application/octet-stream", "*/*"))
                    },
                    onRemoveEmbedding = {
                        com.personalai.mvp.rag.EmbeddingModelInstaller(this).remove()
                        embeddingStatus = embeddingImportService.status()
                        Toast.makeText(this, "Neural embedding removed. Re-index documents to use the baseline.", Toast.LENGTH_LONG).show()
                    },
                    chatContent = {
                        com.personalai.mvp.chat.ChatHostScreen(
                            modelReady = installedModels.isNotEmpty()
                        )
                    }
                )
            }
        }
    }

    private fun handleSelectedPdf(uri: Uri) {
        val name = displayName(uri) ?: "selected.pdf"
        try {
            val imported = documentImportService.importSelectedPdf(uri, name)
            runtime.coordinator.documents.registerImported(imported.id, imported.name, imported.path)
            documentImportService.markRegistered(imported)
            documentImportService.markQueued(imported)
        } catch (t: Throwable) {
            Toast.makeText(this, "PDF import failed: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun maybeHandleModelPair() {
        val modelUri = pendingModelUri ?: return
        val manifestUri = pendingManifestUri ?: return
        // Tokenizer is optional for manifests that do not declare one.
        handleSelectedModelPair(modelUri, manifestUri, pendingTokenizerUri)
    }

    private fun handleSelectedModelPair(modelUri: Uri, manifestUri: Uri, tokenizerUri: Uri?) {
        val modelName = displayName(modelUri) ?: "model.pte"
        val manifestName = displayName(manifestUri) ?: "manifest.json"
        val tokenizerName = tokenizerUri?.let { displayName(it) ?: "tokenizer.model" }
        try {
            val pair: SelectedModelPair = modelImportService.copySelectedPair(
                modelUri, modelName, manifestUri, manifestName, tokenizerUri, tokenizerName
            )
            val result = modelImportService.verifyAndInstall(pair)
            when (result) {
                is com.personalai.mvp.importer.ImportResult.Success ->
                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                is com.personalai.mvp.importer.ImportResult.Failure ->
                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show()
                com.personalai.mvp.importer.ImportResult.Cancelled ->
                    Toast.makeText(this, "Model import cancelled", Toast.LENGTH_SHORT).show()
            }
        } catch (t: Throwable) {
            Toast.makeText(this, "Model import failed: ${t.message}", Toast.LENGTH_LONG).show()
        } finally {
            pendingModelUri = null
            pendingManifestUri = null
            pendingTokenizerUri = null
        }
    }

    private fun maybeHandleEmbeddingPair() {
        val model = pendingEmbeddingModelUri ?: return
        val manifest = pendingEmbeddingManifestUri ?: return
        val vocab = pendingEmbeddingVocabUri ?: return
        val result = embeddingImportService.importSelectedPackage(model, vocab, manifest)
        when (result) {
            is EmbeddingModelImportService.Result.Success -> Toast.makeText(this, result.message + ". Existing RAG index will require re-indexing.", Toast.LENGTH_LONG).show()
            is EmbeddingModelImportService.Result.Failure -> Toast.makeText(this, "Embedding import failed: ${result.message}", Toast.LENGTH_LONG).show()
        }
        pendingEmbeddingModelUri = null
        pendingEmbeddingManifestUri = null
        pendingEmbeddingVocabUri = null
    }

    private fun displayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }
}
