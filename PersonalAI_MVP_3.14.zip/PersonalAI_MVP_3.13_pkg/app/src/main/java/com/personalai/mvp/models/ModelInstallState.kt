package com.personalai.mvp.models

data class ModelInstallState(
    val name: String = "",
    val status: Status = Status.IDLE,
    val message: String = ""
) {
    enum class Status { IDLE, VERIFYING, INSTALLING, INSTALLED, FAILED }
}
