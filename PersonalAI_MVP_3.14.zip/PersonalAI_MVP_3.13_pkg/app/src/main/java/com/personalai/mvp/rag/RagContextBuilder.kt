package com.personalai.mvp.rag

class RagContextBuilder {
    fun build(results: List<ScoredChunk>): String =
        results.filter { it.score > 0f }.joinToString("\n\n") {
            "[Source: ${it.chunk.documentName}, page ${it.chunk.pageNumber}]\n${it.chunk.text}"
        }
}
