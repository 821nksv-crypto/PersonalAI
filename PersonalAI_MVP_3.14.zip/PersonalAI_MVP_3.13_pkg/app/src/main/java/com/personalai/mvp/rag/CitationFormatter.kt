package com.personalai.mvp.rag

/**
 * App-owned citation rendering. The model never controls document names or page numbers.
 */
object CitationFormatter {
    fun format(sources: List<RagSource>): String =
        sources.mapIndexed { i, s ->
            "[${i + 1}] ${s.documentName}, p.${s.pageNumber}"
        }.distinct().joinToString("  ")

    fun appendToAnswer(answer: String, sources: List<RagSource>): String {
        if (answer.isBlank() || sources.isEmpty()) return answer
        val citations = format(sources)
        if (citations.isBlank()) return answer
        return answer.trimEnd() + "\n\nSources: " + citations
    }
}
