package com.personalai.mvp.indexing

data class IndexingState(
    val documentId: String,
    val documentName: String,
    val processedPages: Int = 0,
    val totalPages: Int = 0,
    val status: Status = Status.QUEUED,
    val error: String? = null
) {
    enum class Status { QUEUED, RUNNING, COMPLETED, FAILED, CANCELLED }
}
