package com.personalai.mvp.documents

import android.content.Context
import com.personalai.mvp.catalog.DocumentCatalogStore
import com.personalai.mvp.indexing.IndexingStateRepository
import com.personalai.mvp.indexing.DocumentIndexScheduler
import com.personalai.mvp.rag.IndexHealth
import com.personalai.mvp.rag.PersistentVectorIndex
import java.io.File

class DocumentLibraryController(context: Context) {
    private val catalog = DocumentCatalogStore(context)
    private val indexing = IndexingStateRepository(context)
    private val appContext = context.applicationContext

    fun items(): List<DocumentUiItem> {
        val indexStates = indexing.states.value.associateBy { it.documentId }
        return catalog.list().map { item ->
            val s = indexStates[item.id]
            if (s == null) item
            else item.copy(status = s.status, progress = s.progress)
        }
    }

    fun refreshIndexingState() = indexing.refresh()

    fun requiresReindex(): Boolean =
        PersistentVectorIndex(appContext).health() == IndexHealth.REINDEX_REQUIRED

    fun reindexAll() {
        imported.all().forEach { doc ->
            catalog.upsert(DocumentUiItem(doc.id, doc.name, "QUEUED", 0))
            DocumentIndexScheduler.enqueue(appContext, doc.id, doc.name, doc.path)
        }
        indexing.refresh()
    }

    fun registerImported(id: String, name: String, path: String) {
        catalog.upsert(DocumentUiItem(id, name, "QUEUED", 0))
        DocumentIndexScheduler.enqueue(appContext, id, name, path)
    }

    fun update(item: DocumentUiItem) = catalog.upsert(item)

    private val imported = ImportedDocumentStore(appContext)

    fun cancel(id: String) {
        DocumentIndexScheduler.cancel(appContext, id)
        val existing = catalog.list().firstOrNull { it.id == id }
        if (existing != null) catalog.upsert(existing.copy(status = "CANCELLED"))
    }

    fun retry(item: DocumentUiItem, path: String?) {
        val resolvedPath = path ?: imported.get(item.id)?.path
            ?: throw IllegalStateException("Document file is unavailable")
        catalog.upsert(item.copy(status = "QUEUED", progress = 0))
        indexing.refresh()
        DocumentIndexScheduler.enqueue(appContext, item.id, item.name, resolvedPath)
    }

    fun delete(id: String, path: String?) {
        DocumentIndexScheduler.cancel(appContext, id)
        val resolvedPath = path ?: imported.get(id)?.path
        resolvedPath?.let { File(it).delete() }
        imported.remove(id)
        indexing.refresh()
        catalog.remove(id)
    }
}
