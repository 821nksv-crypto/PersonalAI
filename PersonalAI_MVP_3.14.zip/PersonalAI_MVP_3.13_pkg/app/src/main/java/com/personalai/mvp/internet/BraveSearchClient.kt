package com.personalai.mvp.internet

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

class BraveSearchClient(
    private val apiKey: String
) : WebSearchClient {
    override suspend fun search(query: String, maxResults: Int): WebSearchResponse =
        withContext(Dispatchers.IO) {
            require(apiKey.isNotBlank()) { "Brave Search API key is not configured." }
            val q = URLEncoder.encode(query, "UTF-8")
            val url = URL("https://api.search.brave.com/res/v1/web/search?q=$q&count=${maxResults.coerceIn(1, 10)}")
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "GET"
            c.connectTimeout = 12000
            c.readTimeout = 12000
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("X-Subscription-Token", apiKey)
            try {
                val code = c.responseCode
                if (code !in 200..299) throw IllegalStateException("Brave Search HTTP $code")
                val root = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val web = root.optJSONObject("web")
                val arr = web?.optJSONArray("results") ?: org.json.JSONArray()
                val results = buildList {
                    for (i in 0 until minOf(arr.length(), maxResults)) {
                        val o = arr.getJSONObject(i)
                        add(WebSearchResult(
                            title = o.optString("title"),
                            url = o.optString("url"),
                            snippet = o.optString("description"),
                            source = o.optString("profile", o.optString("url"))
                        ))
                    }
                }
                WebSearchResponse(query, results)
            } finally {
                c.disconnect()
            }
        }
}
