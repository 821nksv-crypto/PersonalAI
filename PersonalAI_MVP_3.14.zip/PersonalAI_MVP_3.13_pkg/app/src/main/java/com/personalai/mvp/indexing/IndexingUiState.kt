package com.personalai.mvp.indexing

import androidx.work.WorkInfo

data class IndexingUiState(
    val running: Boolean = false,
    val progress: Int = 0,
    val status: String = "Idle",
    val error: String? = null
)

fun WorkInfo?.toIndexingUiState(): IndexingUiState {
    if (this == null) return IndexingUiState()
    val processed = progress.getInt("processedPages", 0)
    val total = progress.getInt("totalPages", 0)
    val pct = if (total > 0) ((processed * 100) / total).coerceIn(0, 100) else 0
    return when (state) {
        WorkInfo.State.RUNNING -> IndexingUiState(true, pct, "Indexing $processed/$total pages")
        WorkInfo.State.ENQUEUED -> IndexingUiState(true, pct, "Queued")
        WorkInfo.State.SUCCEEDED -> IndexingUiState(false, 100, "Completed")
        WorkInfo.State.FAILED -> IndexingUiState(false, pct, "Failed", outputData.getString("error"))
        WorkInfo.State.CANCELLED -> IndexingUiState(false, pct, "Cancelled")
        else -> IndexingUiState(false, pct, state.name)
    }
}
