package com.personalai.mvp.documents

import android.content.Context
import android.net.Uri
import com.personalai.mvp.picker.ContentImport
import java.io.File
import java.util.UUID

class SelectedPdfImporter(private val context: Context) {
    fun import(uri: Uri, displayName: String): ImportedPdf {
        require(displayName.lowercase().endsWith(".pdf")) { "Please select a PDF file." }
        val id = UUID.randomUUID().toString()
        val file = ContentImport.copyToPrivateStorage(
            context,
            uri,
            "documents",
            "${id}_${displayName}"
        )
        return ImportedPdf(id, displayName, file.absolutePath, file.length(), ContentImport.sha256(file))
    }
}

data class ImportedPdf(
    val id: String,
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val sha256: String
)
