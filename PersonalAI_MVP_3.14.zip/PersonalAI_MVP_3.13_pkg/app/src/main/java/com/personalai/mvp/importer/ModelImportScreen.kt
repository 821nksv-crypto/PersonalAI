package com.personalai.mvp.importer

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ModelImportScreen(
    installedModels: List<String>,
    onImport: () -> Unit,
    onRemove: (String) -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Local Models", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
            Text("Import Local Model")
        }

        if (installedModels.isEmpty()) {
            Text("No local models installed.")
        } else {
            installedModels.forEach { model ->
                ListItem(
                    headlineContent = { Text(model) },
                    trailingContent = {
                        TextButton(onClick = { onRemove(model) }) {
                            Text("Remove")
                        }
                    }
                )
            }
        }
    }
}
