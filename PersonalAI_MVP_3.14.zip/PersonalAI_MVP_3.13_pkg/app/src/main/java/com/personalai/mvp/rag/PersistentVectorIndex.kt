package com.personalai.mvp.rag

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class PersistentVectorIndex(
    context: Context,
    private val runtime: EmbeddingRuntime = EmbeddingModelResolver(context).resolve()
) {
    private val file = java.io.File(context.filesDir, "rag_index.json")
    private val embeddingManifest: EmbeddingModelManifest = runtime.manifest
    private val items = mutableListOf<PageChunk>()
    private var storedFingerprint: String? = null
    private var health: IndexHealth = IndexHealth.EMPTY

    init { load() }

    fun clear() {
        items.clear()
        storedFingerprint = embeddingManifest.fingerprint()
        health = IndexHealth.EMPTY
        save()
    }

    fun size(): Int = items.size
    fun health(): IndexHealth = health
    fun requiresReindex(): Boolean = health == IndexHealth.REINDEX_REQUIRED
    fun embeddingFingerprint(): String? = storedFingerprint

    fun removeDocument(documentId: String) {
        if (health == IndexHealth.REINDEX_REQUIRED) return
        items.removeAll { it.documentId == documentId }
        health = if (items.isEmpty()) IndexHealth.EMPTY else IndexHealth.READY
        save()
    }

    fun documentIds(): Set<String> = items.map { it.documentId }.toSet()

    fun add(chunks: List<PageChunk>) {
        ensureWritable()
        items += chunks.map { it.copy(vector = runtime.embed(it.text)) }
        health = if (items.isEmpty()) IndexHealth.EMPTY else IndexHealth.READY
        storedFingerprint = embeddingManifest.fingerprint()
        save()
    }

    @Synchronized
    fun addPage(documentId: String, documentName: String, pageNumber: Int, text: String) {
        ensureWritable()
        items.removeAll { it.documentId == documentId && it.pageNumber == pageNumber }
        text.chunked(1200).filter { it.isNotBlank() }.forEachIndexed { chunkIndex, piece ->
            items += PageChunk(documentId, documentName, pageNumber, chunkIndex, piece, runtime.embed(piece))
        }
        health = if (items.isEmpty()) IndexHealth.EMPTY else IndexHealth.READY
        storedFingerprint = embeddingManifest.fingerprint()
        save()
    }

    /**
     * Rebuilds one document off-index and commits it in a single atomic save.
     * Existing vectors remain usable until every page has been extracted and embedded.
     * Cancellation/failure before commit therefore leaves the previous index intact.
     */
    @Synchronized
    fun replaceDocumentFromPages(
        documentId: String,
        documentName: String,
        pages: List<String>,
        onPageEmbedded: ((Int, Int) -> Unit)? = null
    ) {
        val rebuilt = mutableListOf<PageChunk>()
        pages.forEachIndexed { pageIndex, pageText ->
            pageText.chunked(1200).filter { it.isNotBlank() }.forEachIndexed { chunkIndex, piece ->
                rebuilt += PageChunk(
                    documentId, documentName, pageIndex + 1, chunkIndex, piece, runtime.embed(piece)
                )
            }
            onPageEmbedded?.invoke(pageIndex + 1, pages.size)
        }

        val retained = items.filterNot { it.documentId == documentId }
        val committed = retained + rebuilt
        saveSnapshot(committed, embeddingManifest.fingerprint())
        items.clear()
        items.addAll(committed)
        storedFingerprint = embeddingManifest.fingerprint()
        health = if (items.isEmpty()) IndexHealth.EMPTY else IndexHealth.READY
    }

    fun search(query: String, limit: Int = 5, documentIds: Set<String>? = null): List<ScoredChunk> {
        if (health == IndexHealth.REINDEX_REQUIRED || health == IndexHealth.CORRUPTED) return emptyList()
        val q = runtime.embed(query)
        return items.asSequence()
            .filter { documentIds == null || it.documentId in documentIds }
            .map { ScoredChunk(it, cosine(q, it.vector)) }
            .sortedByDescending { it.score }
            .take(limit)
            .toList()
    }

    private fun cosine(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 0f
        var dot = 0f
        var aa = 0f
        var bb = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            aa += a[i] * a[i]
            bb += b[i] * b[i]
        }
        return if (aa == 0f || bb == 0f) 0f else
            dot / (kotlin.math.sqrt(aa.toDouble()).toFloat() * kotlin.math.sqrt(bb.toDouble()).toFloat())
    }

    private fun ensureWritable() {
        if (health == IndexHealth.REINDEX_REQUIRED || health == IndexHealth.CORRUPTED) {
            throw IllegalStateException("Embedding configuration changed; re-index documents before writing to the vector index")
        }
    }

    private fun save() {
        saveSnapshot(items.toList(), embeddingManifest.fingerprint())
    }

    private fun saveSnapshot(snapshot: List<PageChunk>, fingerprint: String) {
        val root = JSONObject().apply {
            put("schemaVersion", 2)
            put("embeddingFingerprint", embeddingManifest.fingerprint())
            put("embeddingName", embeddingManifest.name)
            put("embeddingVersion", embeddingManifest.version)
            put("embeddingDimension", embeddingManifest.dimension)
            put("items", JSONArray().also { a ->
                snapshot.forEach { c ->
                    a.put(JSONObject().apply {
                        put("documentId", c.documentId)
                        put("documentName", c.documentName)
                        put("pageNumber", c.pageNumber)
                        put("chunkIndex", c.chunkIndex)
                        put("text", c.text)
                        put("vector", JSONArray(c.vector.map { it.toDouble() }))
                    })
                }
            })
        }
        val temp = java.io.File(file.parentFile, file.name + ".tmp")
        temp.writeText(root.toString())
        try {
            java.nio.file.Files.move(
                temp.toPath(),
                file.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                java.nio.file.StandardCopyOption.ATOMIC_MOVE
            )
        } catch (atomicFailure: java.nio.file.AtomicMoveNotSupportedException) {
            java.nio.file.Files.move(
                temp.toPath(),
                file.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING
            )
        } catch (t: Throwable) {
            temp.delete()
            throw java.io.IOException("Could not activate rebuilt RAG index", t)
        }
    }

    private fun load() {
        if (!file.exists()) {
            storedFingerprint = embeddingManifest.fingerprint()
            health = IndexHealth.EMPTY
            return
        }
        runCatching {
            val raw = JSONObject(file.readText())
            val schema = raw.optInt("schemaVersion", 0)
            if (schema < 2) {
                storedFingerprint = null
                health = IndexHealth.REINDEX_REQUIRED
                return
            }
            storedFingerprint = raw.optString("embeddingFingerprint", null)
            if (storedFingerprint != embeddingManifest.fingerprint()) {
                health = IndexHealth.REINDEX_REQUIRED
                return
            }
            val a = raw.getJSONArray("items")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val v = o.getJSONArray("vector")
                if (v.length() != embeddingManifest.dimension) {
                    health = IndexHealth.CORRUPTED
                    items.clear()
                    return
                }
                val vector = FloatArray(v.length()) { j -> v.getDouble(j).toFloat() }
                items += PageChunk(
                    o.getString("documentId"), o.getString("documentName"),
                    o.getInt("pageNumber"), o.getInt("chunkIndex"), o.getString("text"), vector
                )
            }
            health = if (items.isEmpty()) IndexHealth.EMPTY else IndexHealth.READY
        }.onFailure {
            items.clear()
            health = IndexHealth.CORRUPTED
        }
    }
}
