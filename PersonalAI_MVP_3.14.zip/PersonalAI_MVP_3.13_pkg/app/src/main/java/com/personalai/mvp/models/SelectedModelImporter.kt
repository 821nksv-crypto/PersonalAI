package com.personalai.mvp.models

import android.content.Context
import android.net.Uri
import com.personalai.mvp.picker.ContentImport
import java.io.File

class SelectedModelImporter(private val context: Context) {
    fun importPte(uri: Uri, displayName: String): File =
        ContentImport.copyToPrivateStorage(context, uri, "models/incoming", displayName)

    fun importManifest(uri: Uri, displayName: String): File =
        ContentImport.copyToPrivateStorage(context, uri, "models/incoming", displayName)
}
