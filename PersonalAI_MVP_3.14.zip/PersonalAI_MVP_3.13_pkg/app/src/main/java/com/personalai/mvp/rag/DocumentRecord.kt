package com.personalai.mvp.rag

data class DocumentRecord(
    val documentId: String,
    val documentName: String,
    val sha256: String,
    val chunkCount: Int,
    val addedAt: Long
)
