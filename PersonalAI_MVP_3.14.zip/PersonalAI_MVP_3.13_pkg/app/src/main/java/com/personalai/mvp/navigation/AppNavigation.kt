package com.personalai.mvp.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personalai.mvp.appstate.AppScreen

@Composable
fun AppNavigation(
    current: AppScreen,
    onNavigate: (AppScreen) -> Unit,
    content: @Composable () -> Unit
) {
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = current == AppScreen.CHAT,
                    onClick = { onNavigate(AppScreen.CHAT) },
                    icon = {},
                    label = { Text("Chat") }
                )
                NavigationBarItem(
                    selected = current == AppScreen.DOCUMENTS,
                    onClick = { onNavigate(AppScreen.DOCUMENTS) },
                    icon = {},
                    label = { Text("Documents") }
                )
                NavigationBarItem(
                    selected = current == AppScreen.MODELS,
                    onClick = { onNavigate(AppScreen.MODELS) },
                    icon = {},
                    label = { Text("Models") }
                )
                NavigationBarItem(
                    selected = current == AppScreen.SETTINGS,
                    onClick = { onNavigate(AppScreen.SETTINGS) },
                    icon = {},
                    label = { Text("Settings") }
                )
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            content()
        }
    }
}
