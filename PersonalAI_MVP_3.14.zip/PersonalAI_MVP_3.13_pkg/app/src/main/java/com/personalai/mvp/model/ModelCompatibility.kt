package com.personalai.mvp.model

import android.os.Build

object ModelCompatibility {
    fun check(manifest: ModelManifest): CompatibilityResult {
        if (manifest.runtime != "executorch") {
            return CompatibilityResult(false, "Unsupported runtime: ${manifest.runtime}")
        }
        val arch = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val compatibleArch = manifest.architecture == "arm64-v8a" && arch == "arm64-v8a"
        if (!compatibleArch) {
            return CompatibilityResult(
                false,
                "Model architecture ${manifest.architecture} is not compatible with device ABI $arch"
            )
        }
        return CompatibilityResult(true, "Compatible with Android ${Build.VERSION.SDK_INT} / $arch")
    }
}

data class CompatibilityResult(val compatible: Boolean, val message: String)
