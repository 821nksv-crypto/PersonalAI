package com.personalai.mvp.shell

import androidx.compose.runtime.*
import androidx.compose.material3.*
import com.personalai.mvp.appstate.AppScreen
import com.personalai.mvp.appstate.AppStateRepository
import com.personalai.mvp.onboarding.PrivacySetupScreen
import com.personalai.mvp.settings.SettingsScreen
import com.personalai.mvp.rag.EmbeddingStatus
import com.personalai.mvp.documents.DocumentLibraryScreen
import com.personalai.mvp.documents.DocumentUiItem
import com.personalai.mvp.importer.ModelImportScreen
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier

@Composable
fun PersonalAiAppShell(
    appState: AppStateRepository,
    documents: List<DocumentUiItem>,
    installedModels: List<String>,
    modelReady: Boolean,
    memoryEnabled: Boolean,
    onImportPdf: () -> Unit,
    onCancelIndexing: (String) -> Unit,
    onDeleteDocument: (String) -> Unit,
    onRetryIndexing: (DocumentUiItem) -> Unit,
    requiresReindex: Boolean,
    onReindexAll: () -> Unit,
    onImportModel: () -> Unit,
    onRemoveModel: (String) -> Unit,
    onClearMemory: () -> Unit,
    onMemoryChanged: (Boolean) -> Unit,
    embeddingStatus: EmbeddingStatus,
    onImportEmbedding: () -> Unit,
    onRemoveEmbedding: () -> Unit,
    chatContent: @Composable () -> Unit
) {
    val state by appState.state.collectAsState()

    if (!state.privacySetupComplete) {
        PrivacySetupScreen(
            onContinue = { appState.completePrivacySetup() }
        )
        return
    }

    when (state.currentScreen) {
        AppScreen.CHAT -> {
            MainScaffold(
                selected = AppScreen.CHAT,
                onSelect = appState::navigate
            ) { chatContent() }
        }

        AppScreen.DOCUMENTS -> {
            MainScaffold(
                selected = AppScreen.DOCUMENTS,
                onSelect = appState::navigate
            ) {
                DocumentLibraryScreen(
                    documents = documents,
                    onImportPdf = onImportPdf,
                    onCancel = onCancelIndexing,
                    onDelete = onDeleteDocument,
                    onRetry = onRetryIndexing,
                    requiresReindex = requiresReindex,
                    onReindexAll = onReindexAll
                )
            }
        }

        AppScreen.MODELS -> {
            MainScaffold(
                selected = AppScreen.MODELS,
                onSelect = appState::navigate
            ) {
                ModelImportScreen(
                    installedModels = installedModels,
                    onImport = onImportModel,
                    onRemove = onRemoveModel
                )
            }
        }

        AppScreen.SETTINGS -> {
            MainScaffold(
                selected = AppScreen.SETTINGS,
                onSelect = appState::navigate
            ) {
                SettingsScreen(
                    internetEnabled = state.internetEnabled,
                    memoryEnabled = memoryEnabled,
                    modelReady = modelReady,
                    onInternetChanged = appState::setInternetEnabled,
                    onMemoryChanged = onMemoryChanged,
                    onClearMemory = onClearMemory,
                    embeddingStatus = embeddingStatus,
                    onImportEmbedding = onImportEmbedding,
                    onRemoveEmbedding = onRemoveEmbedding
                )
            }
        }
    }
}

@Composable
private fun MainScaffold(
    selected: AppScreen,
    onSelect: (AppScreen) -> Unit,
    content: @Composable () -> Unit
) {
    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf(
                    AppScreen.CHAT to "Chat",
                    AppScreen.DOCUMENTS to "Documents",
                    AppScreen.MODELS to "Models",
                    AppScreen.SETTINGS to "Settings"
                ).forEach { (screen, label) ->
                    NavigationBarItem(
                        selected = selected == screen,
                        onClick = { onSelect(screen) },
                        icon = {},
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) { content() }
    }
}
