package com.personalai.mvp.ai

interface StreamingLocalLlm {
    fun startStreaming(
        prompt: String,
        onToken: (String) -> Unit,
        onComplete: (String) -> Unit,
        onError: (Throwable) -> Unit
    )
    fun stopStreaming()
}

class ExecuTorchStreamingAdapter(private val engine: ExecuTorchLocalEngine) : StreamingLocalLlm {
    override fun startStreaming(
        prompt: String,
        onToken: (String) -> Unit,
        onComplete: (String) -> Unit,
        onError: (Throwable) -> Unit
    ) = engine.startStreaming(prompt, onToken, onComplete, onError)

    override fun stopStreaming() = engine.stopStreaming()
}
