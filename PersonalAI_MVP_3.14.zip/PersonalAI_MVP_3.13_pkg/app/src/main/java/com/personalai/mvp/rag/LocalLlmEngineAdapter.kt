package com.personalai.mvp.rag

class LocalLlmEngineAdapter(
    private val generator: suspend (String) -> String
) : LocalLlmEngine {
    override suspend fun generate(prompt: String): String = generator(prompt)
}
