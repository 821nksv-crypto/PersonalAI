package com.personalai.mvp.indexing

object IndexingWorkContract {
    const val KEY_DOCUMENT_ID = "document_id"
    const val KEY_DOCUMENT_NAME = "document_name"
    const val KEY_DOCUMENT_PATH = "document_path"
    const val KEY_PROGRESS = "progress"
    const val KEY_PAGE = "page"
    const val KEY_TOTAL_PAGES = "total_pages"
    const val KEY_ERROR = "error"
}
