package com.personalai.mvp.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

class SecureSettingsStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        "personal_ai_secure",
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        context.applicationContext,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var braveApiKey: String
        get() = prefs.getString("brave_api_key", "") ?: ""
        set(value) { prefs.edit().putString("brave_api_key", value.trim()).apply() }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
