package com.personalai.mvp.ai

import android.content.Context
import java.io.File

data class LocalModelInfo(
    val id: String,
    val displayName: String,
    val fileName: String,
    val format: String,
    val installed: Boolean,
    val sizeBytes: Long
)

class LocalModelManager(private val context: Context) {

    private val modelDir: File
        get() = File(context.filesDir, "models").apply { mkdirs() }

    fun listInstalled(): List<LocalModelInfo> =
        modelDir.listFiles()?.map {
            LocalModelInfo(
                id = it.nameWithoutExtension,
                displayName = it.nameWithoutExtension,
                fileName = it.name,
                format = it.extension.ifBlank { "unknown" },
                installed = true,
                sizeBytes = it.length()
            )
        } ?: emptyList()

    fun modelDirectory(): File = modelDir
}
