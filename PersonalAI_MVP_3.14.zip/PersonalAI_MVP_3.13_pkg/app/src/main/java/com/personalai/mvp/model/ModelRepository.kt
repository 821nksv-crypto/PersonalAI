package com.personalai.mvp.model

import android.content.Context
import android.net.Uri
import java.io.File

class ModelRepository(private val context: Context) {
    private val dir = File(context.filesDir, "models").apply { mkdirs() }

    private fun copy(uri: Uri, destination: File) {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Unable to open selected file." }
            destination.outputStream().use { output -> input.copyTo(output) }
        }
    }

    fun importFile(uri: Uri, fallbackName: String): File {
        val name = context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        } ?: fallbackName
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val destination = File(dir, safe)
        copy(uri, destination)
        return destination
    }

    fun installedFiles(): List<File> = dir.listFiles()?.filter { it.isFile } ?: emptyList()
    fun modelDirectory(): File = dir
}
