package com.personalai.mvp.importer

import com.personalai.mvp.model.AtomicModelInstaller
import com.personalai.mvp.model.InstallationResult
import com.personalai.mvp.model.ModelManifest
import java.io.File

class ModelImportPipeline(
    private val installer: AtomicModelInstaller
) {
    fun import(
        source: File,
        manifest: ModelManifest,
        signatureBase64: String?,
        pinnedPublicKeyBase64: String?,
        tokenizerSource: File? = null
    ): InstallationResult =
        installer.install(source, manifest, signatureBase64, pinnedPublicKeyBase64, tokenizerSource)
}
