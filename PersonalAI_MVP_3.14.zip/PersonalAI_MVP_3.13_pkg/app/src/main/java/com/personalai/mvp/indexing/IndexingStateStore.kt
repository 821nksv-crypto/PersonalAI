package com.personalai.mvp.indexing

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class PersistedIndexingState(
    val documentId: String,
    val status: String,
    val progress: Int,
    val currentPage: Int = 0,
    val totalPages: Int = 0,
    val error: String? = null
)

class IndexingStateStore(private val context: Context) {
    private val file = File(context.filesDir, "indexing_state.json")

    @Synchronized
    fun get(documentId: String): PersistedIndexingState? =
        all().firstOrNull { it.documentId == documentId }

    @Synchronized
    fun all(): List<PersistedIndexingState> {
        if (!file.exists()) return emptyList()
        val array = JSONArray(file.readText())
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(
                    PersistedIndexingState(
                        documentId = o.getString("documentId"),
                        status = o.optString("status", "QUEUED"),
                        progress = o.optInt("progress", 0),
                        currentPage = o.optInt("currentPage", 0),
                        totalPages = o.optInt("totalPages", 0),
                        error = if (o.isNull("error")) null else o.optString("error")
                    )
                )
            }
        }
    }

    @Synchronized
    fun put(state: PersistedIndexingState) {
        val map = all().associateBy { it.documentId }.toMutableMap()
        map[state.documentId] = state
        persist(map.values.toList())
    }

    @Synchronized
    fun remove(documentId: String) {
        persist(all().filterNot { it.documentId == documentId })
    }

    private fun persist(values: List<PersistedIndexingState>) {
        val array = JSONArray()
        values.forEach { s ->
            array.put(
                JSONObject()
                    .put("documentId", s.documentId)
                    .put("status", s.status)
                    .put("progress", s.progress)
                    .put("currentPage", s.currentPage)
                    .put("totalPages", s.totalPages)
                    .put("error", s.error)
            )
        }
        val tmp = File(file.parentFile, "${file.name}.part")
        tmp.writeText(array.toString())
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }
}
