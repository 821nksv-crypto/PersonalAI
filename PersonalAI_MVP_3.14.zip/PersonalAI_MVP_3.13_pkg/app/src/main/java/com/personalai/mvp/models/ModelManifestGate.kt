package com.personalai.mvp.models

import java.io.File
import org.json.JSONObject

object ModelManifestGate {
    fun validateManifestFile(file: File): Result<Unit> = runCatching {
        require(file.exists()) { "Manifest does not exist." }
        val o = JSONObject(file.readText())
        require(o.optString("id").isNotBlank()) { "Manifest id missing." }
        require(o.optString("version").isNotBlank()) { "Manifest version missing." }
        require(o.optString("fileName").isNotBlank()) { "Manifest fileName missing." }
        require(o.optString("sha256").matches(Regex("^[0-9a-fA-F]{64}$"))) {
            "Manifest sha256 must be 64 hex characters."
        }
        require(o.optLong("sizeBytes", -1) >= 0) { "Manifest sizeBytes missing." }
    }
}
