package com.personalai.mvp.documents

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class DocumentUiItem(
    val id: String,
    val name: String,
    val status: String,
    val progress: Int = 0
)

@Composable
fun DocumentLibraryScreen(
    documents: List<DocumentUiItem>,
    onImportPdf: () -> Unit,
    onCancel: (String) -> Unit,
    onDelete: (String) -> Unit,
    onRetry: (DocumentUiItem) -> Unit,
    requiresReindex: Boolean,
    onReindexAll: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Documents", style = MaterialTheme.typography.headlineSmall)

        Button(onClick = onImportPdf, modifier = Modifier.fillMaxWidth()) {
            Text("Import PDF")
        }

        if (requiresReindex) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Documents need re-indexing", style = MaterialTheme.typography.titleMedium)
                    Text("The active embedding configuration changed. Existing vectors are preserved until the replacement index is ready.")
                    Button(onClick = onReindexAll) { Text("Re-index all documents") }
                }
            }
        }

        if (documents.isEmpty()) {
            Text("No documents selected.")
        }

        documents.forEach { item ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(item.name, style = MaterialTheme.typography.titleMedium)
                    Text(item.status)

                    if (item.status.equals("RUNNING", true) ||
                        item.status.equals("QUEUED", true)) {
                        LinearProgressIndicator(
                            progress = { item.progress.coerceIn(0, 100) / 100f },
                            modifier = Modifier.fillMaxWidth()
                        )
                        TextButton(onClick = { onCancel(item.id) }) {
                            Text("Cancel")
                        }
                    }

                    if (item.status.equals("FAILED", true) || item.status.equals("CANCELLED", true)) {
                        TextButton(onClick = { onRetry(item) }) { Text("Retry") }
                    }
                    TextButton(onClick = { onDelete(item.id) }) { Text("Delete") }
                }
            }
        }
    }
}
