package com.personalai.mvp.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personalai.mvp.rag.EmbeddingStatus

@Composable
fun SettingsScreen(
    internetEnabled: Boolean,
    memoryEnabled: Boolean,
    modelReady: Boolean,
    onInternetChanged: (Boolean) -> Unit,
    onMemoryChanged: (Boolean) -> Unit,
    onClearMemory: () -> Unit,
    embeddingStatus: EmbeddingStatus,
    onImportEmbedding: () -> Unit,
    onRemoveEmbedding: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("Internet")
                Text("Only enabled when you choose to use web search.")
            }
            Switch(checked = internetEnabled, onCheckedChange = onInternetChanged)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("Local Memory")
                Text("Stores bounded conversation context on this device.")
            }
            Switch(checked = memoryEnabled, onCheckedChange = onMemoryChanged)
        }

        OutlinedButton(onClick = onClearMemory) {
            Text("Clear Local Memory")
        }

        Text(
            if (modelReady) "Local model: Ready" else "Local model: Not installed",
            style = MaterialTheme.typography.bodyLarge
        )

        EmbeddingSettingsSection(
            status = embeddingStatus,
            onImport = onImportEmbedding,
            onRemove = onRemoveEmbedding
        )
    }
}
