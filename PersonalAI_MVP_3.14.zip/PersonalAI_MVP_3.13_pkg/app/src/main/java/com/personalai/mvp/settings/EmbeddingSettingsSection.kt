package com.personalai.mvp.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personalai.mvp.rag.EmbeddingStatus

@Composable
fun EmbeddingSettingsSection(
    status: EmbeddingStatus,
    onImport: () -> Unit,
    onRemove: () -> Unit
) {
    HorizontalDivider()
    Text("Document Embeddings", style = MaterialTheme.typography.titleMedium)
    Text(if (status.neural) "Neural: ${status.name}" else "Offline baseline: ${status.name}")
    Text(status.detail, style = MaterialTheme.typography.bodySmall)
    OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
        Text("Import ONNX Embedding Model")
    }
    if (status.neural) {
        TextButton(onClick = onRemove) { Text("Remove Neural Embedding") }
    }
}
