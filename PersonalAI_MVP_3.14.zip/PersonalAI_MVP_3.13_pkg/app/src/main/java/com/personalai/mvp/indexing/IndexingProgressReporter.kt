package com.personalai.mvp.indexing

import android.content.Context

class IndexingProgressReporter(context: Context) {
    private val store = IndexingStateStore(context)

    fun queued(id: String) =
        store.put(PersistedIndexingState(id, "QUEUED", 0))

    fun running(id: String, page: Int, totalPages: Int) {
        val progress = if (totalPages <= 0) 0
        else ((page.toDouble() / totalPages.toDouble()) * 100.0).toInt().coerceIn(0, 100)
        store.put(
            PersistedIndexingState(
                documentId = id,
                status = "RUNNING",
                progress = progress,
                currentPage = page,
                totalPages = totalPages
            )
        )
    }

    fun completed(id: String, totalPages: Int) =
        store.put(PersistedIndexingState(id, "COMPLETED", 100, totalPages, totalPages))

    fun failed(id: String, message: String) =
        store.put(PersistedIndexingState(id, "FAILED", 0, error = message))

    fun cancelled(id: String) =
        store.put(PersistedIndexingState(id, "CANCELLED", 0))
}
