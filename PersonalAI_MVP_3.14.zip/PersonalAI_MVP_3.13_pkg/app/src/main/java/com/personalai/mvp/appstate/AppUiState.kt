package com.personalai.mvp.appstate

data class AppUiState(
    val privacySetupComplete: Boolean = false,
    val internetEnabled: Boolean = false,
    val memoryEnabled: Boolean = true,
    val currentScreen: AppScreen = AppScreen.CHAT
)

enum class AppScreen {
    CHAT, DOCUMENTS, MODELS, SETTINGS
}
