package com.personalai.mvp.rag

data class InlineCitation(
    val index: Int,
    val label: String,
    val documentName: String? = null,
    val pageNumber: Int? = null,
    val url: String? = null
)

object InlineCitationFormatter {
    fun local(sources: List<RagSource>): List<InlineCitation> =
        sources.distinctBy { "${it.documentName}:${it.pageNumber}" }.mapIndexed { i, s ->
            InlineCitation(i + 1, "[${i + 1}]", s.documentName, s.pageNumber, null)
        }
}
