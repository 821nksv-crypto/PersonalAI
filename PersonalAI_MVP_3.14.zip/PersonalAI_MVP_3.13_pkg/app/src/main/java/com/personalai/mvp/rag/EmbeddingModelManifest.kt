package com.personalai.mvp.rag

/** Immutable identity of the embedding configuration used to build a vector index. */
data class EmbeddingModelManifest(
    val name: String,
    val format: String,
    val dimension: Int,
    val minAndroidApi: Int,
    val sha256: String,
    val version: String = "1",
    val tokenizerSha256: String = ""
) {
    fun fingerprint(): String = listOf(
        name, format, dimension, minAndroidApi, sha256, version, tokenizerSha256
    ).joinToString("|")

    companion object {
        /** Offline deterministic baseline. It is intentionally not mislabeled as MiniLM. */
        val HASHING_384_V1 = EmbeddingModelManifest(
            name = "local-hashing-384",
            format = "native",
            dimension = 384,
            minAndroidApi = 23,
            sha256 = "builtin",
            version = "1"
        )
    }
}

enum class IndexHealth { READY, EMPTY, REINDEX_REQUIRED, CORRUPTED }
