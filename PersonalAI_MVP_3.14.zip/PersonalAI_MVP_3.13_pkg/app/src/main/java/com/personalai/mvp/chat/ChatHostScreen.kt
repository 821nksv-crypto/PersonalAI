package com.personalai.mvp.chat

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.personalai.mvp.ai.LocalModelEngine
import com.personalai.mvp.model.ModelRuntimeResolver
import com.personalai.mvp.rag.PersistentVectorIndex

@Composable
fun ChatHostScreen(modelReady: Boolean) {
    val context = LocalContext.current
    val resolver = remember { ModelRuntimeResolver(context) }
    val index = remember { PersistentVectorIndex(context) }
    var resolved by remember { mutableStateOf(resolver.resolve()) }

    LaunchedEffect(modelReady) {
        resolved = resolver.resolve()
    }

    val engine: LocalModelEngine = remember(resolved) {
        resolver.createEngine()
    }
    val runtimeKey = when (resolved) {
        is com.personalai.mvp.model.ResolvedModel.Ready -> {
            val p = (resolved as com.personalai.mvp.model.ResolvedModel.Ready).packageInfo
            "${p.manifest.id}-${p.manifest.version}"
        }
        is com.personalai.mvp.model.ResolvedModel.Unavailable -> "unavailable"
    }
    val vm: ChatViewModel = viewModel(
        key = "chat-$runtimeKey",
        factory = ChatViewModelFactory(context, engine, index)
    )

    val messages by vm.messages.collectAsState()
    val route by vm.lastRoute.collectAsState()
    val sources by vm.lastSources.collectAsState()
    val webSources by vm.lastWebSources.collectAsState()
    val busy by vm.busy.collectAsState()
    val stream by vm.stream.collectAsState()
    val internetEnabled by vm.internetEnabled.collectAsState()
    var input by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Personal AI", style = MaterialTheme.typography.headlineMedium)
        Text(if (vm.modelReady) "On-device model: ${vm.modelName}" else "Local model unavailable. ${resolved.reason()}")

        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Switch(checked = internetEnabled, onCheckedChange = vm::setInternetEnabled, enabled = vm.modelReady)
            Text(if (internetEnabled) "Use Internet — explicit query may leave device" else "Internet OFF — local route only")
        }

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages.filter { it.role != "system" }) { message ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(message.role.uppercase(), style = MaterialTheme.typography.labelSmall)
                        Spacer(Modifier.height(4.dp))
                        Text(message.text)
                    }
                }
            }
            if (stream.active && stream.text.isNotBlank()) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("ASSISTANT • generating", style = MaterialTheme.typography.labelSmall)
                            Text(stream.text)
                        }
                    }
                }
            }
        }

        route?.let { Text("Route: ${it.name.replace('_', ' ')}", style = MaterialTheme.typography.labelSmall) }
        sources.distinctBy { "${it.documentName}:${it.pageNumber}" }.forEachIndexed { i, s ->
            Text("[${i + 1}] ${s.documentName} — page ${s.pageNumber}", style = MaterialTheme.typography.bodySmall)
        }
        webSources.forEachIndexed { i, s ->
            Text("[${i + 1}] ${s.title} — ${s.url}", style = MaterialTheme.typography.bodySmall)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                enabled = !busy && vm.modelReady,
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (vm.modelReady) "Talk to your local AI…" else "Install a local model first") }
            )
            if (busy) {
                Button(onClick = vm::stopGeneration) { Text("Stop") }
            } else {
                Button(enabled = vm.modelReady && input.isNotBlank(), onClick = { vm.send(input); input = "" }) {
                    Text("Send")
                }
            }
        }
    }
}

private fun com.personalai.mvp.model.ResolvedModel.reason(): String = when (this) {
    is com.personalai.mvp.model.ResolvedModel.Ready -> "ready"
    is com.personalai.mvp.model.ResolvedModel.Unavailable -> reason
}
