package com.personalai.mvp.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personalai.mvp.ai.ExecuTorchLocalEngine
import com.personalai.mvp.ai.LocalModelEngine
import com.personalai.mvp.internet.InternetPolicy
import com.personalai.mvp.internet.WebSearchResult
import com.personalai.mvp.model.ChatMessage
import com.personalai.mvp.rag.RagSource
import com.personalai.mvp.rag.CitationFormatter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ChatViewModel(
    private val engine: LocalModelEngine,
    private val serviceFactory: (InternetPolicy) -> ChatService,
    private val store: ConversationStore
) : ViewModel() {
    private val system = ChatMessage("system", "LOCAL FIRST. Only selected documents and explicitly enabled web search are external inputs.")
    private val memory = LocalConversationMemory()

    private val _messages = MutableStateFlow(listOf(system) + store.load())
    val messages: StateFlow<List<ChatMessage>> = _messages
    private val _lastRoute = MutableStateFlow<ChatRoute?>(null)
    val lastRoute: StateFlow<ChatRoute?> = _lastRoute
    private val _lastSources = MutableStateFlow<List<RagSource>>(emptyList())
    val lastSources: StateFlow<List<RagSource>> = _lastSources
    private val _lastWebSources = MutableStateFlow<List<WebSearchResult>>(emptyList())
    val lastWebSources: StateFlow<List<WebSearchResult>> = _lastWebSources
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy
    private val _stream = MutableStateFlow(StreamingChatState())
    val stream: StateFlow<StreamingChatState> = _stream
    private val _internetEnabled = MutableStateFlow(false)
    private val _selectedDocumentIds = MutableStateFlow<Set<String>?>(null)
    val selectedDocumentIds: StateFlow<Set<String>?> = _selectedDocumentIds
    val internetEnabled: StateFlow<Boolean> = _internetEnabled

    val modelName: String get() = engine.modelName()
    val modelReady: Boolean get() = engine.isReady()

    fun setInternetEnabled(enabled: Boolean) { _internetEnabled.value = enabled }

    fun setSelectedDocumentIds(documentIds: Set<String>?) { _selectedDocumentIds.value = documentIds?.toSet() }

    fun send(prompt: String) {
        if (prompt.isBlank() || _busy.value || !modelReady) return
        val clean = prompt.trim()
        _messages.value = _messages.value + ChatMessage("user", clean)
        persist()
        _busy.value = true
        _stream.value = StreamingChatState(active = true, text = "")

        viewModelScope.launch {
            try {
                val context = memory.compact(_messages.value.dropLast(1))
                val service = serviceFactory(InternetPolicy(_internetEnabled.value))
                val prepared = service.prepare(clean, context, _selectedDocumentIds.value)
                _lastRoute.value = prepared.route
                _lastSources.value = prepared.sources
                _lastWebSources.value = prepared.webSources

                if (engine is ExecuTorchLocalEngine) {
                    engine.startStreaming(
                        prompt = prepared.prompt,
                        onToken = { token ->
                            if (_busy.value) {
                                _stream.value = _stream.value.copy(active = true, text = _stream.value.text + token)
                            }
                        },
                        onComplete = { full -> completeAssistant(full) },
                        onError = { error -> failAssistant(error) }
                    )
                } else {
                    completeAssistant(engine.generate(prepared.prompt))
                }
            } catch (t: Throwable) {
                failAssistant(t)
            }
        }
    }

    private fun completeAssistant(full: String) {
        if (!_busy.value) return
        val rendered = if (_lastRoute.value == ChatRoute.DOCUMENT_QA) {
            CitationFormatter.appendToAnswer(full, _lastSources.value)
        } else {
            full
        }
        _messages.value = _messages.value + ChatMessage("assistant", rendered)
        persist()
        _stream.value = StreamingChatState(active = false)
        _busy.value = false
    }

    private fun failAssistant(error: Throwable) {
        if (!_busy.value) return
        val message = error.message ?: "inference failed"
        _stream.value = StreamingChatState(active = false, error = message)
        _messages.value = _messages.value + ChatMessage("assistant", "Error: $message")
        persist()
        _busy.value = false
    }

    fun stopGeneration() {
        if (!_busy.value) return
        if (engine is ExecuTorchLocalEngine) engine.stopStreaming()
        val partial = _stream.value.text
        if (partial.isNotBlank()) {
            _messages.value = _messages.value + ChatMessage("assistant", "$partial\n\n[Generation stopped]")
            persist()
        }
        _stream.value = StreamingChatState(active = false)
        _busy.value = false
    }

    private fun persist() { store.save(_messages.value) }
}
