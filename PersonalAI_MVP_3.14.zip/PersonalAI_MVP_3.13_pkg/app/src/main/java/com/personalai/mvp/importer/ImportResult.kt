package com.personalai.mvp.importer

sealed class ImportResult {
    data class Success(val message: String) : ImportResult()
    data class Failure(val message: String) : ImportResult()
    data object Cancelled : ImportResult()
}
