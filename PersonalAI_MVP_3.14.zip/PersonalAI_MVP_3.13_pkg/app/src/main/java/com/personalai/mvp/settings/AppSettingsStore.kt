package com.personalai.mvp.settings

import android.content.Context

class AppSettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("personal_ai_settings", Context.MODE_PRIVATE)

    var internetEnabled: Boolean
        get() = prefs.getBoolean("internet_enabled", false)
        set(value) { prefs.edit().putBoolean("internet_enabled", value).apply() }

    var searchEndpoint: String
        get() = prefs.getString("search_endpoint", "") ?: ""
        set(value) { prefs.edit().putString("search_endpoint", value.trim()).apply() }

    var searchApiKey: String
        get() = prefs.getString("search_api_key", "") ?: ""
        set(value) { prefs.edit().putString("search_api_key", value).apply() }
}
