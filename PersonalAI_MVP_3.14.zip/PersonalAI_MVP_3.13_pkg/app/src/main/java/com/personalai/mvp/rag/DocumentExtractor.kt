package com.personalai.mvp.rag

import android.content.Context
import android.net.Uri

/**
 * MVP extractor.
 * Plain-text files are supported directly.
 * PDF extraction is intentionally isolated behind this interface so a PDF
 * parser can be added without changing the RAG layer.
 */
class DocumentExtractor(private val context: Context) {
    fun extract(uri: Uri, displayName: String): String {
        val type = context.contentResolver.getType(uri).orEmpty()
        return if (type.startsWith("text/") || displayName.endsWith(".txt", true)
            || displayName.endsWith(".md", true)) {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: error("Unable to read selected document")
        } else {
            error("PDF parser is not bundled in this MVP build. Add a PDF parser module before enabling PDF ingestion.")
        }
    }
}
