package com.personalai.mvp.integration

/**
 * 2.8 integration boundary.
 *
 * The existing project contains independent document/model controllers. This adapter
 * centralizes the handoff so ActivityResult callbacks never become a second source of
 * truth for catalogs or verification.
 */
data class DocumentHandoff(
    val id: String,
    val name: String,
    val path: String,
    val sha256: String,
    val sizeBytes: Long
)

data class ModelHandoff(
    val id: String,
    val modelPath: String,
    val manifestPath: String
)
