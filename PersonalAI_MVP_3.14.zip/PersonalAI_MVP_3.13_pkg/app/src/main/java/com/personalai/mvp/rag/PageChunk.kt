package com.personalai.mvp.rag

data class PageChunk(
    val documentId: String,
    val documentName: String,
    val pageNumber: Int,
    val chunkIndex: Int,
    val text: String,
    val vector: FloatArray = floatArrayOf()
)
