package com.personalai.mvp.memory

/**
 * Deterministic local memory compaction.
 * It does not upload conversation content and does not require an external model.
 *
 * The result is intentionally a bounded factual transcript rather than an
 * unconstrained generated "profile".
 */
class MemoryCompactor(
    private val maxCharacters: Int = 6000
) {
    fun compact(turns: List<Pair<String, String>>): String {
        if (turns.isEmpty()) return ""
        val recent = turns.takeLast(20)
        val text = recent.joinToString("\n") { (role, content) ->
            "${role.uppercase()}: ${content.trim()}"
        }
        return if (text.length <= maxCharacters) text
        else text.takeLast(maxCharacters)
    }
}
