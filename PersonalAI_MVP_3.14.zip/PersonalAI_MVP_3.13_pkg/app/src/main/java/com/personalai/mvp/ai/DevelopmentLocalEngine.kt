package com.personalai.mvp.ai

/**
 * Development fallback.
 *
 * This is deliberately transparent: it does not claim to be a language model.
 * Replace it with a real native local-model adapter after selecting a model
 * runtime and model file appropriate for the target Android devices.
 */
class DevelopmentLocalEngine : LocalModelEngine {
    override suspend fun generate(prompt: String): String =
        "Local model runtime is not installed yet. " +
        "The application architecture is ready for a real on-device model. " +
        "Received locally: ${prompt.take(160)}"

    override fun isReady(): Boolean = false
    override fun modelName(): String = "No local model installed"
}
