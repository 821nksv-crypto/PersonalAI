package com.personalai.mvp.model

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Durable metadata for an installed model package. */
data class InstalledModelPackage(
    val manifest: ModelManifest,
    val modelFile: File,
    val tokenizerFile: File?
)

class InstalledModelPackageStore(private val context: Context) {
    private val root = File(context.filesDir, "models").apply { mkdirs() }
    private val registry = File(root, "installed_packages.json")

    @Synchronized
    fun list(): List<InstalledModelPackage> {
        if (!registry.exists()) return emptyList()
        val arr = org.json.JSONArray(registry.readText())
        val out = mutableListOf<InstalledModelPackage>()
        for (i in 0 until arr.length()) {
            runCatching {
                val o = arr.getJSONObject(i)
                val m = ModelManifest(
                    id = o.getString("id"),
                    displayName = o.getString("displayName"),
                    version = o.getString("version"),
                    runtime = o.getString("runtime"),
                    architecture = o.getString("architecture"),
                    fileName = o.getString("fileName"),
                    sizeBytes = o.getLong("sizeBytes"),
                    sha256 = o.getString("sha256"),
                    tokenizerFileName = o.optString("tokenizerFileName", "").takeIf { it.isNotBlank() },
                    tokenizerSha256 = o.optString("tokenizerSha256", "").takeIf { it.isNotBlank() }
                )
                val model = File(root, m.fileName)
                val tokenizer = m.tokenizerFileName?.let { File(root, it) }
                if (model.isFile && (tokenizer == null || tokenizer.isFile)) {
                    out += InstalledModelPackage(m, model, tokenizer)
                }
            }
        }
        return out
    }

    @Synchronized
    fun upsert(manifest: ModelManifest) {
        val values = list().map { it.manifest }.filterNot { it.id == manifest.id }.toMutableList()
        values += manifest
        val arr = org.json.JSONArray()
        values.forEach { arr.put(toJson(it)) }
        val tmp = File(root, "installed_packages.json.part")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(registry)) {
            registry.delete()
            require(tmp.renameTo(registry)) { "Could not update installed model registry" }
        }
    }

    @Synchronized
    fun remove(id: String) {
        val existing = list().map { it.manifest }
        val removed = existing.firstOrNull { it.id == id }
        removed?.let {
            File(root, it.fileName).delete()
            it.tokenizerFileName?.let { name -> File(root, name).delete() }
        }
        val arr = org.json.JSONArray()
        existing.filterNot { it.id == id }.forEach { arr.put(toJson(it)) }
        registry.writeText(arr.toString())
    }

    private fun toJson(m: ModelManifest): JSONObject = JSONObject().apply {
        put("id", m.id)
        put("displayName", m.displayName)
        put("version", m.version)
        put("runtime", m.runtime)
        put("architecture", m.architecture)
        put("fileName", m.fileName)
        put("sizeBytes", m.sizeBytes)
        put("sha256", m.sha256)
        put("tokenizerFileName", m.tokenizerFileName ?: "")
        put("tokenizerSha256", m.tokenizerSha256 ?: "")
    }
}
