package com.personalai.mvp.settings

data class SettingsState(
    val internetEnabled: Boolean = false,
    val memoryEnabled: Boolean = true,
    val modelReady: Boolean = false
)
