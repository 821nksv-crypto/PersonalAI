package com.personalai.mvp.models

import android.content.Context
import org.json.JSONObject
import java.io.File

class PendingModelPairStore(context: Context) {
    private val file = File(context.filesDir, "pending_model_pair.json")

    fun save(pair: SelectedModelPair) {
        file.writeText(JSONObject().apply {
            put("id", pair.id)
            put("model", pair.model.absolutePath)
            put("manifest", pair.manifest.absolutePath)
        }.toString())
    }

    fun load(): SelectedModelPair? {
        if (!file.exists()) return null
        val o = JSONObject(file.readText())
        return SelectedModelPair(
            o.getString("id"),
            File(o.getString("model")),
            File(o.getString("manifest"))
        )
    }

    fun clear() {
        if (file.exists()) file.delete()
    }
}
