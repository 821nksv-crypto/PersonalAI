package com.personalai.mvp.indexing

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.work.WorkInfo
import androidx.work.WorkManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ObservedWorkState(
    val documentId: String,
    val workId: String,
    val status: WorkInfo.State,
    val progress: Int,
    val error: String? = null
)

class WorkManagerIndexingObserver(context: Context) {
    private val workManager = WorkManager.getInstance(context.applicationContext)
    private val _state = MutableStateFlow<List<ObservedWorkState>>(emptyList())
    val state: StateFlow<List<ObservedWorkState>> = _state.asStateFlow()

    fun observe(documentId: String): LiveData<List<WorkInfo>> =
        workManager.getWorkInfosForUniqueWorkLiveData(uniqueName(documentId))

    fun update(documentId: String, workInfos: List<WorkInfo>) {
        _state.value = workInfos.map { info ->
            ObservedWorkState(
                documentId = documentId,
                workId = info.id.toString(),
                status = info.state,
                progress = info.progress.getInt(DocumentIndexWorker.KEY_PROGRESS, 0).coerceIn(0, 100),
                error = info.outputData.getString("error")
            )
        }
    }

    fun cancel(documentId: String) {
        workManager.cancelUniqueWork(uniqueName(documentId))
    }

    companion object {
        fun uniqueName(documentId: String) = "document-index-$documentId"
    }
}
