package com.personalai.mvp.rag

data class RagSource(
    val documentName: String,
    val pageNumber: Int,
    val chunkIndex: Int,
    val score: Float
)

data class RagAnswer(
    val answer: String,
    val sources: List<RagSource>
)
