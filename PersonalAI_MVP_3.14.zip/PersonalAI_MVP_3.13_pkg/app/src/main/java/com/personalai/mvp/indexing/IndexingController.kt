package com.personalai.mvp.indexing

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.work.WorkInfo
import androidx.work.WorkManager

class IndexingController(private val context: Context) {
    fun observe(documentId: String): LiveData<WorkInfo?> =
        WorkManager.getInstance(context)
            .getWorkInfosForUniqueWorkLiveData("index-$documentId")
            .map { it.firstOrNull() }

    fun cancel(documentId: String) =
        DocumentIndexScheduler.cancel(context, documentId)
}
