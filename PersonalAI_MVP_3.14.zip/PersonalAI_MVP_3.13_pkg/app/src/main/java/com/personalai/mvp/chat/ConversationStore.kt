package com.personalai.mvp.chat

import android.content.Context
import com.personalai.mvp.model.ChatMessage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ConversationStore(context: Context) {
    private val file = File(context.filesDir, "conversation.json")

    fun load(): List<ChatMessage> = runCatching {
        if (!file.exists()) return emptyList()
        val a = JSONArray(file.readText())
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(ChatMessage(o.getString("role"), o.getString("text")))
            }
        }
    }.getOrDefault(emptyList())

    fun save(messages: List<ChatMessage>) {
        val a = JSONArray()
        messages.filter { it.role != "system" }.forEach {
            a.put(JSONObject().apply {
                put("role", it.role)
                put("text", it.text)
            })
        }
        file.writeText(a.toString())
    }
}
