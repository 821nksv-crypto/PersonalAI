package com.personalai.mvp.internet

interface WebSearchClient {
    suspend fun search(query: String, maxResults: Int = 5): WebSearchResponse
}

/**
 * Provider-neutral HTTP JSON adapter.
 *
 * Expected response:
 * {
 *   "results": [
 *     {"title":"...", "url":"https://...", "snippet":"...","source":"..."}
 *   ]
 * }
 *
 * The endpoint must be HTTPS. No user files, chat history, contacts or device
 * identifiers are included in the request—only the explicit search query.
 */
class HttpsJsonSearchClient(
    private val endpoint: String,
    private val httpGet: suspend (url: String) -> String
) : WebSearchClient {
    override suspend fun search(query: String, maxResults: Int): WebSearchResponse {
        require(endpoint.startsWith("https://")) { "Search endpoint must use HTTPS." }
        val encoded = java.net.URLEncoder.encode(query, "UTF-8")
        val url = "$endpoint?q=$encoded&limit=$maxResults"
        val body = httpGet(url)
        val json = org.json.JSONObject(body)
        val array = json.optJSONArray("results") ?: org.json.JSONArray()
        val results = buildList {
            for (i in 0 until minOf(array.length(), maxResults)) {
                val o = array.getJSONObject(i)
                add(
                    WebSearchResult(
                        title = o.optString("title"),
                        url = o.optString("url"),
                        snippet = o.optString("snippet"),
                        source = o.optString("source", o.optString("url"))
                    )
                )
            }
        }
        return WebSearchResponse(query, results)
    }
}
