package com.personalai.mvp.models

import com.personalai.mvp.model.ModelManifest
import org.json.JSONObject

object ModelManifestJson {
    fun parse(json: String): ModelManifest {
        val o = JSONObject(json)
        return ModelManifest(
            id = o.getString("id"),
            displayName = o.optString("displayName", o.optString("name")),
            version = o.getString("version"),
            runtime = o.optString("runtime", "executorch"),
            architecture = o.optString("architecture", o.optString("abi", "arm64-v8a")),
            fileName = o.getString("fileName"),
            sizeBytes = o.getLong("sizeBytes"),
            sha256 = o.getString("sha256"),
            tokenizerFileName = o.optString("tokenizerFileName", "").takeIf { it.isNotBlank() },
            tokenizerSha256 = o.optString("tokenizerSha256", "").takeIf { it.isNotBlank() }
        )
    }
}
