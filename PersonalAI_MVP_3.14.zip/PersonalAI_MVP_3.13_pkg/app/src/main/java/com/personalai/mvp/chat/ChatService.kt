package com.personalai.mvp.chat

import com.personalai.mvp.ai.LocalModelEngine
import com.personalai.mvp.internet.InternetPolicy
import com.personalai.mvp.internet.WebContextBuilder
import com.personalai.mvp.internet.WebSearchClient
import com.personalai.mvp.rag.LocalLlmEngineAdapter
import com.personalai.mvp.rag.PersistentVectorIndex
import com.personalai.mvp.rag.RagAnswer
import com.personalai.mvp.rag.RagOrchestrator
import com.personalai.mvp.rag.RagPromptBuilder
import com.personalai.mvp.rag.RagSource
import com.personalai.mvp.internet.WebSearchResult

class ChatService(
    private val engine: LocalModelEngine,
    private val index: PersistentVectorIndex,
    private val internetPolicy: InternetPolicy = InternetPolicy(false),
    private val webSearch: WebSearchClient? = null
) {
    private val router = ChatRouter()
    private val rag = RagOrchestrator(
        index = index,
        promptBuilder = RagPromptBuilder(),
        llm = LocalLlmEngineAdapter { prompt -> engine.generate(prompt) }
    )

    /** Resolves the route and builds the exact final prompt before model generation. */
    suspend fun prepare(prompt: String, conversationContext: String = "", selectedDocumentIds: Set<String>? = null): PreparedAnswer {
        val route = router.route(
            prompt,
            hasDocuments = index.size() > 0 && !index.requiresReindex(),
            internetEnabled = internetPolicy.canSearch()
        )

        return when (route.route) {
            ChatRoute.GENERAL_CHAT -> {
                val system = "You are Personal AI, a private local-first assistant. Answer naturally and never claim access to data or internet that is not actually supplied."
                val memory = if (conversationContext.isBlank()) "" else "\n\nRECENT LOCAL CONVERSATION:\n$conversationContext"
                PreparedAnswer(
                    prompt = "$system$memory\n\nUSER:\n$prompt\n\nASSISTANT:",
                    route = route.route,
                    sources = emptyList(),
                    webSources = emptyList(),
                    reason = route.reason
                )
            }
            ChatRoute.DOCUMENT_QA -> {
                val results = index.search(prompt, 5, selectedDocumentIds)
                val finalPrompt = RagPromptBuilder().build(prompt, results)
                val sources = results.map {
                    RagSource(it.chunk.documentName, it.chunk.pageNumber, it.chunk.chunkIndex, it.score)
                }
                PreparedAnswer(finalPrompt, route.route, sources, emptyList(), route.reason)
            }
            ChatRoute.INTERNET_SEARCH -> {
                val client = webSearch ?: return PreparedAnswer(
                    prompt = "Internet search is not configured. Answer locally if possible:\n$prompt",
                    route = ChatRoute.GENERAL_CHAT,
                    sources = emptyList(),
                    webSources = emptyList(),
                    reason = "Internet was requested but no search provider is configured."
                )
                val response = client.search(prompt)
                val context = WebContextBuilder.build(response)
                val finalPrompt = """
You are a local AI assistant using externally retrieved web search results.
Answer the user's question using only the supplied web context.
Do not invent facts or citations. Use [N] labels when referring to a web result.
If the results are insufficient, say so.

$context

USER:
$prompt

ASSISTANT:
""".trimIndent()
                PreparedAnswer(finalPrompt, route.route, emptyList(), response.results, route.reason)
            }
        }
    }

    suspend fun answer(prompt: String, conversationContext: String = ""): ServiceAnswer {
        val prepared = prepare(prompt, conversationContext)
        val generated = engine.generate(prepared.prompt)
        return ServiceAnswer(
            generated, prepared.route,
            prepared.sources, prepared.webSources, prepared.reason
        )
    }
}

data class PreparedAnswer(
    val prompt: String,
    val route: ChatRoute,
    val sources: List<RagSource>,
    val webSources: List<WebSearchResult>,
    val reason: String
)

data class ServiceAnswer(
    val text: String,
    val route: ChatRoute,
    val sources: List<RagSource>,
    val webSources: List<WebSearchResult>,
    val reason: String
)
