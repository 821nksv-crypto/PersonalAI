package com.personalai.mvp.internet

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object AndroidHttpsTransport {
    suspend fun get(url: String, timeoutMs: Int = 12000): String =
        withContext(Dispatchers.IO) {
            require(url.startsWith("https://")) { "Only HTTPS URLs are allowed." }
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "GET"
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = true
            c.setRequestProperty("Accept", "application/json")
            try {
                val code = c.responseCode
                if (code !in 200..299) {
                    throw IllegalStateException("Search request failed: HTTP $code")
                }
                c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                c.disconnect()
            }
        }
}
