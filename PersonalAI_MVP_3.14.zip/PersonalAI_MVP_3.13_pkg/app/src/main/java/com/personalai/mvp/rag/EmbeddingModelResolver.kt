package com.personalai.mvp.rag

import android.content.Context
import com.personalai.mvp.model.ModelVerifier
import org.json.JSONObject
import java.io.File

/** Resolves a verified, app-private embedding package; otherwise uses the explicit hashing baseline. */
class EmbeddingModelResolver(private val context: Context) {
    fun resolve(): EmbeddingRuntime {
        val root = File(context.filesDir, "embedding")
        val manifestFile = File(root, "embedding_manifest.json")
        if (!manifestFile.isFile) return HashingEmbeddingRuntime()

        return runCatching {
            val o = JSONObject(manifestFile.readText())
            val model = File(root, o.getString("modelFileName"))
            val vocab = File(root, o.getString("vocabFileName"))
            require(model.isFile && vocab.isFile) { "Embedding model package is incomplete" }

            val modelHash = ModelVerifier.sha256(model)
            val expectedModelHash = o.getString("modelSha256")
            require(modelHash.equals(expectedModelHash, ignoreCase = true)) { "Embedding model SHA-256 mismatch" }

            val vocabHash = ModelVerifier.sha256(vocab)
            val expectedVocabHash = o.getString("vocabSha256")
            require(vocabHash.equals(expectedVocabHash, ignoreCase = true)) { "Embedding vocabulary SHA-256 mismatch" }

            val manifest = EmbeddingModelManifest(
                name = o.getString("name"),
                format = "onnx",
                dimension = o.getInt("dimension"),
                minAndroidApi = o.optInt("minAndroidApi", 26),
                sha256 = expectedModelHash,
                version = o.getString("version"),
                tokenizerSha256 = expectedVocabHash
            )
            require(manifest.dimension > 0) { "Embedding dimension must be positive" }
            require(android.os.Build.VERSION.SDK_INT >= manifest.minAndroidApi) { "Embedding runtime requires Android API ${manifest.minAndroidApi}" }

            val tokenizer = BertWordPieceTokenizer.fromVocabFile(vocab)
            OnnxEmbeddingRuntime(
                OnnxMiniLmEmbedder(model, tokenizer, o.optInt("maxLength", 128)),
                manifest
            )
        }.getOrElse { error ->
            throw IllegalStateException("Installed embedding package could not be verified: ${error.message}", error)
        }
    }
}

/** Installs an embedding model only after model/vocabulary hashes have been verified. */
class EmbeddingModelInstaller(private val context: Context) {
    fun install(
        modelSource: File,
        vocabSource: File,
        name: String,
        version: String,
        dimension: Int,
        maxLength: Int = 128
    ) = installValidated(modelSource, vocabSource, name, version, dimension, maxLength,
        ModelVerifier.sha256(modelSource), ModelVerifier.sha256(vocabSource))

    fun installValidated(
        modelSource: File,
        vocabSource: File,
        name: String,
        version: String,
        dimension: Int,
        maxLength: Int,
        expectedModelSha256: String,
        expectedVocabSha256: String
    ) {
        require(modelSource.isFile) { "Embedding model file not found" }
        require(vocabSource.isFile) { "Embedding vocabulary file not found" }
        require(dimension > 0) { "Embedding dimension must be positive" }
        require(maxLength > 0) { "maxLength must be positive" }

        val root = File(context.filesDir, "embedding")
        val staging = File(context.filesDir, "embedding-staging-${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val modelTarget = File(staging, "model.onnx")
            val vocabTarget = File(staging, "vocab.txt")
            modelSource.copyTo(modelTarget, overwrite = true)
            vocabSource.copyTo(vocabTarget, overwrite = true)

            val modelHash = ModelVerifier.sha256(modelTarget)
            val vocabHash = ModelVerifier.sha256(vocabTarget)
            require(modelHash.equals(expectedModelSha256, ignoreCase = true)) { "Embedding model SHA-256 mismatch" }
            require(vocabHash.equals(expectedVocabSha256, ignoreCase = true)) { "Embedding vocabulary SHA-256 mismatch" }
            BertWordPieceTokenizer.fromVocabFile(vocabTarget)

            val manifest = JSONObject().apply {
                put("schemaVersion", 1)
                put("name", name)
                put("version", version)
                put("format", "onnx")
                put("modelFileName", "model.onnx")
                put("modelSha256", modelHash)
                put("vocabFileName", "vocab.txt")
                put("vocabSha256", vocabHash)
                put("dimension", dimension)
                put("maxLength", maxLength)
                put("minAndroidApi", 26)
            }
            File(staging, "embedding_manifest.json").writeText(manifest.toString())

            val backup = File(context.filesDir, "embedding-backup-${System.currentTimeMillis()}")
            if (root.exists()) require(root.renameTo(backup)) { "Could not stage current embedding package" }
            require(staging.renameTo(root)) {
                if (backup.exists()) backup.renameTo(root)
                "Could not activate embedding package"
            }
            backup.deleteRecursively()
        } catch (t: Throwable) {
            staging.deleteRecursively()
            throw t
        }
    }

    fun remove() {
        File(context.filesDir, "embedding").deleteRecursively()
    }
}
