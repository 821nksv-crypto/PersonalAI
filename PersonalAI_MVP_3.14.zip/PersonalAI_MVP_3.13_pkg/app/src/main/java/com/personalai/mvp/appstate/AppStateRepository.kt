package com.personalai.mvp.appstate

import android.content.Context
import com.personalai.mvp.onboarding.PrivacySetupStore
import com.personalai.mvp.settings.SettingsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppStateRepository(context: Context) {
    private val privacy = PrivacySetupStore(context)
    private val settings = SettingsStore(context)

    private val _state = MutableStateFlow(
        AppUiState(
            privacySetupComplete = privacy.isComplete(),
            internetEnabled = settings.internetEnabled()
        )
    )
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    fun completePrivacySetup() {
        privacy.complete()
        _state.value = _state.value.copy(privacySetupComplete = true)
    }

    fun setInternetEnabled(enabled: Boolean) {
        settings.setInternetEnabled(enabled)
        _state.value = _state.value.copy(internetEnabled = enabled)
    }

    fun setMemoryEnabled(enabled: Boolean) {
        _state.value = _state.value.copy(memoryEnabled = enabled)
    }

    fun navigate(screen: AppScreen) {
        _state.value = _state.value.copy(currentScreen = screen)
    }
}
