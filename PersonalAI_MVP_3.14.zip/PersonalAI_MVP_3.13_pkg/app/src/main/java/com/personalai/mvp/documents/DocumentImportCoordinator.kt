package com.personalai.mvp.documents

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.util.UUID

class DocumentImportCoordinator(private val context: Context) {
    private val controller = DocumentLibraryController(context)

    fun importPdf(source: File, displayName: String): ImportedDocument {
        val id = UUID.randomUUID().toString()
        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val target = File(context.filesDir, "documents/$id-$safeName")
        target.parentFile?.mkdirs()

        FileInputStream(source).use { input ->
            target.outputStream().use { output ->
                input.copyTo(output, 1024 * 1024)
                output.fd.sync()
            }
        }

        controller.registerImported(id, displayName, target.absolutePath)
        return ImportedDocument(id, displayName, target)
    }
}

data class ImportedDocument(
    val id: String,
    val displayName: String,
    val file: File
)
