package com.personalai.mvp.catalog

import android.content.Context
import com.personalai.mvp.documents.DocumentUiItem
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class DocumentCatalogStore(private val context: Context) {
    private val file = File(context.filesDir, "document_catalog.json")

    @Synchronized
    fun list(): List<DocumentUiItem> {
        if (!file.exists()) return emptyList()
        val array = JSONArray(file.readText())
        return buildList {
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                add(
                    DocumentUiItem(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        status = o.optString("status", "QUEUED"),
                        progress = o.optInt("progress", 0)
                    )
                )
            }
        }
    }

    @Synchronized
    fun upsert(item: DocumentUiItem) {
        val all = list().associateBy { it.id }.toMutableMap()
        all[item.id] = item
        persist(all.values.toList())
    }

    @Synchronized
    fun remove(id: String) {
        persist(list().filterNot { it.id == id })
    }

    private fun persist(items: List<DocumentUiItem>) {
        val array = JSONArray()
        items.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("status", it.status)
                    .put("progress", it.progress)
            )
        }
        val tmp = File(file.parentFile, "${file.name}.part")
        tmp.writeText(array.toString())
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }
}
