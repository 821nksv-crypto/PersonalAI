package com.personalai.mvp.indexing

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class IndexingStateRepository(context: Context) {
    private val store = IndexingStateStore(context)
    private val _states = MutableStateFlow(store.all())
    val states: StateFlow<List<PersistedIndexingState>> = _states.asStateFlow()

    fun refresh() {
        _states.value = store.all()
    }

    fun state(documentId: String): PersistedIndexingState? =
        store.get(documentId)
}
