package com.personalai.mvp.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun PrivacySetupScreen(onContinue: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Your Personal AI", style = MaterialTheme.typography.headlineMedium)
        Text("Privacy-first setup", style = MaterialTheme.typography.titleLarge)

        Text("By default:")
        Text("• Your selected personal files stay on this device.")
        Text("• Internet access is off until you enable it.")
        Text("• Contacts, SMS, WhatsApp, email, gallery, camera, microphone and GPS are not accessed automatically.")
        Text("• Local conversation memory is optional.")
        Text("• Model and document processing is designed to run locally.")

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = onContinue
        ) {
            Text("Continue")
        }
    }
}
