package com.personalai.mvp.model

import java.io.File

data class VerificationResult(val ok: Boolean, val reason: String)

object ModelInstallVerifier {
    fun verify(file: File, manifest: ModelManifest): VerificationResult {
        if (!file.exists()) return VerificationResult(false, "Model file does not exist.")
        if (file.length() != manifest.sizeBytes) {
            return VerificationResult(false, "Size mismatch: expected ${manifest.sizeBytes}, got ${file.length()}.")
        }
        val actual = ModelVerifier.sha256(file)
        if (!actual.equals(manifest.sha256, ignoreCase = true)) {
            return VerificationResult(false, "SHA-256 mismatch.")
        }
        return VerificationResult(true, "Verified ${manifest.id} ${manifest.version}.")
    }
}
