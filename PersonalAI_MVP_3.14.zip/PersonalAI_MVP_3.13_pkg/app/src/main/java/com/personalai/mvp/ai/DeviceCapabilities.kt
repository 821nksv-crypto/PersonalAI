package com.personalai.mvp.ai

import android.app.ActivityManager
import android.content.Context
import android.os.Build

data class DeviceCapabilities(
    val totalRamMb: Long,
    val availableProcessors: Int,
    val androidApi: Int
)

fun detectDeviceCapabilities(context: Context): DeviceCapabilities {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val info = ActivityManager.MemoryInfo()
    am.getMemoryInfo(info)
    return DeviceCapabilities(
        totalRamMb = info.totalMem / (1024 * 1024),
        availableProcessors = Runtime.getRuntime().availableProcessors(),
        androidApi = Build.VERSION.SDK_INT
    )
}
