package com.personalai.mvp.rag

import org.junit.Assert.assertEquals
import org.junit.Test

class WordPieceTokenizerTest {
    @Test fun encodesSpecialTokensAndKnownPieces() {
        val tokenizer = BertWordPieceTokenizer(mapOf(
            "[UNK]" to 0, "[CLS]" to 1, "[SEP]" to 2,
            "hello" to 3, "world" to 4, "##s" to 5
        ))
        val encoded = tokenizer.encode("hello worlds", 8)
        assertEquals(1, encoded.inputIds[0])
        assertEquals(3, encoded.inputIds[1])
        assertEquals(4, encoded.inputIds[2])
        assertEquals(5, encoded.inputIds[3])
        assertEquals(2, encoded.inputIds[4])
        assertEquals(1, encoded.attentionMask[4])
    }
}
