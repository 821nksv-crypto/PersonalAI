package com.personalai.mvp.model

import org.junit.Assert.assertEquals
import org.junit.Test

class InstalledModelPackageStoreTest {
    @Test fun manifestRoundTripShapeIsStable() {
        val m = ModelManifest(
            id = "qwen-test", displayName = "Qwen Test", version = "1",
            runtime = "executorch", architecture = "arm64-v8a",
            fileName = "qwen.pte", sizeBytes = 10, sha256 = "abc",
            tokenizerFileName = "tokenizer.model", tokenizerSha256 = "def"
        )
        assertEquals("qwen.pte", m.fileName)
        assertEquals("tokenizer.model", m.tokenizerFileName)
    }
}
