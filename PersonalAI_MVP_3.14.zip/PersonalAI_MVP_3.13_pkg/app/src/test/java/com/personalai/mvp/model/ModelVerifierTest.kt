package com.personalai.mvp.model

import org.junit.Assert.*
import org.junit.Test
import java.io.File

class ModelVerifierTest {
    @Test fun missingFileFails() {
        val manifest = ModelManifest("x","X","1","executorch","arm64-v8a","x.pte",1,"00")
        val result = ModelVerifier.verify(File("does-not-exist"), manifest)
        assertFalse(result.verified)
    }
}
