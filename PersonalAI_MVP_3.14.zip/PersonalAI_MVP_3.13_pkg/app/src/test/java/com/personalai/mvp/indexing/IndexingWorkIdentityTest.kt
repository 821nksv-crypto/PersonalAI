package com.personalai.mvp.indexing

import org.junit.Assert.assertEquals
import org.junit.Test

class IndexingWorkIdentityTest {
    @Test
    fun uniqueWorkNameIsDeterministic() {
        assertEquals(
            "document-index-123",
            WorkManagerIndexingObserver.uniqueName("123")
        )
    }
}
