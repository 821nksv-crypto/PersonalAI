package com.personalai.mvp.indexing

import org.junit.Assert.assertEquals
import org.junit.Test

class IndexingProgressReporterTest {
    @Test
    fun progressIsBounded() {
        val progress = ((150.0 / 100.0) * 100.0).toInt().coerceIn(0, 100)
        assertEquals(100, progress)
    }

    @Test
    fun failureStateCarriesError() {
        val state = PersistedIndexingState("id", "FAILED", 0, error = "bad pdf")
        assertEquals("bad pdf", state.error)
    }
}
