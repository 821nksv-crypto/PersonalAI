package com.personalai.mvp.rag

import org.junit.Assert.assertEquals
import org.junit.Test

class PersistentVectorIndexContractTest {
    @Test fun documentIdsArePartOfRetrievalContract() {
        val chunk = PageChunk("doc-a", "A.pdf", 1, 0, "alpha")
        assertEquals("doc-a", chunk.documentId)
    }

    @Test fun emptyDocumentFilterDoesNotMeanAllDocuments() {
        val ids = emptySet<String>()
        assertEquals(false, "doc-a" in ids)
    }
}
