package com.personalai.mvp.rag

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class EmbeddingModelManifestTest {
    @Test fun sameManifestHasStableFingerprint() {
        assertEquals(EmbeddingModelManifest.HASHING_384_V1.fingerprint(), EmbeddingModelManifest.HASHING_384_V1.fingerprint())
    }

    @Test fun tokenizerHashChangeChangesFingerprint() {
        val base = EmbeddingModelManifest.HASHING_384_V1
        val changed = base.copy(tokenizerSha256 = "abc")
        assertNotEquals(base.fingerprint(), changed.fingerprint())
    }

    @Test fun versionChangeChangesFingerprint() {
        val base = EmbeddingModelManifest.HASHING_384_V1
        val changed = base.copy(version = "2")
        assertNotEquals(base.fingerprint(), changed.fingerprint())
    }
}
