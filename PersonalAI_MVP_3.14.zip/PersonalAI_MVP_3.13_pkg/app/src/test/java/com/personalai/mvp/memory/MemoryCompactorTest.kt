package com.personalai.mvp.memory

import org.junit.Assert.*
import org.junit.Test

class MemoryCompactorTest {
    @Test fun compactionIsBounded() {
        val c = MemoryCompactor(100)
        val result = c.compact(listOf("user" to "a".repeat(200)))
        assertTrue(result.length <= 100)
    }
}
