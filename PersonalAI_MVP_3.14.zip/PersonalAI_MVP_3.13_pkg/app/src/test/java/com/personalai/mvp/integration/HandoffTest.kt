package com.personalai.mvp.integration

import org.junit.Assert.assertEquals
import org.junit.Test

class HandoffTest {
    @Test
    fun documentHandoffRetainsIdentity() {
        val h = DocumentHandoff("d1", "a.pdf", "/x/a.pdf", "abc", 10)
        assertEquals("d1", h.id)
        assertEquals(10, h.sizeBytes)
    }

    @Test
    fun modelHandoffRetainsPaths() {
        val h = ModelHandoff("m1", "/x/model.pte", "/x/manifest.json")
        assertEquals("/x/model.pte", h.modelPath)
        assertEquals("/x/manifest.json", h.manifestPath)
    }
}
