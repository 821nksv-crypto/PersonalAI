package com.personalai.mvp.catalog

import com.personalai.mvp.documents.DocumentUiItem
import org.junit.Assert.assertEquals
import org.junit.Test

class CatalogModelTest {
    @Test
    fun documentItemKeepsProgress() {
        val item = DocumentUiItem("1", "a.pdf", "RUNNING", 55)
        assertEquals(55, item.progress)
    }

    @Test
    fun statusCanRepresentFailure() {
        val item = DocumentUiItem("1", "a.pdf", "FAILED", 25)
        assertEquals("FAILED", item.status)
    }
}
