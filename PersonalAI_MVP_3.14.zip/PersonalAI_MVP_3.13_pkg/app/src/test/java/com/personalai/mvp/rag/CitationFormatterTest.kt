package com.personalai.mvp.rag

import org.junit.Assert.assertEquals
import org.junit.Test

class CitationFormatterTest {
    @Test
    fun appendsStableDocumentCitations() {
        val sources = listOf(
            RagSource("Contract.pdf", 12, 0, 0.91f),
            RagSource("Contract.pdf", 12, 1, 0.88f),
            RagSource("Contract.pdf", 18, 0, 0.84f)
        )

        val result = CitationFormatter.appendToAnswer("The clause requires notice.", sources)

        assertEquals(
            "The clause requires notice.\n\nSources: [1] Contract.pdf, p.12  [2] Contract.pdf, p.12  [3] Contract.pdf, p.18",
            result
        )
    }

    @Test
    fun doesNotAddSourcesWhenThereAreNoSources() {
        assertEquals("Answer", CitationFormatter.appendToAnswer("Answer", emptyList()))
    }
}
