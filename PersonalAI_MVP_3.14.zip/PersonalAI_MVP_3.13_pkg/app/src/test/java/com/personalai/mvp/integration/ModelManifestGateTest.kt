package com.personalai.mvp.integration

import com.personalai.mvp.models.ModelManifestGate
import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelManifestGateTest {
    @Test
    fun rejectsInvalidManifest() {
        val f = File.createTempFile("manifest", ".json")
        f.writeText("{\"id\":\"x\",\"version\":\"1\",\"fileName\":\"x.pte\",\"sha256\":\"bad\",\"sizeBytes\":1}")
        assertTrue(ModelManifestGate.validateManifestFile(f).isFailure)
        f.delete()
    }
}
