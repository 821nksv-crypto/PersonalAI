package com.personalai.mvp.shell

import com.personalai.mvp.appstate.AppScreen
import org.junit.Assert.assertEquals
import org.junit.Test

class ShellStateTest {
    @Test
    fun mainScreensAreStable() {
        assertEquals(
            listOf(
                AppScreen.CHAT,
                AppScreen.DOCUMENTS,
                AppScreen.MODELS,
                AppScreen.SETTINGS
            ),
            AppScreen.values().toList()
        )
    }
}
