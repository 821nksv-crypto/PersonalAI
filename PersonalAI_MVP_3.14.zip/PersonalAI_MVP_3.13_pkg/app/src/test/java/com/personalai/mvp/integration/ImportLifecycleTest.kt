package com.personalai.mvp.integration

import org.junit.Assert.assertEquals
import org.junit.Test

class ImportLifecycleTest {
    @Test
    fun lifecycleValuesAreStable() {
        assertEquals("SELECTED", ImportLifecycle.SELECTED.name)
        assertEquals("COPIED_PRIVATE", ImportLifecycle.COPIED_PRIVATE.name)
        assertEquals("QUEUED", ImportLifecycle.QUEUED.name)
    }
}
