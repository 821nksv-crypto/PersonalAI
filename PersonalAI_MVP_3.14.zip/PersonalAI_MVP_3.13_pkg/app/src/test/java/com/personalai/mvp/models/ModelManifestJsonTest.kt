
package com.personalai.mvp.models

import org.junit.Assert.assertEquals
import org.junit.Test

class ModelManifestJsonTest {
    @Test
    fun parsesRequiredManifestFields() {
        val json = """
            {
              "id":"qwen",
              "name":"Qwen Local",
              "version":"1",
              "fileName":"model.pte",
              "sha256":"abc",
              "sizeBytes":123,
              "runtime":"executorch",
              "abi":"arm64-v8a"
            }
        """.trimIndent()

        val m = ModelManifestJson.parse(json)
        assertEquals("qwen", m.id)
        assertEquals(123L, m.sizeBytes)
        assertEquals("arm64-v8a", m.architecture)
    }
}
