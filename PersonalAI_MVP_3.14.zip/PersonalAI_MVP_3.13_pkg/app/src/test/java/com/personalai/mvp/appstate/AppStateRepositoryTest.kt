package com.personalai.mvp.appstate

import org.junit.Assert.assertEquals
import org.junit.Test

class AppStateRepositoryTest {
    @Test
    fun navigationStatesAreRepresented() {
        val initial = AppUiState()
        assertEquals(AppScreen.CHAT, initial.currentScreen)
    }

    @Test
    fun privacyStartsIncomplete() {
        val state = AppUiState()
        assertEquals(false, state.privacySetupComplete)
    }
}
