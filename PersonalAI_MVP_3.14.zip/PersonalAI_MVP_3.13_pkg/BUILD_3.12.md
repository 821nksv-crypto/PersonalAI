# Personal AI 3.12 — Build Readiness

Version: 3.12.0 (versionCode 37)

## Build target

- Android Gradle Plugin: 8.7.3
- Gradle: 8.11.1
- Kotlin: 2.0.21
- compileSdk: 35
- minSdk: 26
- Java/Kotlin target: 17

## Important verification status

This source archive is build-ready in configuration, but the supplied development environment used to prepare this archive does not contain a Gradle executable, a Gradle wrapper JAR, or an Android SDK command-line toolchain. Therefore an APK build was **not** claimed or embedded as verified in this release.

## Reproducible build

On a machine with Android SDK + JDK 17 and Gradle 8.11.1 available:

```text
gradle wrapper --gradle-version 8.11.1 --distribution-type bin
gradle testDebugUnitTest

gradle assembleDebug
```

The resulting debug APK should be under `app/build/outputs/apk/debug/`.

## Runtime prerequisites

The app intentionally does not bundle a large language model or embedding model. A user must explicitly import compatible model packages before local inference/RAG can operate.

- Local LLM: verified/imported ExecuTorch package + tokenizer.
- Neural RAG: verified/imported ONNX embedding model + manifest + vocab.
- Internet search: explicit app route and INTERNET permission only.

## Privacy boundary

No contacts, SMS, WhatsApp, gallery, microphone, camera, or location permissions are declared by the application manifest.
