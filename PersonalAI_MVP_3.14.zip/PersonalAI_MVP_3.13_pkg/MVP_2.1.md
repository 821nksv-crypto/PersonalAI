# Personal AI MVP 2.1

## App-level integration

This milestone introduces the application state and navigation layer needed to connect the previously separate modules.

### Added
- `AppUiState` and `AppStateRepository`
- First-run privacy state gate
- Central navigation model: Chat / Documents / Models / Settings
- Bottom navigation shell
- Model library UI
- PDF document library UI
- Import result/controller abstraction
- Basic app-state unit tests

## Intended runtime flow

1. App starts.
2. If privacy setup is incomplete, show the privacy setup screen.
3. After completion, enter the main navigation shell.
4. Chat is the default screen.
5. Documents can be imported through Android's document picker and sent to the existing WorkManager indexing pipeline.
6. Models can be imported through the existing verification/atomic-install pipeline.
7. Settings controls the explicit Internet boundary and local-memory preference.

## Security boundary

No new personal-data permissions are introduced.

The app still does not automatically access:
- contacts
- SMS
- WhatsApp
- email
- gallery
- camera
- microphone
- GPS

Internet remains explicitly controlled.

## Next: MVP 2.2

- Wire these composables into the actual `MainActivity`/existing chat UI.
- Persist the document/model catalog rather than using UI-only lists.
- Connect WorkManager progress to `DocumentLibraryScreen`.
- Connect real `ModelManager` inventory to `ModelImportScreen`.
- Add model manifest JSON picker.
- Add retry and cancellation controls with persisted state.
