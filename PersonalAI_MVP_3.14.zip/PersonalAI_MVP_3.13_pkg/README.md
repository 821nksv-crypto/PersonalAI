# Personal AI MVP 0.5

Local-first Android AI assistant foundation.

## 0.5 changes

- Uses the current ExecuTorch Android LLM API pattern (`LlmModuleConfig`, `LlmModule`, `LlmGenerationConfig`, `LlmCallback`).
- Uses memory-mapped model loading.
- Runs synchronous native generation on a coroutine background dispatcher, not the Android main thread.
- Adds SHA-256 model verification utility.
- Adds a concrete Qwen3 0.6B ExecuTorch/XNNPACK model-pack recipe.
- Keeps model and tokenizer inside app-private storage.
- Does not bundle a model or silently download one.

## Important

This ZIP is source code. It has not been represented as a verified APK build in this environment. Open it in Android Studio, sync Gradle, and build on a machine with the Android SDK/NDK as required by the selected ExecuTorch runtime.

## Privacy boundary

Private chats/files are not sent to other devices. Future distributed-compute features must operate only on explicitly classified public/authorized workloads. Other devices are compute workers, not sources of personal data.

## 0.6 update

- Added local document store.
- Added local chunking and lexical retrieval.
- Added explicit document extraction boundary.
- User-selected documents remain app-private.
- PDF parser/vector embeddings are intentionally deferred to the next build rather than pretending they are implemented.

## 0.7 update

- Added PDFBox-Android PDF text extraction.
- Added page-aware chunks and source metadata.
- Added local vector retrieval baseline.
- Added RAG context builder.
- Added explicit distinction between hashing vectors and neural embeddings.

## 0.8 update

- Added ONNX Runtime Android 1.30.0.
- Added real MiniLM ONNX embedding adapter.
- Added embedding model manifest/checksum documentation.
- Added explicit RAG pipeline boundary.
- Retained deterministic vectorizer as fallback.
- Model download is intentionally not automatic until a verified downloader is implemented.

## 0.9 update

- Added end-to-end RAG orchestration boundary.
- Added grounded prompt builder.
- Added structured `RagAnswer` and `RagSource`.
- Added Local LLM adapter boundary.
- Added citation formatter.
- Citations are application-generated from retrieved metadata, not trusted from model prose.


## MVP 1.0
See `MVP_1.0.md`. This milestone adds a local conversational service, local conversation persistence, PDF ingestion, document-aware routing, and structured source display.


## MVP 1.1
Adds explicit Internet mode, a provider-neutral HTTPS search adapter, three-way routing (local chat / local documents / internet), and a strict privacy boundary. See `INTERNET_1.1.md`.


## MVP 1.2
Real Brave Search adapter, persistent local RAG index, streaming-capable ExecuTorch callback adapter, and local search-provider settings. See `MVP_1.2.md`.


## MVP 1.3
Adds encrypted search credentials, persistent document management with SHA-256 deduplication and deletion, and unified streaming UI state. See `MVP_1.3.md`.


## MVP 1.4
Adds true ExecuTorch token streaming for general local chat, generation cancellation, bounded local conversation context, and current stable AndroidX Security Crypto dependency. See `MVP_1.4.md`.

## MVP 1.5
Unified streaming for general chat, RAG, and web routes; fixed document-aware routing; structured citation metadata; stop/partial-output handling. See `MVP_1.5.md`.


## MVP 1.6
Reliability milestone: structured app-owned citations, bounded local memory, SHA-256/size model verification, restored page-aware PDF extraction, indexing feedback, and corrected generation-stop persistence. See `MVP_1.6.md`.


## MVP 1.7
Background WorkManager PDF indexing, page-level progress/retry/cancel infrastructure, model SHA-256/size verification, and runtime/ABI compatibility checks. See `MVP_1.7.md`.


## MVP 1.8
Signed Ed25519 manifest verification, atomic model installation/rollback, indexing controller, and bounded local memory compaction. See `MVP_1.8.md`.


## MVP 1.9
Adds user-facing model manager, indexing progress/cancel controls, encrypted local memory controls, and local unit tests. See `MVP_1.9.md`.


## MVP 2.0
End-to-end integration foundations: first-run privacy setup, central settings, model import facade, PDF import → background indexing coordinator, and picker contracts. See `MVP_2.0.md`.


## MVP 2.1
Adds app-level state/navigation, privacy gate integration primitives, model library UI, document library UI, and import result handling. See `MVP_2.1.md`.


## MVP 2.2
Adds persistent document/model catalogs and controllers for import, indexing lifecycle, retry/cancel/delete, and application coordination. See `MVP_2.2.md`.


## MVP 2.3
Adds durable indexing lifecycle state, page-progress reporting, UI state recovery, and model installation state primitives. See `MVP_2.3.md`.


## MVP 2.4
Adds WorkManager observation contracts and a verified model manifest import flow. See `MVP_2.4.md`.


## MVP 2.5
Adds the unified application shell, privacy gate, Chat/Documents/Models/Settings navigation, and a host Activity integration surface. See `MVP_2.5.md`.


## MVP 2.6
Adds explicit Android SAF picker contracts and app-private import helpers. See `MVP_2.6.md`.


## MVP 2.7
Explicit PDF/model import lifecycle services and durable import events. See `MVP_2.7.md`.


## MVP 2.8
Adds durable document/model handoff records and persistent selected-artifact state. See `MVP_2.8.md`.

## MVP 3.0
Canonical release path: the legacy duplicate MainActivity/chat ViewModel path was removed; PersonalAiHostActivity is the launcher. Model installation now supports a manifest-declared tokenizer with SHA-256 verification and atomic model/tokenizer commit. WorkManager progress uses a shared `progress` contract. See `MVP_3.0.md`.


## MVP 3.3
Build/release configuration repair: version 3.3.0, Gradle 8.11.1 wrapper configuration, and explicit JUnit test dependency. See `MVP_3.3.md`.
