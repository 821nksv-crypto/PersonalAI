# PersonalAI MVP 3.7

## RAG grounding and app-owned citations

This milestone connects the existing persistent vector retrieval and grounded prompt path to the user-visible answer. Document-QA responses receive citations after local model generation using application-owned source metadata.

Pipeline:
PDF -> page extraction -> persistent vector index -> top-K retrieval -> grounded prompt -> verified local model -> answer -> app-owned citations

The language model does not author document names or page numbers. Citation metadata comes from the indexed chunk records.

## Privacy

Imported documents remain app-private. Internet search remains an explicit separate route. No contacts, SMS, location, microphone, camera, or gallery permissions are added.

## Verification

Source-level checks and ZIP integrity can be performed offline. Full Android APK compilation still requires a working Gradle/Android dependency environment.
