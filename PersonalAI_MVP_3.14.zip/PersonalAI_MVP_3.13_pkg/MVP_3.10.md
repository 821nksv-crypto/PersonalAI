# Personal AI MVP 3.10

## Verified ONNX embedding package import

3.10 adds an Android-side import and status path for neural RAG embeddings.

### User-controlled import

Settings now exposes **Import ONNX Embedding Model**. The user selects:

1. `model.onnx`
2. embedding manifest JSON
3. `vocab.txt`

The app copies selected files into an app-private staging directory and validates the manifest-declared SHA-256 hashes before activation.

### Safe activation

The installer validates the model hash, vocabulary hash, BERT vocabulary special tokens, dimension, and max sequence length before replacing the active package. Activation uses a staged directory so a partially imported model is not intentionally exposed as the active package.

### Runtime status

Settings reports whether the active RAG embedder is:

- the built-in offline hashing baseline, or
- a verified ONNX neural embedding package.

### Re-index requirement

Changing or removing the embedding package changes the embedding fingerprint. The existing vector index therefore becomes `REINDEX_REQUIRED` and retrieval is blocked until documents are indexed with the current embedding configuration.

### Privacy

Selected embedding files are copied only into the application's private storage. No new Android permission is introduced. The embedding model is never automatically downloaded.

## Version

- versionName: 3.10.0
- versionCode: 35
