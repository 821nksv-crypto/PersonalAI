# Local RAG privacy model

## Data boundary

Only files explicitly selected by the user enter the document pipeline.

Selected files are:
1. read locally;
2. converted to text locally;
3. chunked locally;
4. stored under the app's private storage;
5. retrieved locally.

They are **not** sent to another device, cloud API, analytics service, or distributed-compute worker by this MVP.

## Retrieval

MVP 0.6 uses a deterministic lexical retriever. This is intentionally simple and auditable.

Next upgrade:
- PDF text extraction
- embeddings
- local vector index
- hybrid lexical + semantic retrieval
- source/page citations in generated answers

## Important

Retrieval quality is not yet equivalent to a production vector database. The architecture is designed so the retriever can be replaced without changing the local-data boundary.
