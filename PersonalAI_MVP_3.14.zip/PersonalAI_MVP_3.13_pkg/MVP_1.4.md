# Personal AI MVP 1.4

## Runtime milestone

ExecuTorch 1.5's Android `LlmModule` supports:
- `LlmCallback.onResult()` for each generated token;
- `LlmCallback.onStats()` when generation finishes;
- `LlmModule.stop()` to interrupt generation;
- generation off the UI thread.

This milestone wires those APIs into the local chat path.

## Added

### True local streaming
For ordinary local conversation, tokens are delivered from the ExecuTorch callback into the Compose UI as they arrive.

### Stop generation
The user can interrupt an active local generation. This calls `LlmModule.stop()`.

### Local conversation context
A bounded recent-turn context is injected into the local prompt. It is stored and processed on-device only.

### RAG and web routes
Document QA and web-search routes continue to use the complete-answer service path. A unified streaming adapter for those routes is the next integration layer.

### Dependency hardening
`androidx.security:security-crypto:1.1.0` is used rather than the earlier alpha dependency.

## Privacy

Conversation context is local. No automatic contacts, SMS, WhatsApp, email, gallery, camera, microphone, or GPS access is added.

Internet mode remains explicit. The included Brave adapter receives only the search query.

## Build verification

The source was generated and the ExecuTorch API usage was checked against current official ExecuTorch 1.5 documentation. An APK build is not claimed unless a full Android SDK/Gradle environment is available.

## Next: MVP 1.5

- Stream RAG answers token-by-token.
- Stream web-grounded answers token-by-token.
- Proper citation objects rendered inline with answer chunks.
- Conversation memory compaction/summarization.
- Voice input/output.
- Model pack signature verification.
