# Internet Search — MVP 1.1

## Privacy boundary

When Internet mode is OFF:
- no web request is made by the search layer;
- the local model can still answer from its installed model;
- selected PDFs remain local.

When Internet mode is ON:
- only the explicit search query is sent to the configured HTTPS search endpoint;
- chat history, PDF contents, contacts, messages, photos, GPS, microphone and camera are not sent by this layer;
- returned web snippets are fed into the local LLM for answer generation.

## Search provider

The app deliberately uses a provider-neutral `WebSearchClient`. A real provider must be configured in a later build with:
- HTTPS endpoint;
- authentication/credential handling;
- rate limiting;
- response validation;
- source URL allow/deny policy as appropriate.

No fake search API key or hard-coded third-party account is included.

## Security

Android requires the `INTERNET` permission for network operations. This milestone declares only that normal permission and does not add personal-data permissions.

All search requests are required to use HTTPS.

## Known limitation

`ChatViewModelFactory` currently receives `null` for the web client in the demo UI, so the privacy UI and routing are implemented, but a production search provider still needs to be configured. This is intentional rather than pretending a provider is connected.
