# Personal AI MVP 2.4

## WorkManager observation + verified model import

### Indexing
Added `WorkManagerIndexingObserver` using deterministic unique work identity:
`document-index-{documentId}`.

It maps WorkManager status, progress and terminal error data into UI-friendly state and supports cancellation.

`IndexingWorkContract` centralizes worker input/output keys.

### Models
Added:
- JSON -> `ModelManifest` adapter.
- Model import session state.
- Verified model import controller.
- Model verification/install screen.
- Model library registration after successful installation.

The existing installer remains responsible for SHA-256, compatibility, optional Ed25519 signature verification, and atomic commit/rollback.

### Security
Selecting a model file does not make it trusted. The manifest is parsed and the model goes through the existing verification/install pipeline.

No automatic model download is introduced.

## Worker contract
The existing worker should publish:
- `progress`
- `page`
- `total_pages`
through WorkManager progress, and `error` through output data on terminal failure.

The observer is designed for this contract.

## Next: MVP 2.5
- Wire WorkManager observer into the actual Compose document screen.
- Add real model/manifest SAF pickers and session state.
- Persist model metadata beyond display names.
- Persist document metadata/path for recovery.
- Wire first-run -> navigation -> chat/settings/documents/models in one Activity flow.
- Start local memory summary generation with explicit user approval.
