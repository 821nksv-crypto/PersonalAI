# PersonalAI MVP 3.14 — Build Validation Gate

Version: 3.14.0  
Version code: 39

## Purpose
3.14 is a build-validation milestone. It does not claim a compiled APK from this packaging environment.

## Build target
- Android Gradle Plugin: 8.7.3
- Gradle: 8.11.1
- JDK: 17
- compileSdk: 35
- build-tools: 35.0.0
- minSdk: 26
- targetSdk: 35

## CI path
The GitHub Actions workflow installs Gradle 8.11.1 directly through `gradle/actions/setup-gradle@v4`. It deliberately does not require `gradlew` or `gradle-wrapper.jar`, because this source package currently does not contain a wrapper JAR.

Commands executed by CI:
1. `gradle testDebugUnitTest --stacktrace`
2. `gradle assembleDebug --stacktrace`

## Local Android Studio path
Open the project root in Android Studio with a configured Android SDK 35 and JDK 17. Gradle sync may use the IDE-managed Gradle installation; alternatively install Gradle 8.11.1 and run the commands above.

## Current environment limitation
The packaging environment has Java 21 but does not have Gradle, Android SDK, ADB, or AAPT2. Therefore APK compilation is **not verified here**.

## Security boundary
The manifest continues to request only `android.permission.INTERNET`. No automatic access to contacts, SMS, WhatsApp, gallery, microphone, camera, or location is introduced.
