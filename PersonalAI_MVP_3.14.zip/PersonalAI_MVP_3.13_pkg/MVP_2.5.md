# Personal AI MVP 2.5

## Unified application shell

This milestone creates the app-level Compose shell connecting:
- First-run privacy setup
- Chat
- Documents
- Models
- Settings

### Added
- `PersonalAiAppShell`
- `AppRuntime`
- `PersonalAiHostActivity`
- Chat host surface
- Runtime snapshot model
- App-shell unit test

### Privacy
The first-run privacy gate remains before the main application shell.

No new automatic personal-data permissions are introduced.

### Important integration boundary

`PersonalAiHostActivity` is a host/reference Activity. The existing production `MainActivity`, if present in the project, should be merged with this shell rather than creating two launcher Activities.

The callbacks marked for PDF/model pickers and memory clearing intentionally remain explicit integration points. They do not silently access files or personal data.

## Next: MVP 2.6

- Wire Android Activity Result PDF picker.
- Copy selected URI through ContentResolver into app-private storage.
- Wire model + manifest URI pickers.
- Connect WorkManager LiveData observer to document UI refresh.
- Connect `EncryptedMemoryStore.clear()` and memory toggle.
- Replace ChatHostScreen with the existing ChatViewModel/streaming Chat UI.
- Add lifecycle-aware state collection.
