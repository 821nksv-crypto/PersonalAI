# PersonalAI MVP 3.11

## Atomic RAG re-indexing

3.11 completes the embedding-change recovery path. A document is rebuilt off-index and committed only after all pages have been extracted and embedded successfully. Cancellation or failure before commit leaves the prior index untouched.

### User flow
- Settings/embedding package changes can put the persistent index into `REINDEX_REQUIRED`.
- Documents screen displays a re-index banner.
- `Re-index all documents` queues every app-private imported document through WorkManager.
- Each document is rebuilt atomically.
- The old vectors remain available until the replacement snapshot is activated.

### Safety
- No cloud upload of personal documents.
- No new Android permissions.
- Failed/cancelled rebuilds do not delete the prior document vectors.
