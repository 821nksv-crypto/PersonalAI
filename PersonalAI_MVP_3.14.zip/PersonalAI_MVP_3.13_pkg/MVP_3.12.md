# MVP 3.12 — Build Infrastructure Checkpoint

## Changes

- Version bumped to 3.12.0 / versionCode 37.
- Preserved the complete 3.11 source tree as the baseline; no feature code was discarded.
- Added `BUILD_3.12.md` documenting exact AGP/Gradle/Kotlin/SDK targets and the current verification boundary.
- Added `tools/check_build_environment.sh` for reproducible environment diagnostics.
- Confirmed the manifest remains INTERNET-only; no automatic personal-data permissions were added.
- Confirmed no Kotlin `TODO()`, `NotImplementedError`, or `FIXME` markers in the source tree during the checkpoint inspection.

## Verification

- Source/archive inspection: PASS.
- Version consistency: PASS.
- APK compilation: NOT VERIFIED in the preparation environment because Gradle and the Android SDK CLI toolchain were unavailable.
- Real-device inference/RAG: NOT VERIFIED.

## Next checkpoint

3.13 should be performed on a machine/container with a complete Android build toolchain. The first objective is `testDebugUnitTest` followed by `assembleDebug`; compile errors should be fixed from actual compiler output rather than predicted.
