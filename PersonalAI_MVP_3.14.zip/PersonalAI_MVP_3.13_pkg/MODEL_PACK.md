# Personal AI — Model Pack

## Selected baseline

For the first hardware-neutral Android baseline, use a **small Qwen3 model exported to ExecuTorch/XNNPACK**, rather than shipping a huge model inside the APK.

The ExecuTorch project currently documents Qwen3 0.6B export to XNNPACK and provides an Android LLM runtime. The project also documents Llama 3.2 1B/3B as mobile examples.

### Why 0.6B first

- substantially smaller than 1B/3B models
- more realistic for entry-level Android hardware
- suitable for validating the entire local-inference pipeline
- later the app can offer larger models based on detected RAM/accelerator

## Required files

The app expects:

- `qwen3_0_6b.pte`
- the tokenizer file required by the exported model

The files are imported into the app's private storage. The app does not automatically upload them anywhere.

## Export

Use the current ExecuTorch Qwen3 export recipe rather than renaming a checkpoint. An ExecuTorch `.pte` is an exported runtime artifact, not simply a renamed `.bin`/`.safetensors` file.

Example from the current ExecuTorch Qwen3 example:

```bash
python -m extension.llm.export.export_llm \\
  --config examples/models/qwen3/config/qwen3_xnnpack_q8da4w.yaml \\
  +base.model_class="qwen3_0_6b" \\
  +base.params="examples/models/qwen3/config/0_6b_config.json" \\
  +export.output_name="qwen3_0_6b.pte"
```

Check the model's own license and redistribution terms before packaging or distributing it.

## Integrity

Before installing a model in a release build, publish a SHA-256 checksum and verify it after download/import. MVP 0.5 includes the hashing utility; the next release will expose checksum verification in the UI.
