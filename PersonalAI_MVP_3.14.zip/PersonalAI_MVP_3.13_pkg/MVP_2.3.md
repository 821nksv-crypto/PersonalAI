# Personal AI MVP 2.3

## Durable indexing lifecycle

### Added
- Persistent `IndexingStateStore`.
- `IndexingProgressReporter` for QUEUED/RUNNING/COMPLETED/FAILED/CANCELLED state.
- Page-aware progress representation.
- `IndexingStateRepository` for UI refresh after process restart.
- `DocumentLibraryController.items()` now merges persisted worker/indexing state with the document catalog.
- Model installation state abstraction for the next model-import UI milestone.
- Unit tests for indexing-state semantics.

## Intended lifecycle

```text
Import PDF
  ↓
Document Catalog = QUEUED
  ↓
WorkManager
  ↓
RUNNING + page/progress
  ↓
COMPLETED
       or
FAILED + error
       or
CANCELLED
```

The durable state lives in app-private storage and is independent of an Activity instance.

## Integration note

The worker-facing reporter is intentionally separated from the PDF extraction/vector-index implementation. Before release, the worker should call:
- `queued()` when execution begins;
- `running()` after each successfully processed page/batch;
- `completed()` only after the vector index commit succeeds;
- `failed()` on terminal failure;
- `cancelled()` when WorkManager cancellation is detected.

This keeps the UI status semantically tied to actual indexing.

## Next: MVP 2.4

- Wire the reporter calls into every successful/failed/cancelled worker exit path.
- Observe WorkManager `WorkInfo` for immediate UI updates.
- Add persisted document file paths and recovery after process restart.
- Add model manifest JSON picker and verification result screen.
- Connect model installation result to `ModelLibraryController`.
