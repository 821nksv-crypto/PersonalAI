# Personal AI MVP 1.2

## Added

### Real web search provider
- Brave Search API adapter.
- User supplies their own API key.
- HTTPS request.
- Only the explicit search query is sent by this adapter.
- Search can be disabled with the UI switch.
- No fake key, account, or hidden provider is included.

### Persistent RAG
- Local vector index is serialized to app-private `rag_index.json`.
- Indexed selected PDF chunks survive app restarts.
- No cloud database is used.

### Streaming groundwork
- ExecuTorch `LlmCallback` streaming adapter is added.
- The runtime callback receives generated tokens as they arrive.
- The current router still commits complete answers for RAG/web paths; the next milestone can stream every route through a unified UI state.

## Privacy

The application does not request access to contacts, SMS, WhatsApp, email, gallery, microphone, camera, or GPS.

Internet mode is explicit. When enabled, the configured Brave adapter sends the search query to Brave Search. User-selected PDF content is not included in that request.

## Build note

This source package was generated in the workspace; an APK build was not claimed or verified here because the environment does not include the Android SDK/Gradle wrapper required for a reproducible Android build.

## Next

MVP 1.3:
- unified token streaming for local/RAG/web answers;
- encrypted local secrets for API keys;
- document deduplication and deletion UI;
- source-aware answer renderer;
- model pack verification/install UX;
- voice input/output.
