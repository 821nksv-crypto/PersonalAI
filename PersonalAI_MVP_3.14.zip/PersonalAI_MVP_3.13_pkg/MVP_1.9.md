# Personal AI MVP 1.9

## User-facing local controls
Added Compose components for:
- Model Manager: list/remove installed model files.
- Document indexing progress: running/queued/completed/failed/cancelled states.
- Local Memory: enable/disable and clear.

## Encrypted local memory
`EncryptedMemoryStore` stores the bounded memory summary in Android encrypted preferences. Disabling memory prevents new summaries from being saved; clearing removes the local summary.

## Tests
Added deterministic unit tests for model verification and memory compaction.

## Integration
The UI components are intentionally modular. They can be placed into the existing settings/document screens without changing the privacy architecture.

## Security
The signed-manifest infrastructure from 1.8 remains. A real release must pin its Ed25519 public key and require signature verification for remote model packages.

## Next: MVP 2.0
- Unified Settings screen.
- First-run privacy wizard.
- Model import picker wired to AtomicModelInstaller.
- PDF picker → WorkManager indexing → vector index end-to-end.
- Memory summary generation using local LLM, with explicit user control.
- Voice module with runtime permissions.
