# Personal AI MVP 3.9

## Neural embedding runtime

3.9 wires the RAG vector index to an explicit `EmbeddingRuntime` abstraction.

- Default baseline remains `local-hashing-384` and is truthfully identified as such.
- If an app-private verified ONNX embedding package is installed at `filesDir/embedding`, the index uses it for both document indexing and query retrieval.
- Model and vocabulary SHA-256 are verified before the ONNX runtime is created.
- The embedding fingerprint includes model identity, version, dimension, model hash, and vocabulary hash.
- A changed embedding package therefore invalidates the existing index and requires re-indexing.

## ONNX package

`EmbeddingModelInstaller` installs `model.onnx`, `vocab.txt`, and an app-private manifest atomically enough to avoid partial target files. `BertWordPieceTokenizer` implements the basic WordPiece path needed by BERT-style MiniLM exports.

The app does not download a model automatically. A verified model pack must be supplied locally.

## RAG path

PDF -> page extraction -> selected embedding runtime -> persistent vector index -> filtered top-K retrieval -> grounded prompt -> local LLM -> app-owned citations.

No personal document content is sent to the embedding runtime over the network.
