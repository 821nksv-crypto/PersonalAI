# MVP 0.9 — End-to-end RAG integration

## Runtime flow

1. User selects a PDF.
2. PdfBox extracts text page-by-page.
3. Chunks receive document + page metadata.
4. MiniLM ONNX generates local embeddings.
5. Local vector index stores/retrieves chunks.
6. `RagPromptBuilder` creates a grounded prompt.
7. `LocalLlmEngineAdapter` sends the prompt to the local Qwen/ExecuTorch runtime.
8. `RagAnswer` returns the generated answer plus structured sources.
9. UI renders sources from structured metadata.

## Citation rule

The model is NOT trusted to invent citations.

The application itself owns:
- document name
- page number
- chunk index
- retrieval score

Therefore the UI should render citations from `RagAnswer.sources`, not parse page numbers from the LLM's prose.

## Privacy

No cloud endpoint is required by this pipeline. User-selected documents stay inside app-private storage and local inference.
