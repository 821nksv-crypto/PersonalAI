# Personal AI MVP 1.5

## Unified streaming pipeline

All three chat routes now resolve their final prompt first and then use the same local ExecuTorch token-streaming path:

1. Router determines GENERAL_CHAT, DOCUMENT_QA, or INTERNET_SEARCH.
2. The service prepares the final prompt.
3. RAG retrieves local document chunks and creates structured `RagSource` metadata.
4. Internet mode performs an explicit search and creates structured `WebSearchResult` metadata.
5. ExecuTorch `LlmCallback.onResult()` streams generated tokens to the UI.
6. The UI stores citations separately from generated text.

ExecuTorch 1.5 documents `LlmCallback.onResult()` as the per-token callback, `onStats()` as generation completion, and `LlmModule.stop()` as the interruption API.

## Important 1.5 fix

The previous chat implementation passed `hasDocuments = false` to the router. 1.5 uses the actual persistent vector-index size, so document-aware routing is now possible.

## Stop behavior

If the user stops generation, the partial local output is preserved with a `[Generation stopped]` marker. The next generation can begin only after the previous one has been stopped/completed.

## Citation boundary

The model is instructed to use source labels, but the application remains the owner of source metadata. This prevents the UI from trusting arbitrary page numbers or URLs emitted by the model.

## Privacy boundary

- Selected documents remain app-private.
- Internet access is still explicitly enabled.
- Only the search query is sent to the configured search provider.
- No contacts, SMS, WhatsApp, email, gallery, microphone, camera, or GPS permission was added.

## Build status

Source/API integration was checked against the current ExecuTorch 1.5 Android documentation. No APK build is claimed without a complete Android SDK/Gradle build environment.

## Next: MVP 1.6

- Inline citation rendering for document and web answers.
- Conversation memory compaction/summarization instead of only recent-turn context.
- Model manifest signature verification.
- PDF indexing progress/retry UX.
- Optional voice input/output.
