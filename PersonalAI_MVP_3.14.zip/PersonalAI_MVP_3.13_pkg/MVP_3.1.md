# Personal AI — MVP 3.1

## Runtime hardening

- Installed model packages now have durable manifest metadata in `models/installed_packages.json`.
- Chat resolves the exact installed `.pte` and declared tokenizer pair from that registry instead of scanning arbitrary files.
- A compatible ExecuTorch package is the only path that creates `ExecuTorchLocalEngine`.
- The previous development/fake model fallback is no longer used by the production chat shell; without a compatible package the UI reports that no local model is available.
- Model removal removes the catalog entry, installed model, declared tokenizer, and package registry record.

## Model integrity

- Model SHA-256 remains mandatory.
- Declared tokenizer SHA-256 remains mandatory when a tokenizer is declared.
- Model and tokenizer are committed through the atomic installer.
- Successful installation writes the durable package registry used by runtime resolution.
- Optional Ed25519 manifest verification remains supported; production deployments should pin a real public key and require signatures for remotely distributed model packages.

## Privacy boundary

- Android manifest contains only `INTERNET` permission.
- Personal documents remain in app-private storage.
- Internet search remains an explicit user-controlled route.
- No contacts, SMS, call logs, gallery, microphone, camera, or location permission is introduced.

## Version

- versionName: `3.1.0`
- versionCode: `26`

## Build note

The repository does not contain a Gradle wrapper in this environment, so Android compilation was not executed here. Source-level integration checks were performed, but this is not an APK build verification.
