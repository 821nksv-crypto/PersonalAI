# MVP 3.14

## Build infrastructure validation milestone
3.14 moves the project from wrapper-dependent CI to an explicit Gradle 8.11.1 CI toolchain. This makes the build path reproducible even though the source archive does not contain the Gradle wrapper JAR.

## Expected outputs
- Unit-test result from `testDebugUnitTest`
- Debug APK from `assembleDebug`
- CI artifact named `personalai-debug-apk`

## Status
Source package prepared. APK compilation remains unverified until an environment with Android SDK 35 and Gradle 8.11.1 executes the build.
