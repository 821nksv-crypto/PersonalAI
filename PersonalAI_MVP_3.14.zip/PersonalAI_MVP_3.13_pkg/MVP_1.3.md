# Personal AI MVP 1.3

## Added

### Secure API-key storage
Brave Search API keys are stored with AndroidX Security Crypto encrypted preferences rather than ordinary SharedPreferences.

### Document management
- Persistent document records.
- SHA-256 based duplicate detection.
- Selected document list.
- Delete action removes the document's chunks from the local vector index.
- No cloud document store.

### Streaming UI state
A unified `StreamingChatState` now exists and the UI can render a live "generating" response state. The existing runtime adapter still returns complete answers for some paths; full callback-driven token streaming for every route remains a 1.4 integration task.

### Privacy boundary
- No contacts/SMS/WhatsApp/email/gallery/GPS/camera/microphone permissions.
- Internet remains an explicit user-controlled mode.
- Only the search query is sent to Brave Search by the included adapter.
- Selected PDFs remain local.

## Important implementation note

The dependency `androidx.security:security-crypto:1.1.0-alpha06` is used for encrypted local secrets. A production release should pin and periodically review dependency versions and Android security guidance.

## Next: MVP 1.4

- True token-by-token ExecuTorch UI streaming across all routes.
- Cancel generation.
- Conversation summarization/memory that stays local.
- Model download/import verification with signed manifests.
- Better PDF parser error reporting and document rebuild.
- Optional voice input/output.
