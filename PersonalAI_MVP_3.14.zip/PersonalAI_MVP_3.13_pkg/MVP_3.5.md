# Personal AI MVP 3.5

## Runtime integration fixes

- Fixed the PDF indexing worker to use `PdfTextExtractor(applicationContext)` and its real `extractPages(File)` API.
- Added the real `PersistentVectorIndex.addPage(...)` API used by WorkManager.
- Added `documentId` to persisted `PageChunk` records so document deletion/re-indexing is deterministic.
- Re-indexing removes the document's previous chunks before adding fresh pages, preventing duplicate retrieval entries after retries.
- Preserved app-private document storage and explicit Internet routing.
- Version: 3.5.0 / versionCode 30.

## Verification status

Source-level integration was audited in this environment. A full Android Gradle compile was not executed because the environment cannot retrieve the required Gradle/dependency artifacts. No APK build is claimed.
