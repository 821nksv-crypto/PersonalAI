# Personal AI MVP 2.7

## Import lifecycle integration

PDF flow:
User selects PDF → app-private copy → SHA-256 → registration/queue lifecycle → existing coordinator/WorkManager handoff.

Model flow:
User selects `.pte` + manifest → app-private copies → structural manifest validation helper → verification lifecycle → existing verified installation gate.

Added:
- ImportLifecycle
- ImportEventStore
- DocumentImportService
- ModelImportService
- ModelManifestGate
- DocumentProgressBridge
- Activity lifecycle hooks
- Unit tests

Security:
Copying a model never means it is trusted or installed. Production installation remains manifest → SHA-256 → Ed25519 → atomic commit.

Build status:
This ZIP was packaged from source; Android compilation was not claimed or verified in this environment.
