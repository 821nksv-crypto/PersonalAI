#!/usr/bin/env bash
set -u
ok=0
printf '%s\n' 'PersonalAI Android build environment check'
printf '%s\n' '----------------------------------------'
for c in java; do
  if command -v "$c" >/dev/null 2>&1; then
    printf '[PASS] %s: %s\n' "$c" "$(command -v "$c")"
  else
    printf '[FAIL] %s not found\n' "$c"; ok=1
  fi
done
if [ -x ./gradlew ]; then
  printf '[PASS] gradlew executable\n'
else
  printf '[FAIL] gradlew missing or not executable\n'; ok=1
fi
if [ -f ./gradle/wrapper/gradle-wrapper.jar ]; then
  printf '[PASS] gradle-wrapper.jar present\n'
else
  printf '[FAIL] gradle-wrapper.jar missing\n'; ok=1
fi
if command -v adb >/dev/null 2>&1; then
  printf '[PASS] adb: %s\n' "$(command -v adb)"
else
  printf '[WARN] adb not found (device testing unavailable here)\n'
fi
if command -v sdkmanager >/dev/null 2>&1; then
  printf '[PASS] sdkmanager: %s\n' "$(command -v sdkmanager)"
else
  printf '[WARN] sdkmanager not found (SDK provisioning unavailable here)\n'
fi
exit "$ok"
