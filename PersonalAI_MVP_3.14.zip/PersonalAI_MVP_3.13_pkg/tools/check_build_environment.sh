#!/usr/bin/env bash
set -u
printf 'Personal AI 3.12 build environment\n'
printf 'Java: '; java -version 2>&1 | head -1 || true
printf 'Gradle: '; if command -v gradle >/dev/null 2>&1; then gradle --version | head -8; else echo 'NOT FOUND'; fi
printf 'ADB: '; command -v adb || echo 'NOT FOUND'
printf 'SDKMAN Kotlin: '; command -v kotlinc || echo 'NOT FOUND'
printf 'Gradle wrapper JAR: '; if [ -f gradle/wrapper/gradle-wrapper.jar ]; then echo 'present'; else echo 'NOT FOUND'; fi
printf 'Wrapper script: '; if [ -f gradlew ]; then echo 'present'; else echo 'NOT FOUND'; fi
