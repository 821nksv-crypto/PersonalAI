# Personal AI MVP 2.0

## Integration milestone

### First-run privacy setup
The app now has a dedicated privacy setup screen explaining the local-first boundary before normal use.

### Central settings
Settings expose:
- Internet on/off
- Local Memory on/off
- Clear Local Memory
- Local model readiness

### Model import pipeline
`ModelImportPipeline` connects selected model files to the existing:
- runtime compatibility check;
- SHA-256 verification;
- optional Ed25519 signed manifest verification;
- atomic install/rollback.

### PDF import pipeline
`DocumentImportCoordinator` copies a selected PDF into app-private storage and schedules WorkManager indexing. The source is not automatically uploaded.

### Picker contracts
Android document-picker intents are provided for PDF and model selection.

## Privacy boundary

The app still does not request automatic access to contacts, SMS, WhatsApp, email, gallery, camera, microphone or GPS.

Internet access remains an explicit setting.

## Important build note

This milestone provides integration classes and composables. The exact existing `MainActivity` navigation can differ by branch; wire these screens into the app's navigation host rather than duplicating the application state.

## Next: MVP 2.1

- Wire the actual navigation host and first-run gate into MainActivity.
- Add document library screen with indexed/failed states.
- Add model import UI with manifest JSON selection and verification result.
- Add app-wide state repository.
- Add instrumentation tests for privacy gate and picker/import flows.
