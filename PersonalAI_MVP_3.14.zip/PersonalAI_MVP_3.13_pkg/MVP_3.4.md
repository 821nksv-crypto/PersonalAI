# PersonalAI MVP 3.4

## Build and source-hardening milestone

### Changes
- Fixed a real Kotlin source issue in `ModelImportService.kt`: added the missing `InstalledModelPackageStore` import.
- Pinned Android Java compilation to Java 17.
- Pinned Kotlin JVM target to 17.
- Added explicit `debug` and `release` build types.
- Debug builds use `.debug` applicationId suffix and `-debug` versionName suffix so a debug install cannot silently replace the production package.
- Release build is configured with the standard Android optimized ProGuard defaults while keeping minification disabled until model/runtime keep rules are validated.
- Added packaging exclusions for common license metadata collisions.
- Preserved the single launcher activity and INTERNET-only permission boundary.
- Preserved local model verification/import and explicit Internet routing.

## Verification
- Extracted the previous 3.3 archive and inspected the actual source tree.
- Confirmed the launcher and manifest boundaries.
- Found and fixed the missing model-store import described above.
- Confirmed the Gradle project has explicit Java/Kotlin 17 targets.

## Remaining build verification
This environment cannot download the Gradle distribution or Android dependencies, and no Gradle installation is available locally. Therefore `assembleDebug` and `test` have **not** been executed here.

The ZIP contains the Gradle distribution URL configuration, but the Gradle wrapper launcher JAR could not be provisioned offline. On a network-enabled machine/Android Studio, run:

```text
./gradlew test
./gradlew assembleDebug
```

If Android Studio reports a missing wrapper JAR, use **Gradle > Wrapper** from the IDE or regenerate the wrapper with the configured Gradle 8.11.1 distribution.
