# PersonalAI MVP 3.8

## Retrieval integrity
- Versioned persistent vector-index schema.
- Embedding configuration fingerprint is persisted with every index.
- Legacy/unversioned indexes require re-indexing instead of being silently reused.
- Dimension mismatch marks the index corrupted.
- Embedding configuration mismatch returns no retrieval results and exposes `REINDEX_REQUIRED`.

## Document-scoped RAG
- `PersistentVectorIndex.search()` accepts an optional set of document IDs.
- `ChatService.prepare()` accepts selected document IDs.
- `ChatViewModel.setSelectedDocumentIds()` provides the app-level selection boundary.
- A selected-document query cannot retrieve chunks from other documents.

## Privacy boundary
- All retrieval remains local.
- No new Android permissions.
- Internet search remains an explicit separate route.

## Runtime note
The current production retrieval baseline is the built-in 384-dimensional hashing vectorizer. The ONNX MiniLM adapter remains available as a separate adapter; its model/tokenizer must be wired through a verified embedding configuration before an index is built with it.
