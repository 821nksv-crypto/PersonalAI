# Personal AI MVP 2.2

## Persistent app data integration

### Added
- Persistent JSON document catalog in app-private storage.
- Persistent JSON model catalog in app-private storage.
- `DocumentLibraryController` for import, status, cancel, retry and delete.
- `ModelLibraryController` for installed model inventory.
- `AppCoordinator` as a single application-level entry point for state/catalog controllers.
- PDF import now registers the document before scheduling WorkManager indexing.
- Catalog unit tests.

## Data boundary

Catalog files are stored under the application's private files directory. They contain local metadata only; they do not upload documents or model contents.

## Important implementation note

The existing WorkManager worker is still the authoritative indexing executor. The catalog controller is the UI-facing state layer. A later milestone should make the worker write progress/failure state back to the catalog so that the UI reflects actual worker state after process death.

## Next: MVP 2.3

- Worker → catalog progress callbacks/persisted state.
- Observe WorkManager `WorkInfo` and map states to UI.
- Real retry/cancel controls.
- Model manifest JSON picker and verified install result UI.
- Wire `AppCoordinator` into the existing Activity/navigation host.
