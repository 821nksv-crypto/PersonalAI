# Personal AI MVP 2.9

## Integration milestone

2.9 connects the explicit file-selection boundary to the canonical document/model pipelines.

### Documents
- Selected PDF is copied to app-private storage.
- Canonical `DocumentLibraryController` registers the document.
- Canonical WorkManager scheduler queues indexing.
- WorkManager unique-work identity is now shared by scheduler, observer, and cancellation.
- Worker publishes durable indexing state and WorkManager progress.
- UI polls the durable state so queued/running/completed/failed/cancelled states become visible.
- Retry resolves the persisted private document path; delete cancels work and removes the private copy.

### Models
- Selected `.pte` + manifest are copied to app-private incoming storage.
- Manifest is parsed through the canonical model manifest type.
- Verification uses SHA-256 and compatibility checks.
- Installation uses the atomic installer.
- Successful installation is registered in the model catalog.
- The current UI path does not collect a detached Ed25519 signature; therefore unsigned imports remain possible. Production builds should require a pinned signature before allowing remote/untrusted model packages.

### Memory
- Settings clear action now calls the encrypted local memory store.

## Explicit privacy boundary

No contacts, SMS, WhatsApp, gallery, microphone, camera, GPS, or browser-history permissions are added. User-selected PDFs/models are copied into app-private storage.

## Not claimed

This milestone does not claim a verified Android APK build unless Gradle compilation is successfully run in the target Android build environment. The ZIP contains source code and project configuration; no model is bundled.
