# Personal AI — MVP 3.0

## Release cleanup
- One canonical application shell and launcher: `PersonalAiHostActivity`.
- Removed the obsolete duplicate `MainActivity` and duplicate `viewmodel` chat implementation.

## Local model package
- Model manifest can declare `tokenizerFileName` and `tokenizerSha256`.
- Model SHA-256 and size are verified before install.
- Declared tokenizer SHA-256 is verified before install.
- Model and tokenizer are committed atomically with rollback backups.
- A manifest requiring a tokenizer cannot be installed without it.

## Document indexing
- WorkManager unique identity is `document-index-{documentId}`.
- Worker publishes a shared integer `progress` (0–100).
- Durable app-private indexing state remains the UI source of truth.
- Retry resolves the persisted private document path.
- Delete cancels work, removes the private PDF and its durable handoff record.

## Privacy boundary
- No contacts, SMS, WhatsApp, gallery, microphone, camera or location permission.
- Selected files are copied into app-private storage.
- Internet remains an explicit route; it is not used for local document indexing.

## Verification status
This source package was statically audited and cleaned, but an Android APK build is not claimed as verified because a Gradle executable/wrapper is not present in the build environment used for this artifact.

## Production security note
Signed Ed25519 manifests are supported by the existing verifier, but production distribution should pin a real public key and make signature verification mandatory for remote/untrusted model packages.
