# Personal AI MVP 1.7

## Background document indexing
PDF indexing can run through WorkManager rather than blocking the UI. The worker:
- reports page-level progress;
- survives normal UI lifecycle changes;
- retries transient I/O failures with exponential backoff;
- can be cancelled by unique work name;
- keeps document files app-private.

## Model verification
Added:
- `ModelManifest`
- SHA-256 verification
- exact file-size verification
- runtime compatibility check
- Android ABI compatibility check

This is integrity verification, not cryptographic signature verification. A signed manifest remains a later security milestone.

## Privacy
Selected documents remain local. Indexing occurs on-device. WorkManager does not upload document content.

## Important integration note
The worker uses the existing `PersistentVectorIndex` API and expects `addPage(...)` to be available in the current source tree. If the exact API differs in a future refactor, wire the worker to the repository's page/chunk insertion method without changing the privacy boundary.

## Next: MVP 1.8
- Complete UI integration for indexing progress/retry/cancel.
- Signed manifest verification with embedded public key.
- Model download/import pipeline with atomic install and rollback.
- Memory compaction/summarization.
- Voice input/output.
