# Personal AI MVP 2.8

## Durable handoff layer

This milestone inspects the existing coordinator/controller source before adding integration.

### Added
- `CoordinatorHandoff`
- `ImportedDocumentStore`
- `IndexingHandoff`
- `PendingModelPairStore`
- persistent imported-document metadata
- persistent pending model-pair metadata
- handoff unit tests

### Why this layer exists

The ActivityResult API is lifecycle-scoped. A process recreation must not erase a selected document/model pair. Therefore selected artifacts are copied to app-private storage and their identities are persisted before any indexing or verification work is started.

### Document lifecycle

Selected PDF
→ private copy
→ SHA-256
→ `ImportedDocumentStore`
→ coordinator/catalog handoff
→ unique WorkManager indexing job
→ observer
→ page-level progress
→ completed/failed/cancelled.

### Model lifecycle

Selected `.pte` + manifest
→ private copy
→ `PendingModelPairStore`
→ manifest parsing
→ SHA-256
→ Ed25519 signature
→ atomic install
→ model catalog.

### Important build note

This package does not claim Android compilation verification. The existing controller APIs were inspected from source, and the integration is kept behind explicit handoff records rather than inventing constructor/method calls that were not present.

## Next: MVP 2.9

The next pass should wire the exact discovered `DocumentImportCoordinator` and `VerifiedModelImportController` methods into these handoff records, then expose live WorkManager state in `DocumentLibraryScreen` and installed-model verification state in `ModelVerificationScreen`.
