# Personal AI MVP 1.6

## Reliability / grounding milestone

### 1. Structured citations
RAG source metadata remains owned by the application. The model is not trusted to manufacture page numbers. The UI renders document/page citations from retrieved chunks after generation.

### 2. Bounded local memory
Recent conversation context is capped by both turn count and character count before being inserted into prompts. It never leaves the device unless the user explicitly enables Internet mode and the current search provider receives the search query.

### 3. Model package verification
`ModelInstallVerifier` verifies file existence, exact byte size, and SHA-256 against a supplied manifest before a model package is considered verified. Cryptographic manifest signing is intentionally left for the next installer hardening step.

### 4. PDF extraction restored
The project now uses the existing PdfBox-Android dependency for page-aware PDF extraction. Empty/unextractable PDFs report an explicit error.

### 5. Indexing feedback
PDF ingestion reports an indexing state and user-visible errors rather than silently swallowing failures.

### 6. Generation stop correctness
The previous malformed stopped-generation string is fixed. Partial output is persisted exactly once when the user stops generation.

## Important limitation

The indexing callback is still executed synchronously from the document picker callback. For very large PDFs, the next iteration should move extraction/embedding to a background worker with progress percentages and resumable jobs.

## Next: MVP 1.7

- Background WorkManager indexing with progress and retry.
- Signed model manifest / trusted-key verification.
- Model compatibility checks: runtime, architecture, tokenizer, context length.
- Memory summarization using the local model instead of only bounded recent turns.
- Voice input/output.
