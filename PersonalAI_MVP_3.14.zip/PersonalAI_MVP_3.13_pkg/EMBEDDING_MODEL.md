# MVP 0.8 embedding model

The RAG pipeline now supports a real neural embedding runtime.

## Baseline

Model: `sentence-transformers/all-MiniLM-L6-v2`

Android file: `onnx/model_qint8_arm64.onnx`

- Format: ONNX
- Quantization: int8
- Size: about 23 MB
- SHA-256: `4278337fd0ff3c68bfb6291042cad8ab363e1d9fbc43dcb499fe91c871902474`
- License: Apache-2.0

The model repository publishes an ARM64 quantized ONNX file at about 23 MB. The model card identifies it as the ONNX export of all-MiniLM-L6-v2.

## Runtime

`com.microsoft.onnxruntime:onnxruntime-android:1.30.0`

ONNX Runtime documents Android Java/Kotlin support through `onnxruntime-android`; its Android packages include XNNPACK support. The app uses CPU inference by default.

## Security

The model is not automatically downloaded by the app in this MVP. A production downloader must:
1. download only from an allowlisted source;
2. verify HTTPS;
3. verify the pinned SHA-256;
4. reject mismatches;
5. store the model in app-private storage.

## Tokenization

The adapter contains a deliberately small tokenizer boundary. For production quality, the full Hugging Face tokenizer vocabulary and normalization rules must be imported with the model pack rather than relying on the minimal fallback tokenizer.
